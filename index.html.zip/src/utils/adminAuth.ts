import { AdminSession } from '../types';

const ADMIN_SALT = 'SMK_TEXTILE_SECURE_SALT_2026';
const SESSION_KEY = 'smk_admin_session';
const HASH_STORAGE_KEY = 'smk_admin_auth_hash';

// Initial precomputed SHA-256 hash for default credentials:
// Username: "admin"
// Password: "MarutiAdmin@2026"
// String: "admin:MarutiAdmin@2026:SMK_TEXTILE_SECURE_SALT_2026"
// SHA-256: "b0ee8eec55cfebf0653d9e30a5caeeb3c9ff4cfc7aa9a0a03a25cfaf3077717f" (we also verify dynamically)

async function sha256(message: string): Promise<string> {
  const msgBuffer = new TextEncoder().encode(message);
  const hashBuffer = await crypto.subtle.digest('SHA-256', msgBuffer);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

export async function verifyAdminCredentials(username: string, password: string): Promise<boolean> {
  const cleanUser = username.trim().toLowerCase();
  const cleanPass = password.trim();

  if (!cleanUser || !cleanPass) return false;

  const inputHash = await sha256(`${cleanUser}:${cleanPass}:${ADMIN_SALT}`);
  
  // Check against stored custom hash if password was changed, or default hash
  const storedHash = localStorage.getItem(HASH_STORAGE_KEY);
  
  if (storedHash) {
    return inputHash === storedHash;
  }

  // Precomputed hash for admin / MarutiAdmin@2026
  const defaultHash = await sha256(`admin:MarutiAdmin@2026:${ADMIN_SALT}`);
  return inputHash === defaultHash;
}

export async function changeAdminPassword(username: string, newPass: string): Promise<boolean> {
  const cleanUser = username.trim().toLowerCase();
  const cleanPass = newPass.trim();
  if (cleanPass.length < 6) return false;

  const newHash = await sha256(`${cleanUser}:${cleanPass}:${ADMIN_SALT}`);
  localStorage.setItem(HASH_STORAGE_KEY, newHash);
  return true;
}

export function createAdminSession(username: string): AdminSession {
  const now = Date.now();
  const session: AdminSession = {
    username,
    role: 'ADMIN',
    token: `smk_token_${Math.random().toString(36).substring(2)}${Date.now()}`,
    loginTime: now,
    expiresAt: now + 8 * 60 * 60 * 1000 // 8 hours valid session
  };

  sessionStorage.setItem(SESSION_KEY, JSON.stringify(session));
  return session;
}

export function getAdminSession(): AdminSession | null {
  try {
    const raw = sessionStorage.getItem(SESSION_KEY);
    if (!raw) return null;
    const session: AdminSession = JSON.parse(raw);
    
    // Check role and expiry
    if (session.role !== 'ADMIN' || !session.expiresAt || session.expiresAt < Date.now()) {
      sessionStorage.removeItem(SESSION_KEY);
      return null;
    }
    return session;
  } catch {
    sessionStorage.removeItem(SESSION_KEY);
    return null;
  }
}

export function clearAdminSession(): void {
  sessionStorage.removeItem(SESSION_KEY);
}

export function isAdminAuthenticated(): boolean {
  return getAdminSession() !== null;
}
