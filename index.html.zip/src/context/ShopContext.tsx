import React, { createContext, useContext, useState, useEffect, useMemo } from 'react';
import { 
  Product, 
  ProductVariant, 
  FabricLengthOption, 
  CartItem, 
  Order, 
  Address, 
  CategoryType, 
  OrderStatus,
  TrackingStep,
  ReturnRequest,
  CustomerSummary,
  AdminSession
} from '../types';
import { PRODUCTS, POPULAR_SEARCHES, getCategoryLengthConfig } from '../data/products';
import { translations, Language } from '../data/translations';
import { 
  verifyAdminCredentials, 
  createAdminSession, 
  getAdminSession, 
  clearAdminSession 
} from '../utils/adminAuth';

interface ActiveModalState {
  type: 'product' | 'cartDrawer' | 'checkout' | 'tracking' | 'return' | 'support' | 'addConfirm';
  data?: any;
}

export interface AdminStats {
  todayOrders: number;
  totalOrders: number;
  pendingOrders: number;
  shippedOrders: number;
  deliveredOrders: number;
  cancelledOrders: number;
  returnRequests: number;
  refundRequests: number;
  totalCustomers: number;
  totalProducts: number;
  lowStockCount: number;
  todaySales: number;
  totalSales: number;
}

interface ShopContextType {
  // Localization
  language: Language;
  setLanguage: (lang: Language) => void;
  t: typeof translations['en'];

  // Products & Catalog
  products: Product[];
  filteredProducts: Product[];
  selectedCategory: CategoryType;
  setSelectedCategory: (category: CategoryType) => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  recentSearches: string[];
  addRecentSearch: (query: string) => void;
  clearRecentSearches: () => void;

  // Cart
  cart: CartItem[];
  cartCount: number;
  cartTotal: number;
  cartMRP: number;
  cartDiscount: number;
  addToCart: (product: Product, variant?: ProductVariant, length?: FabricLengthOption, quantity?: number) => void;
  updateCartQuantity: (cartItemId: string, delta: number) => void;
  removeFromCart: (cartItemId: string) => void;
  clearCart: () => void;

  // Wishlist
  wishlist: string[];
  toggleWishlist: (productId: string) => void;

  // Orders (Customer)
  orders: Order[];
  placeOrder: (
    address: Address, 
    deliveryType: 'standard' | 'express', 
    paymentMethod: 'cod' | 'upi' | 'card' | 'phonepe',
    paymentDetails?: { orderNumber?: string; paymentId?: string; paymentRef?: string; paymentStatus?: 'pending' | 'paid' }
  ) => Order;
  requestReturn: (orderId: string, productId: string, reason: string, refundMethod: 'bank_upi' | 'store_credit') => void;
  selectedOrderForTracking: Order | null;
  setSelectedOrderForTracking: (order: Order | null) => void;

  // Modals & Navigation
  activeModal: ActiveModalState | null;
  openModal: (type: ActiveModalState['type'], data?: any) => void;
  closeModal: () => void;
  lastAddedItem: CartItem | null;
  activeTab: 'home' | 'categories' | 'orders' | 'wishlist' | 'account';
  setActiveTab: (tab: 'home' | 'categories' | 'orders' | 'wishlist' | 'account') => void;
  
  // URL Routing
  currentPath: string;
  navigate: (path: string) => void;

  // Customer User Profile
  user: { name: string; phone: string; isLoggedIn: boolean };
  loginUser: (name: string, phone: string) => void;
  logoutUser: () => void;

  // ================= ADMIN MANAGEMENT =================
  adminSession: AdminSession | null;
  loginAdmin: (username: string, pass: string) => Promise<boolean>;
  logoutAdmin: () => void;
  adminStats: AdminStats;
  lowStockProducts: { product: Product; variant: ProductVariant }[];
  customersList: CustomerSummary[];
  returnRequests: ReturnRequest[];

  // Admin Order Actions
  updateOrderStatus: (orderId: string, status: OrderStatus, note?: string) => void;
  updateOrderTracking: (orderId: string, courierName: string, trackingNumber: string, expectedDelivery?: string) => void;
  updatePaymentStatus: (orderId: string, paymentStatus: 'pending' | 'paid' | 'failed' | 'cancelled' | 'refunded') => void;
  cancelOrder: (orderId: string, reason?: string) => void;

  // Admin Product Actions
  addProduct: (product: Product) => void;
  updateProduct: (product: Product) => void;
  deleteProduct: (productId: string) => void;
  updateProductStock: (productId: string, variantId: string, newStock: number) => void;

  // Admin Return Actions
  updateReturnStatus: (returnId: string, newStatus: 'approved' | 'picked_up' | 'refunded' | 'rejected') => void;
}

const ShopContext = createContext<ShopContextType | undefined>(undefined);

// Initial demo order for customer demonstration
const INITIAL_DEMO_ORDER: Order = {
  id: 'ord-demo-01',
  orderNumber: 'SMK-78491',
  date: '22 Sep 2026, 4:30 PM',
  items: [
    {
      cartItemId: 'demo-cart-01',
      product: PRODUCTS[0],
      selectedVariant: PRODUCTS[0].variants?.[0] || { id: 'std', colorName: 'Standard', hex: '#333333', stock: 100, image: PRODUCTS[0].image },
      selectedLength: PRODUCTS[0].lengthOptions[0],
      quantity: 1
    }
  ],
  shippingAddress: {
    fullName: 'Ramesh Patel',
    phoneNumber: '9876543210',
    pincode: '395006',
    houseFlat: 'B-402, Shrinath Residency',
    roadArea: 'Near Maruti Temple, Varachha',
    city: 'Surat',
    state: 'Gujarat',
    isDefault: true
  },
  deliveryType: 'standard',
  paymentMethod: 'cod',
  paymentStatus: 'pending',
  subtotal: 1299,
  discount: 600,
  deliveryFee: 0,
  totalPayable: 699,
  status: 'out_for_delivery',
  currentStepIndex: 4,
  trackingSteps: [
    { status: 'placed', label: 'Order Placed', labelHi: 'ऑर्डर बुक हुआ', date: '22 Sep 2026', time: '04:30 PM', completed: true, current: false },
    { status: 'confirmed', label: 'Order Confirmed', labelHi: 'ऑर्डर स्वीकृत', date: '22 Sep 2026', time: '05:15 PM', completed: true, current: false },
    { status: 'packed', label: 'Fabric Cut & Packed', labelHi: 'कपड़ा पैक हुआ', date: '23 Sep 2026', time: '11:00 AM', completed: true, current: false, note: 'Quality checked by Master Tailor' },
    { status: 'shipped', label: 'Shipped via Courier', labelHi: 'कूरियर को सौंपा', date: '23 Sep 2026', time: '06:40 PM', completed: true, current: false, note: 'Dispatched from Surat Central Hub' },
    { status: 'out_for_delivery', label: 'Out for Delivery', labelHi: 'डिलीवरी के लिए निकला', date: 'Today', time: '09:15 AM', completed: false, current: true, note: 'Delivery agent: Vikram (Ph: +91 91234 56789)' },
    { status: 'delivered', label: 'Delivered', labelHi: 'डिलीवर होगा', date: 'Today by 5:00 PM', time: 'Expected', completed: false, current: false }
  ],
  courierName: 'Delhivery Surface Express',
  trackingNumber: 'DLHV-994827103',
  expectedDelivery: 'Today by 5:00 PM'
};

const INITIAL_DEMO_RETURNS: ReturnRequest[] = [
  {
    id: 'ret-demo-101',
    orderId: 'ord-demo-01',
    orderNumber: 'SMK-78491',
    customerName: 'Ramesh Patel',
    customerPhone: '9876543210',
    productName: 'Pure Egyptian Giza Cotton Shirt Fabric',
    variantColor: 'Pure Pearl White',
    amount: 699,
    reason: 'Fabric shade looks slightly lighter than expected',
    refundMethod: 'bank_upi',
    status: 'pending',
    requestDate: '23 Sep 2026, 08:30 PM'
  }
];

export const ShopProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Navigation / Route Handling
  const [currentPath, setCurrentPath] = useState<string>(() => {
    return window.location.pathname || '/';
  });

  useEffect(() => {
    const handlePopState = () => {
      setCurrentPath(window.location.pathname || '/');
    };
    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  const navigate = (path: string) => {
    if (window.location.pathname !== path) {
      window.history.pushState(null, '', path);
      setCurrentPath(path);
      window.scrollTo(0, 0);
    }
  };

  // Language (English default)
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem('smk_lang');
    return saved === 'hi' ? 'en' : (saved as Language) || 'en';
  });

  // Products catalog (persisted in localStorage, fallback to PRODUCTS)
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem('smk_products');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          // Verify each product has category-specific sizes (shirt=2.25m, pant=1.20m, combo=2.25m+1.20m)
          return parsed.map((p: Product) => {
            const config = getCategoryLengthConfig(p.category, p.name);
            return {
              ...p,
              lengthOptions: config.options,
              defaultLength: config.defaultLength
            };
          });
        }
      }
      return PRODUCTS;
    } catch {
      return PRODUCTS;
    }
  });

  // Cart
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('smk_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Wishlist
  const [wishlist, setWishlist] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('smk_wishlist');
      return saved ? JSON.parse(saved) : ['smk-01', 'smk-03'];
    } catch {
      return ['smk-01', 'smk-03'];
    }
  });

  // Orders
  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem('smk_orders');
      return saved ? JSON.parse(saved) : [INITIAL_DEMO_ORDER];
    } catch {
      return [INITIAL_DEMO_ORDER];
    }
  });

  // Real-time Order Synchronization with Full-Stack Backend
  useEffect(() => {
    fetch('/api/orders')
      .then(res => res.json())
      .then(data => {
        if (data.success && Array.isArray(data.orders) && data.orders.length > 0) {
          setOrders(prev => {
            const map = new Map<string, Order>();
            data.orders.forEach((o: Order) => map.set(o.id, o));
            prev.forEach(o => {
              if (!map.has(o.id)) map.set(o.id, o);
            });
            return Array.from(map.values());
          });
        }
      })
      .catch(() => {
        // Fallback for offline usage
      });
  }, []);

  // Return Requests
  const [returnRequests, setReturnRequests] = useState<ReturnRequest[]>(() => {
    try {
      const saved = localStorage.getItem('smk_returns');
      return saved ? JSON.parse(saved) : INITIAL_DEMO_RETURNS;
    } catch {
      return INITIAL_DEMO_RETURNS;
    }
  });

  // Customer user
  const [user, setUser] = useState<{ name: string; phone: string; isLoggedIn: boolean }>(() => {
    try {
      const saved = localStorage.getItem('smk_user');
      return saved ? JSON.parse(saved) : { name: 'Ramesh Patel', phone: '9876543210', isLoggedIn: true };
    } catch {
      return { name: 'Ramesh Patel', phone: '9876543210', isLoggedIn: true };
    }
  });

  // Recent Searches
  const [recentSearches, setRecentSearches] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('smk_searches');
      return saved ? JSON.parse(saved) : ['White Shirt Fabric', 'Combo Set'];
    } catch {
      return ['White Shirt Fabric', 'Combo Set'];
    }
  });

  const [selectedCategory, setSelectedCategory] = useState<CategoryType>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeModal, setActiveModal] = useState<ActiveModalState | null>(null);
  const [lastAddedItem, setLastAddedItem] = useState<CartItem | null>(null);
  const [activeTab, setActiveTab] = useState<'home' | 'categories' | 'orders' | 'wishlist' | 'account'>('home');
  const [selectedOrderForTracking, setSelectedOrderForTracking] = useState<Order | null>(null);

  // Admin Session State
  const [adminSession, setAdminSession] = useState<AdminSession | null>(() => {
    return getAdminSession();
  });

  // Sync state to local storage
  useEffect(() => {
    localStorage.setItem('smk_lang', language);
  }, [language]);

  useEffect(() => {
    try {
      localStorage.setItem('smk_products', JSON.stringify(products));
    } catch (e) {
      console.warn('Could not save all products to localStorage quota limit', e);
    }
  }, [products]);

  useEffect(() => {
    localStorage.setItem('smk_cart', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem('smk_wishlist', JSON.stringify(wishlist));
  }, [wishlist]);

  useEffect(() => {
    localStorage.setItem('smk_orders', JSON.stringify(orders));
  }, [orders]);

  useEffect(() => {
    localStorage.setItem('smk_returns', JSON.stringify(returnRequests));
  }, [returnRequests]);

  useEffect(() => {
    localStorage.setItem('smk_user', JSON.stringify(user));
  }, [user]);

  useEffect(() => {
    localStorage.setItem('smk_searches', JSON.stringify(recentSearches));
  }, [recentSearches]);

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
  };

  const t = translations[language];

  const addRecentSearch = (query: string) => {
    const trimmed = query.trim();
    if (!trimmed) return;
    setRecentSearches(prev => {
      const filtered = prev.filter(s => s.toLowerCase() !== trimmed.toLowerCase());
      return [trimmed, ...filtered].slice(0, 6);
    });
  };

  const clearRecentSearches = () => {
    setRecentSearches([]);
  };

  // Cart calculations
  const cartCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  const cartMRP = cart.reduce((acc, item) => {
    const baseMRP = item.product.originalPrice * item.selectedLength.priceMultiplier;
    return acc + Math.round(baseMRP * item.quantity);
  }, 0);

  const cartTotal = cart.reduce((acc, item) => {
    const basePrice = item.product.discountPrice * item.selectedLength.priceMultiplier;
    return acc + Math.round(basePrice * item.quantity);
  }, 0);

  const cartDiscount = cartMRP - cartTotal;

  const addToCart = (
    product: Product, 
    variant?: ProductVariant, 
    length?: FabricLengthOption, 
    quantity = 1
  ) => {
    const selectedLength = length || product.lengthOptions[0];
    const defaultVariant: ProductVariant = variant || product.variants?.[0] || {
      id: 'std',
      colorName: 'Standard',
      hex: '#333333',
      image: product.image,
      stock: product.totalStock || 100
    };
    const cartItemId = `${product.id}-${selectedLength.lengthMeters}`;
    const newItem: CartItem = {
      cartItemId,
      product,
      selectedVariant: defaultVariant,
      selectedLength,
      quantity
    };

    setCart(prev => {
      const existingIndex = prev.findIndex(item => item.cartItemId === cartItemId);
      if (existingIndex > -1) {
        const updated = [...prev];
        updated[existingIndex] = {
          ...updated[existingIndex],
          quantity: updated[existingIndex].quantity + quantity
        };
        return updated;
      }
      return [...prev, newItem];
    });

    setLastAddedItem(newItem);
    setActiveModal({ type: 'addConfirm', data: newItem });
  };

  const updateCartQuantity = (cartItemId: string, delta: number) => {
    setCart(prev => {
      return prev
        .map(item => {
          if (item.cartItemId === cartItemId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[];
    });
  };

  const removeFromCart = (cartItemId: string) => {
    setCart(prev => prev.filter(item => item.cartItemId !== cartItemId));
  };

  const clearCart = () => {
    setCart([]);
  };

  const toggleWishlist = (productId: string) => {
    setWishlist(prev => 
      prev.includes(productId) 
        ? prev.filter(id => id !== productId)
        : [...prev, productId]
    );
  };

  const openModal = (type: ActiveModalState['type'], data?: any) => {
    setActiveModal({ type, data });
  };

  const closeModal = () => {
    setActiveModal(null);
  };

  const loginUser = (name: string, phone: string) => {
    setUser({
      name: name.trim() || 'Customer',
      phone: phone.trim() || '9876543210',
      isLoggedIn: true
    });
  };

  const logoutUser = () => {
    setUser({ name: '', phone: '', isLoggedIn: false });
  };

  // Place order from customer checkout
  const placeOrder = (
    address: Address, 
    deliveryType: 'standard' | 'express', 
    paymentMethod: 'cod' | 'upi' | 'card' | 'phonepe',
    paymentDetails?: { orderNumber?: string; paymentId?: string; paymentRef?: string; paymentStatus?: 'pending' | 'paid' }
  ): Order => {
    const deliveryFee = deliveryType === 'express' ? 49 : 0;
    const finalPayable = cartTotal + deliveryFee;
    const randomNum = Math.floor(10000 + Math.random() * 90000);
    const orderNumber = paymentDetails?.orderNumber || `SMK-${randomNum}`;

    const now = new Date();
    const dateFormatted = `${now.getDate()} Sep 2026, ${now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;

    const newOrder: Order = {
      id: `ord-${Date.now()}`,
      orderNumber,
      date: dateFormatted,
      items: [...cart],
      shippingAddress: address,
      deliveryType,
      paymentMethod,
      paymentStatus: paymentDetails?.paymentStatus === 'paid' ? 'paid' : 'pending',
      paymentId: paymentDetails?.paymentId,
      paymentRef: paymentDetails?.paymentRef,
      subtotal: cartMRP,
      discount: cartDiscount,
      deliveryFee,
      totalPayable: finalPayable,
      status: 'placed',
      currentStepIndex: 0,
      trackingSteps: [
        { status: 'placed', label: 'Order Placed', labelHi: 'ऑर्डर बुक हुआ', date: 'Today', time: 'Just Now', completed: true, current: true, note: 'Order received in system' },
        { status: 'confirmed', label: 'Order Confirmed', labelHi: 'ऑर्डर स्वीकृत', date: 'Expected within 1 hr', time: '', completed: false, current: false },
        { status: 'packed', label: 'Fabric Cut & Packed', labelHi: 'कपड़ा पैक होगा', date: 'Tomorrow', time: '', completed: false, current: false },
        { status: 'shipped', label: 'Shipped via Courier', labelHi: 'कूरियर को सौंपेंगे', date: '2-3 Days', time: '', completed: false, current: false },
        { status: 'out_for_delivery', label: 'Out for Delivery', labelHi: 'डिलीवरी के लिए निकलेगा', date: '3-4 Days', time: '', completed: false, current: false },
        { status: 'delivered', label: 'Delivered', labelHi: 'डिलीवर होगा', date: deliveryType === 'express' ? 'In 2 Days' : 'In 3-4 Days', time: '', completed: false, current: false }
      ],
      courierName: 'Delhivery Surface Express',
      trackingNumber: `DLHV-${Math.floor(100000000 + Math.random() * 900000000)}`,
      expectedDelivery: deliveryType === 'express' ? 'Within 2 Days' : 'Within 3-4 Days'
    };

    // Save to persistent backend API
    fetch('/api/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newOrder),
    }).catch(err => console.log('Offline order save fallback', err));

    // Deduct stock automatically
    setProducts(prev => {
      const updated = [...prev];
      cart.forEach(item => {
        const pIndex = updated.findIndex(p => p.id === item.product.id);
        if (pIndex > -1) {
          const productCopy = { ...updated[pIndex] };
          if (productCopy.totalStock !== undefined) {
            productCopy.totalStock = Math.max(0, productCopy.totalStock - item.quantity);
          }
          if (productCopy.variants && productCopy.variants.length > 0) {
            productCopy.variants = productCopy.variants.map(v => {
              if (item.selectedVariant && v.id === item.selectedVariant.id) {
                return { ...v, stock: Math.max(0, v.stock - item.quantity) };
              }
              return v;
            });
          }
          updated[pIndex] = productCopy;
        }
      });
      return updated;
    });

    setOrders(prev => [newOrder, ...prev]);
    clearCart();
    return newOrder;
  };

  // Customer Return Request
  const requestReturn = (
    orderId: string, 
    productId: string, 
    reason: string, 
    refundMethod: 'bank_upi' | 'store_credit'
  ) => {
    const targetOrder = orders.find(o => o.id === orderId);
    const targetItem = targetOrder?.items.find(i => i.product.id === productId) || targetOrder?.items[0];

    const newReturn: ReturnRequest = {
      id: `ret-${Date.now()}`,
      orderId,
      orderNumber: targetOrder ? targetOrder.orderNumber : `SMK-ORD`,
      customerName: targetOrder?.shippingAddress.fullName || user.name || 'Customer',
      customerPhone: targetOrder?.shippingAddress.phoneNumber || user.phone || '9876543210',
      productName: targetItem ? targetItem.product.name : 'Fabric Product',
      variantColor: targetItem?.selectedVariant?.colorName,
      amount: targetOrder?.totalPayable || 0,
      reason,
      refundMethod,
      status: 'pending',
      requestDate: 'Today, ' + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setReturnRequests(prev => [newReturn, ...prev]);

    setOrders(prev => prev.map(ord => {
      if (ord.id === orderId) {
        return {
          ...ord,
          returnRequested: true,
          returnReason: reason,
          returnStatus: 'pending',
          refundMethod,
          returnDate: 'Scheduled for Tomorrow pickup'
        };
      }
      return ord;
    }));
  };

  // ================= ADMIN ACTIONS =================
  const loginAdmin = async (username: string, pass: string): Promise<boolean> => {
    const isValid = await verifyAdminCredentials(username, pass);
    if (isValid) {
      const session = createAdminSession(username);
      setAdminSession(session);
      return true;
    }
    return false;
  };

  const logoutAdmin = () => {
    clearAdminSession();
    setAdminSession(null);
    navigate('/');
  };

  const updateOrderStatus = (orderId: string, newStatus: OrderStatus, note?: string) => {
    setOrders(prev => prev.map(order => {
      if (order.id !== orderId) return order;

      const stepIndexMap: Record<OrderStatus, number> = {
        'placed': 0,
        'confirmed': 1,
        'packed': 2,
        'shipped': 3,
        'out_for_delivery': 4,
        'delivered': 5,
        'cancelled': 0,
        'returned': 5
      };

      const newStepIdx = stepIndexMap[newStatus] ?? 0;
      const nowStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

      const updatedSteps = order.trackingSteps.map((step, idx) => {
        if (idx < newStepIdx) {
          return { ...step, completed: true, current: false };
        } else if (idx === newStepIdx) {
          return { 
            ...step, 
            completed: newStatus === 'delivered', 
            current: newStatus !== 'delivered', 
            time: nowStr,
            note: note || step.note 
          };
        } else {
          return { ...step, completed: false, current: false };
        }
      });

      return {
        ...order,
        status: newStatus,
        currentStepIndex: newStepIdx,
        trackingSteps: updatedSteps,
        paymentStatus: (newStatus === 'delivered' && order.paymentMethod === 'cod') ? 'paid' : order.paymentStatus
      };
    }));

    // Sync status to backend
    fetch(`/api/orders/${orderId}/status`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: newStatus })
    }).catch(() => {});
  };

  const updateOrderTracking = (
    orderId: string, 
    courierName: string, 
    trackingNumber: string, 
    expectedDelivery?: string
  ) => {
    setOrders(prev => prev.map(order => {
      if (order.id !== orderId) return order;
      return {
        ...order,
        courierName: courierName.trim() || order.courierName,
        trackingNumber: trackingNumber.trim() || order.trackingNumber,
        expectedDelivery: expectedDelivery?.trim() || order.expectedDelivery
      };
    }));
  };

  const updatePaymentStatus = (orderId: string, paymentStatus: 'pending' | 'paid' | 'failed' | 'cancelled' | 'refunded') => {
    setOrders(prev => prev.map(o => o.id === orderId ? { ...o, paymentStatus } : o));
    fetch(`/api/orders/${orderId}/status`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ paymentStatus })
    }).catch(() => {});
  };

  const cancelOrder = (orderId: string, reason?: string) => {
    setOrders(prev => prev.map(order => {
      if (order.id !== orderId) return order;
      return {
        ...order,
        status: 'cancelled',
        trackingSteps: order.trackingSteps.map(s => ({
          ...s,
          current: false,
          note: s.status === 'placed' ? `Cancelled: ${reason || 'Order cancelled by Store Admin'}` : s.note
        }))
      };
    }));

    // Restore stock
    const targetOrder = orders.find(o => o.id === orderId);
    if (targetOrder) {
      setProducts(prev => {
        const updated = [...prev];
        targetOrder.items.forEach(item => {
          const pIndex = updated.findIndex(p => p.id === item.product.id);
          if (pIndex > -1) {
            const productCopy = { ...updated[pIndex] };
            if (productCopy.totalStock !== undefined) {
              productCopy.totalStock = productCopy.totalStock + item.quantity;
            }
            if (productCopy.variants && productCopy.variants.length > 0) {
              productCopy.variants = productCopy.variants.map(v => {
                if (item.selectedVariant && v.id === item.selectedVariant.id) {
                  return { ...v, stock: v.stock + item.quantity };
                }
                return v;
              });
            }
            updated[pIndex] = productCopy;
          }
        });
        return updated;
      });
    }
  };

  // Product Actions
  const addProduct = (newProduct: Product) => {
    const config = getCategoryLengthConfig(newProduct.category, newProduct.name);
    const configuredProduct: Product = {
      ...newProduct,
      lengthOptions: (newProduct.lengthOptions && newProduct.lengthOptions.length > 0) ? newProduct.lengthOptions : config.options,
      defaultLength: newProduct.defaultLength || config.defaultLength
    };
    setProducts(prev => [configuredProduct, ...prev]);
  };

  const updateProduct = (updatedProduct: Product) => {
    setProducts(prev => prev.map(p => p.id === updatedProduct.id ? updatedProduct : p));
  };

  const deleteProduct = (productId: string) => {
    setProducts(prev => prev.filter(p => p.id !== productId));
  };

  const updateProductStock = (productId: string, variantId: string, newStock: number) => {
    setProducts(prev => prev.map(prod => {
      if (prod.id !== productId) return prod;
      const safeStock = Math.max(0, newStock);
      const variantsList = prod.variants || [];
      const updatedVariants = variantsList.length > 0
        ? variantsList.map(v => (v.id === variantId || variantsList.length === 1) ? { ...v, stock: safeStock } : v)
        : [{ id: 'std', colorName: 'Standard', hex: '#333333', stock: safeStock, image: prod.image }];
      
      return {
        ...prod,
        totalStock: safeStock,
        variants: updatedVariants,
        inStock: safeStock > 0
      };
    }));
  };

  // Return Actions
  const updateReturnStatus = (
    returnId: string, 
    newStatus: 'approved' | 'picked_up' | 'refunded' | 'rejected'
  ) => {
    setReturnRequests(prev => prev.map(r => {
      if (r.id !== returnId) return r;
      return {
        ...r,
        status: newStatus,
        resolutionDate: new Date().toLocaleDateString('en-GB')
      };
    }));

    // Sync with corresponding order
    const returnItem = returnRequests.find(r => r.id === returnId);
    if (returnItem) {
      setOrders(prev => prev.map(o => {
        if (o.id === returnItem.orderId) {
          return {
            ...o,
            returnStatus: newStatus,
            paymentStatus: newStatus === 'refunded' ? 'refunded' : o.paymentStatus,
            status: newStatus === 'refunded' ? 'returned' : o.status
          };
        }
        return o;
      }));
    }
  };

  // Filtered products logic for customer view
  const filteredProducts = useMemo(() => {
    return products.filter(product => {
      // Category filter
      if (selectedCategory === 'shirt' && product.category !== 'shirt') return false;
      if (selectedCategory === 'pant' && product.category !== 'pant') return false;
      if (selectedCategory === 'combo' && product.category !== 'combo') return false;
      if (selectedCategory === 'premium' && product.category !== 'premium') return false;
      if (selectedCategory === 'new_arrivals' && !product.isNewArrival) return false;
      if (selectedCategory === 'best_sellers' && !product.isBestSeller) return false;
      if (selectedCategory === 'offers' && !product.isOffer) return false;

      // Search query filter
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const name = product.name.toLowerCase();
        const nameHi = product.nameHi.toLowerCase();
        const desc = product.description.toLowerCase();
        const brand = product.brand.toLowerCase();
        const material = product.material.toLowerCase();

        const matchesWord = (word: string) => {
          if (word === 'pant' || word === 'trouser' || word === 'chinos') {
            return product.category === 'pant' || name.includes('pant') || name.includes('trouser');
          }
          if (word === 'shirt' || word === 'shirting') {
            return product.category === 'shirt' || name.includes('shirt');
          }
          if (word === 'combo' || word === 'pair' || word === 'jodi' || word === 'set') {
            return product.category === 'combo';
          }
          if (word === 'safari') {
            return name.includes('safari') || desc.includes('safari');
          }
          if (word === 'linen' || word === 'lenin') {
            return material.includes('linen') || name.includes('linen');
          }
          if (word === 'cotton' || word === 'coton') {
            return material.includes('cotton') || name.includes('cotton');
          }
          return false;
        };

        const words = q.split(' ').filter(Boolean);
        const isSynonymMatch = words.some(w => matchesWord(w));

        return (
          name.includes(q) ||
          nameHi.includes(q) ||
          desc.includes(q) ||
          brand.includes(q) ||
          material.includes(q) ||
          isSynonymMatch
        );
      }

      return true;
    });
  }, [products, selectedCategory, searchQuery]);

  // Low stock products calculation (stock <= 20)
  const lowStockProducts = useMemo(() => {
    const list: { product: Product; variant: ProductVariant }[] = [];
    products.forEach(p => {
      const stock = p.totalStock ?? (p.variants?.[0]?.stock ?? 0);
      if (stock <= 20) {
        list.push({
          product: p,
          variant: p.variants?.[0] || { id: 'std', colorName: 'Standard', hex: '#333333', stock, image: p.image }
        });
      }
    });
    return list;
  }, [products]);

  // Unique customers list extracted from real orders
  const customersList: CustomerSummary[] = useMemo(() => {
    const map = new Map<string, CustomerSummary>();
    orders.forEach(ord => {
      const phone = ord.shippingAddress.phoneNumber;
      const existing = map.get(phone);
      if (existing) {
        existing.totalOrders += 1;
        if (ord.status !== 'cancelled') {
          existing.totalSpent += ord.totalPayable;
        }
      } else {
        map.set(phone, {
          phoneNumber: phone,
          fullName: ord.shippingAddress.fullName,
          city: ord.shippingAddress.city,
          state: ord.shippingAddress.state,
          totalOrders: 1,
          totalSpent: ord.status !== 'cancelled' ? ord.totalPayable : 0,
          lastOrderDate: ord.date
        });
      }
    });
    return Array.from(map.values());
  }, [orders]);

  // Live Real Database Admin Stats
  const adminStats: AdminStats = useMemo(() => {
    const totalOrders = orders.length;
    const pendingOrders = orders.filter(o => o.status === 'placed' || o.status === 'confirmed').length;
    const shippedOrders = orders.filter(o => o.status === 'shipped' || o.status === 'out_for_delivery').length;
    const deliveredOrders = orders.filter(o => o.status === 'delivered').length;
    const cancelledOrders = orders.filter(o => o.status === 'cancelled').length;

    // Today's orders
    const todayOrdersList = orders.filter(o => o.date.includes('Today') || o.date.includes('Just Now') || o.date.includes('24 Sep'));
    const todayOrders = todayOrdersList.length;
    const todaySales = todayOrdersList
      .filter(o => o.status !== 'cancelled')
      .reduce((sum, o) => sum + o.totalPayable, 0);

    const totalSales = orders
      .filter(o => o.status !== 'cancelled')
      .reduce((sum, o) => sum + o.totalPayable, 0);

    const pendingReturns = returnRequests.filter(r => r.status === 'pending' || r.status === 'approved').length;
    const refundRequests = returnRequests.filter(r => r.status === 'picked_up').length;

    return {
      todayOrders,
      totalOrders,
      pendingOrders,
      shippedOrders,
      deliveredOrders,
      cancelledOrders,
      returnRequests: pendingReturns,
      refundRequests,
      totalCustomers: customersList.length,
      totalProducts: products.length,
      lowStockCount: lowStockProducts.length,
      todaySales,
      totalSales
    };
  }, [orders, returnRequests, customersList, products, lowStockProducts]);

  return (
    <ShopContext.Provider
      value={{
        language,
        setLanguage,
        t,
        products,
        filteredProducts,
        selectedCategory,
        setSelectedCategory,
        searchQuery,
        setSearchQuery,
        recentSearches,
        addRecentSearch,
        clearRecentSearches,
        cart,
        cartCount,
        cartTotal,
        cartMRP,
        cartDiscount,
        addToCart,
        updateCartQuantity,
        removeFromCart,
        clearCart,
        wishlist,
        toggleWishlist,
        orders,
        placeOrder,
        requestReturn,
        activeModal,
        openModal,
        closeModal,
        lastAddedItem,
        activeTab,
        setActiveTab,
        currentPath,
        navigate,
        user,
        loginUser,
        logoutUser,
        selectedOrderForTracking,
        setSelectedOrderForTracking,

        // Admin
        adminSession,
        loginAdmin,
        logoutAdmin,
        adminStats,
        lowStockProducts,
        customersList,
        returnRequests,
        updateOrderStatus,
        updateOrderTracking,
        updatePaymentStatus,
        cancelOrder,
        addProduct,
        updateProduct,
        deleteProduct,
        updateProductStock,
        updateReturnStatus
      }}
    >
      {children}
    </ShopContext.Provider>
  );
};

export const useShop = () => {
  const context = useContext(ShopContext);
  if (!context) {
    throw new Error('useShop must be used within a ShopProvider');
  }
  return context;
};
