import React from 'react';
import { useShop } from '../context/ShopContext';
import { 
  Home, 
  Grid, 
  Package, 
  Heart, 
  User, 
  ShoppingBag 
} from 'lucide-react';

export const BottomNav: React.FC = () => {
  const { 
    activeTab, 
    setActiveTab, 
    cartCount, 
    openModal, 
    language,
    orders,
    wishlist 
  } = useShop();

  const navItems = [
    { key: 'home', labelEn: 'Home', labelHi: 'होम', icon: <Home className="w-5 h-5" /> },
    { key: 'categories', labelEn: 'Categories', labelHi: 'कैटेगरी', icon: <Grid className="w-5 h-5" /> },
    { 
      key: 'orders', 
      labelEn: 'Orders', 
      labelHi: 'ऑर्डर', 
      icon: <Package className="w-5 h-5" />,
      badge: orders.length > 0 ? orders.length : undefined
    },
    { 
      key: 'wishlist', 
      labelEn: 'Wishlist', 
      labelHi: 'पसंद', 
      icon: <Heart className="w-5 h-5" />,
      badge: wishlist.length > 0 ? wishlist.length : undefined
    },
    { key: 'account', labelEn: 'Account', labelHi: 'खाता', icon: <User className="w-5 h-5" /> },
  ];

  return (
    <div className="sm:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#111111] border-t border-[#2B2B2B] shadow-lg px-2 py-1.5 pb-safe">
      <div className="flex items-center justify-around">
        {navItems.map((item) => {
          const isActive = activeTab === item.key;
          return (
            <button
              key={item.key}
              onClick={() => setActiveTab(item.key as any)}
              className={`flex-1 flex flex-col items-center justify-center py-1 px-1 rounded-xl transition cursor-pointer relative min-h-[48px] ${
                isActive ? 'text-[#C8A96B] font-extrabold' : 'text-[#D9D4CA] hover:text-white font-medium'
              }`}
            >
              <div className="relative">
                {item.icon}
                {item.badge && (
                  <span className="absolute -top-1.5 -right-2 bg-[#9B2C2C] text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center">
                    {item.badge}
                  </span>
                )}
              </div>
              <span className="text-[11px] mt-0.5 tracking-tight">
                {language === 'hi' ? item.labelHi : item.labelEn}
              </span>
            </button>
          );
        })}

        {/* Permanent Floating Cart Trigger on Mobile */}
        <button
          onClick={() => openModal('cartDrawer')}
          className="flex-1 flex flex-col items-center justify-center py-1 px-1 rounded-xl text-white font-extrabold cursor-pointer relative min-h-[48px]"
          aria-label="View Shopping Bag"
        >
          <div className="relative">
            <ShoppingBag className="w-5 h-5 text-[#C8A96B]" />
            {cartCount > 0 && (
              <span className="absolute -top-1.5 -right-2 bg-[#9B2C2C] text-white text-[10px] font-black w-4 h-4 rounded-full flex items-center justify-center animate-bounce">
                {cartCount}
              </span>
            )}
          </div>
          <span className="text-[11px] mt-0.5 tracking-tight text-[#D9D4CA]">
            {language === 'hi' ? 'कार्ट' : 'Cart'}
          </span>
        </button>
      </div>
    </div>
  );
};
