import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import { Address, Order } from '../types';
import { 
  X, 
  Check, 
  MapPin, 
  Truck, 
  CreditCard, 
  Banknote, 
  QrCode, 
  ShieldCheck, 
  ArrowLeft, 
  ArrowRight, 
  CheckCircle2, 
  Phone,
  Package,
  Calendar,
  Copy,
  ExternalLink,
  Loader2,
  Sparkles,
  Smartphone,
  CheckCheck,
  AlertCircle
} from 'lucide-react';

export const CheckoutModal: React.FC = () => {
  const { 
    cart, 
    cartTotal, 
    cartMRP, 
    cartDiscount, 
    closeModal, 
    openModal, 
    placeOrder, 
    user, 
    loginUser, 
    language,
    setSelectedOrderForTracking
  } = useShop();

  const [currentStep, setCurrentStep] = useState<1 | 2 | 3 | 4>(1);

  // Address Form State
  const [address, setAddress] = useState<Address>({
    fullName: user.name || 'Ramesh Patel',
    phoneNumber: user.phone || '9876543210',
    pincode: '395006',
    houseFlat: 'B-402, Shrinath Heights',
    roadArea: 'Near Maruti Temple, Varachha',
    city: 'Surat',
    state: 'Gujarat',
    isDefault: true
  });

  const [addressErrors, setAddressErrors] = useState<Record<string, string>>({});
  const [deliveryType, setDeliveryType] = useState<'standard' | 'express'>('standard');
  const [paymentMethod, setPaymentMethod] = useState<'phonepe' | 'cod' | 'upi' | 'card'>('phonepe');
  const [placedOrder, setPlacedOrder] = useState<Order | null>(null);
  const [checkoutOrderNumber] = useState(() => `SMK-${Math.floor(10000 + Math.random() * 90000)}`);
  const [paymentNotice, setPaymentNotice] = useState<string | null>(null);

  // Backend Payment State
  const [paymentSession, setPaymentSession] = useState<{
    paymentId: string;
    upiIntentUrl: string;
    upiQrCode: string;
    phonepeIntentUrl?: string;
    phonepeRedirectUrl?: string | null;
    merchantUpi: string;
    merchantName: string;
    amount: number;
    phonepeConfig?: {
      merchantId: string;
      environment: string;
      phonepeUpi: string;
    };
  } | null>(null);
  const [isLoadingPayment, setIsLoadingPayment] = useState(false);
  const [isVerifying, setIsVerifying] = useState(false);
  const [utrNumber, setUtrNumber] = useState('');
  const [utrError, setUtrError] = useState('');
  const [copiedUpi, setCopiedUpi] = useState(false);

  const deliveryFee = deliveryType === 'express' ? 49 : 0;
  const finalPayable = cartTotal + deliveryFee;

  // Auto-detect city/state from pincode
  const handlePincodeChange = (pin: string) => {
    setAddress(prev => ({ ...prev, pincode: pin }));
    if (pin.length === 6) {
      if (pin.startsWith('39')) {
        setAddress(prev => ({ ...prev, city: 'Surat', state: 'Gujarat' }));
      } else if (pin.startsWith('40') || pin.startsWith('41')) {
        setAddress(prev => ({ ...prev, city: 'Mumbai', state: 'Maharashtra' }));
      } else if (pin.startsWith('11')) {
        setAddress(prev => ({ ...prev, city: 'New Delhi', state: 'Delhi' }));
      } else if (pin.startsWith('30')) {
        setAddress(prev => ({ ...prev, city: 'Jaipur', state: 'Rajasthan' }));
      } else if (pin.startsWith('56')) {
        setAddress(prev => ({ ...prev, city: 'Bengaluru', state: 'Karnataka' }));
      } else if (pin.startsWith('38')) {
        setAddress(prev => ({ ...prev, city: 'Ahmedabad', state: 'Gujarat' }));
      }
    }
  };

  const validateAddress = () => {
    const errors: Record<string, string> = {};
    if (!address.fullName.trim()) {
      errors.fullName = language === 'hi' ? 'कृपया अपना नाम भरें' : 'Please enter your full name';
    }
    if (!address.phoneNumber.trim() || address.phoneNumber.trim().length < 10) {
      errors.phoneNumber = language === 'hi' ? '10 अंकों का मान्य मोबाइल नंबर भरें' : 'Enter 10-digit mobile number';
    }
    if (!address.pincode.trim() || address.pincode.trim().length !== 6) {
      errors.pincode = language === 'hi' ? '6 अंकों का पिनकोड भरें' : 'Enter 6-digit pincode';
    }
    if (!address.houseFlat.trim()) {
      errors.houseFlat = language === 'hi' ? 'मकान या फ्लैट नंबर भरें' : 'Enter house or flat number';
    }
    if (!address.roadArea.trim()) {
      errors.roadArea = language === 'hi' ? 'सड़क या इलाका भरें' : 'Enter street or area';
    }
    setAddressErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleNextFromAddress = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateAddress()) {
      if (!user.isLoggedIn) {
        loginUser(address.fullName, address.phoneNumber);
      }
      setCurrentStep(2);
    }
  };

  // Fetch Payment Order from Backend API (PhonePe / UPI / Card / COD)
  const fetchPaymentSession = async (method: 'phonepe' | 'cod' | 'upi' | 'card') => {
    setIsLoadingPayment(true);
    try {
      const res = await fetch('/api/payment/create-order', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          orderId: checkoutOrderNumber,
          amount: finalPayable,
          customerName: address.fullName,
          customerPhone: address.phoneNumber,
          paymentMethod: method,
        }),
      });
      const data = await res.json();
      if (data.success) {
        setPaymentSession({
          paymentId: data.paymentId,
          upiIntentUrl: data.upiIntentUrl || '',
          upiQrCode: data.upiQrCode || '',
          phonepeIntentUrl: data.phonepeIntentUrl || '',
          phonepeRedirectUrl: data.phonepeRedirectUrl || null,
          merchantUpi: data.merchantUpi || 'shreemarutikrupa@ybl',
          merchantName: data.merchantName || 'Shree Maruti Krupa',
          amount: data.amount,
          phonepeConfig: data.phonepeConfig,
        });
      }
    } catch (err) {
      console.error('Payment order creation error:', err);
    } finally {
      setIsLoadingPayment(false);
    }
  };

  // Auto load payment session when entering Step 3
  React.useEffect(() => {
    if (currentStep === 3 && (paymentMethod === 'phonepe' || paymentMethod === 'upi') && !paymentSession) {
      fetchPaymentSession(paymentMethod);
    }
  }, [currentStep, paymentMethod]);

  const handleSelectPaymentMethod = (method: 'phonepe' | 'cod' | 'upi' | 'card') => {
    setPaymentMethod(method);
    if ((method === 'phonepe' || method === 'upi')) {
      fetchPaymentSession(method);
    }
  };

  const handleCopyUpi = () => {
    const upi = paymentSession?.merchantUpi || 'shreemarutikrupa@ybl';
    navigator.clipboard?.writeText(upi);
    setCopiedUpi(true);
    setTimeout(() => setCopiedUpi(false), 2000);
  };

  const handleConfirmOrder = async () => {
    if (paymentMethod === 'phonepe' || paymentMethod === 'upi') {
      if (utrNumber.trim() && utrNumber.trim().length < 6) {
        setUtrError(language === 'hi' ? 'कृपया सही 12-अंकों का UTR / PhonePe Ref नंबर दर्ज करें' : 'Please enter valid 12-digit UTR / Ref number');
        return;
      }
    }

    setIsVerifying(true);
    try {
      const verifiedPaymentId = paymentSession?.paymentId || `PAY_${Date.now()}`;
      let finalStatus: 'pending' | 'paid' = 'pending';

      const verifyRes = await fetch('/api/payment/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          paymentId: verifiedPaymentId,
          orderId: checkoutOrderNumber,
          paymentMethod,
          utr: utrNumber.trim() || undefined,
          phonepeTxnId: utrNumber.trim() || undefined,
        }),
      });
      const verifyData = await verifyRes.json();
      
      // Strict rule: Only mark paid if backend server verified with PhonePe
      if (verifyData.success && verifyData.paymentStatus === 'paid') {
        finalStatus = 'paid';
      } else {
        finalStatus = 'pending';
      }

      const order = placeOrder(address, deliveryType, paymentMethod, {
        orderNumber: checkoutOrderNumber,
        paymentId: verifiedPaymentId,
        paymentRef: utrNumber.trim() || (paymentMethod === 'phonepe' ? 'PHONEPE_PG' : paymentMethod === 'cod' ? 'COD_DOORSTEP' : 'UPI_ONLINE'),
        paymentStatus: finalStatus,
      });
      setPlacedOrder(order);
    } catch (err) {
      console.error('Order placement error:', err);
      const order = placeOrder(address, deliveryType, paymentMethod, {
        orderNumber: checkoutOrderNumber,
        paymentStatus: 'pending',
      });
      setPlacedOrder(order);
    } finally {
      setIsVerifying(false);
    }
  };

  const handleTrackPlacedOrder = () => {
    if (placedOrder) {
      setSelectedOrderForTracking(placedOrder);
      closeModal();
      openModal('tracking', placedOrder);
    }
  };

  // Success Confirmation Screen
  if (placedOrder) {
    return (
      <div className="fixed inset-0 z-50 bg-stone-950/70 backdrop-blur-xs flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl max-w-lg w-full p-6 sm:p-8 text-center shadow-2xl border border-[#E5E0D8] animate-in zoom-in-95 duration-150">
          <div className="w-16 h-16 rounded-full bg-[#F7F5F0] border border-[#E5E0D8] flex items-center justify-center text-[#C8A96B] mx-auto mb-4">
            <CheckCircle2 className="w-10 h-10" />
          </div>

          <span className="inline-block bg-[#F7F5F0] text-[#111111] border border-[#E5E0D8] text-xs font-bold px-3 py-1 rounded-full mb-2">
            {language === 'hi' ? 'ऑर्डर सफलतापूर्वक दर्ज हुआ' : 'Order Placed Successfully'}
          </span>

          <h2 className="text-xl sm:text-2xl font-black text-[#111111]">
            {language === 'hi' ? 'बधाई! आपका ऑर्डर बुक हो गया है' : 'Thank You For Your Order!'}
          </h2>

          <p className="text-xs sm:text-sm text-[#4A4A4A] mt-2">
            {language === 'hi' 
              ? `ऑर्डर नंबर: #${placedOrder.orderNumber}। हमने पुष्टि का संदेश ${placedOrder.shippingAddress.phoneNumber} पर भेज दिया है।`
              : `Order #${placedOrder.orderNumber} confirmed. Confirmation sent to ${placedOrder.shippingAddress.phoneNumber}.`}
          </p>

          <div className="bg-[#F7F5F0] rounded-xl p-4 my-5 border border-[#E5E0D8] text-left text-xs space-y-2">
            <div className="flex justify-between items-center text-[#4A4A4A]">
              <span className="font-medium flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-[#C8A96B]" />
                {language === 'hi' ? 'अनुमानित डिलीवरी:' : 'Estimated Delivery:'}
              </span>
              <span className="font-bold text-[#111111]">{placedOrder.expectedDelivery}</span>
            </div>
            <div className="flex justify-between items-center text-[#4A4A4A]">
              <span className="font-medium flex items-center gap-1.5">
                <Banknote className="w-3.5 h-3.5 text-[#C8A96B]" />
                {language === 'hi' ? 'भुगतान का तरीका:' : 'Payment Method:'}
              </span>
              <span className="font-bold text-[#111111]">
                {placedOrder.paymentMethod === 'phonepe'
                  ? 'PhonePe Payment Gateway'
                  : placedOrder.paymentMethod === 'cod'
                  ? 'Cash on Delivery (COD)'
                  : placedOrder.paymentMethod.toUpperCase()}
              </span>
            </div>
            <div className="flex justify-between items-center text-[#4A4A4A]">
              <span className="font-medium flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5 text-emerald-600" />
                {language === 'hi' ? 'पेमेंट स्थिति:' : 'Payment Status:'}
              </span>
              <span className={`font-black text-xs px-2 py-0.5 rounded ${
                placedOrder.paymentStatus === 'paid'
                  ? 'bg-emerald-100 text-emerald-800'
                  : 'bg-amber-100 text-amber-800'
              }`}>
                {placedOrder.paymentStatus === 'paid' ? 'PAID (भुगतान सफल)' : 'PENDING / UNPAID (घर पर भुगतान)'}
              </span>
            </div>
            {placedOrder.paymentRef && (
              <div className="flex justify-between items-center text-[#4A4A4A]">
                <span className="font-medium text-[11px]">
                  {language === 'hi' ? 'रेफरेंस नंबर:' : 'Transaction Ref:'}
                </span>
                <span className="font-mono font-bold text-[11px] text-[#111111] truncate max-w-[170px]">
                  {placedOrder.paymentRef}
                </span>
              </div>
            )}
            <div className="flex justify-between items-center text-[#4A4A4A]">
              <span className="font-medium flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-[#C8A96B]" />
                {language === 'hi' ? 'डिलीवरी का पता:' : 'Deliver To:'}
              </span>
              <span className="font-semibold text-[#111111] truncate max-w-[200px]">
                {placedOrder.shippingAddress.houseFlat}, {placedOrder.shippingAddress.city}
              </span>
            </div>
          </div>

          <div className="space-y-2.5">
            <button
              onClick={handleTrackPlacedOrder}
              className="w-full bg-[#111111] hover:bg-[#2B2B2B] text-white font-extrabold py-3.5 px-4 rounded-xl text-sm flex items-center justify-center gap-2 shadow-md transition cursor-pointer"
            >
              <Package className="w-5 h-5 text-[#C8A96B]" />
              <span>{language === 'hi' ? 'ऑर्डर अभी ट्रैक करें (Track Order)' : 'Track Your Order Now'}</span>
            </button>

            <button
              onClick={() => {
                closeModal();
                openModal('product', null);
              }}
              className="w-full py-2.5 px-4 text-xs sm:text-sm text-[#4A4A4A] hover:text-[#111111] font-bold transition cursor-pointer"
            >
              {language === 'hi' ? 'मुख्य पृष्ठ पर लौटें' : 'Back to Home'}
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 bg-stone-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-2xl w-full my-auto overflow-hidden shadow-2xl border border-[#E5E0D8] max-h-[92vh] flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[#E5E0D8] bg-[#F7F5F0] flex items-center justify-between">
          <div>
            <h2 className="text-base sm:text-lg font-bold text-[#111111]">
              {language === 'hi' ? 'आसान 4-स्टेप चेकआउट' : 'Easy 4-Step Checkout'}
            </h2>
            <p className="text-xs text-[#777777]">
              {language === 'hi' ? 'कोई मुश्किल सवाल नहीं • तुरंत ऑर्डर बुक करें' : 'Simple & Quick • No unnecessary details'}
            </p>
          </div>
          <button
            onClick={closeModal}
            className="w-8 h-8 rounded-lg bg-white hover:bg-[#E5E0D8] text-[#111111] border border-[#E5E0D8] flex items-center justify-center transition cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Progress Indicators */}
        <div className="bg-[#F7F5F0] px-4 py-3 border-b border-[#E5E0D8]">
          <div className="grid grid-cols-4 gap-2 text-center">
            {[
              { num: 1, label: language === 'hi' ? '1. पता' : '1. Address' },
              { num: 2, label: language === 'hi' ? '2. डिलीवरी' : '2. Delivery' },
              { num: 3, label: language === 'hi' ? '3. भुगतान' : '3. Payment' },
              { num: 4, label: language === 'hi' ? '4. ऑर्डर' : '4. Review' }
            ].map(step => (
              <div
                key={step.num}
                className={`py-1.5 px-2 rounded-lg text-xs font-bold transition flex items-center justify-center gap-1 ${
                  currentStep === step.num
                    ? 'bg-[#111111] text-white shadow-xs'
                    : currentStep > step.num
                    ? 'bg-[#111111] text-[#C8A96B]'
                    : 'text-[#777777] bg-white border border-[#E5E0D8]'
                }`}
              >
                {currentStep > step.num ? <Check className="w-3.5 h-3.5 text-[#C8A96B]" /> : null}
                <span className="truncate">{step.label}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Main Content Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6">
          {/* STEP 1: Address */}
          {currentStep === 1 && (
            <form onSubmit={handleNextFromAddress} className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm sm:text-base font-bold text-[#111111] flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-[#C8A96B]" />
                  <span>{language === 'hi' ? 'कपड़ा कहाँ पहुंचाना है? (डिलीवरी पता)' : 'Where should we deliver your fabric?'}</span>
                </h3>
                <span className="text-xs text-[#777777] font-medium">Step 1 of 4</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Full Name */}
                <div>
                  <label className="block text-xs font-bold text-[#111111] mb-1">
                    {language === 'hi' ? 'आपका पूरा नाम *' : 'Full Name *'}
                  </label>
                  <input
                    type="text"
                    value={address.fullName}
                    onChange={(e) => setAddress({ ...address, fullName: e.target.value })}
                    placeholder="e.g. Ramesh Patel"
                    className="w-full px-3 py-2 text-sm bg-[#F7F5F0] border border-[#E5E0D8] rounded-xl focus:bg-white focus:outline-none focus:ring-1 focus:ring-[#111111] text-[#111111]"
                  />
                  {addressErrors.fullName && <p className="text-[11px] text-[#9B2C2C] mt-0.5">{addressErrors.fullName}</p>}
                </div>

                {/* Mobile Number */}
                <div>
                  <label className="block text-xs font-bold text-[#111111] mb-1">
                    {language === 'hi' ? '10-अंकों का मोबाइल नंबर *' : '10-Digit Mobile Number *'}
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-[#777777]">+91</span>
                    <input
                      type="tel"
                      maxLength={10}
                      value={address.phoneNumber}
                      onChange={(e) => setAddress({ ...address, phoneNumber: e.target.value.replace(/\D/g, '') })}
                      placeholder="9876543210"
                      className="w-full pl-11 pr-3 py-2 text-sm bg-[#F7F5F0] border border-[#E5E0D8] rounded-xl focus:bg-white focus:outline-none focus:ring-1 focus:ring-[#111111] font-mono text-[#111111]"
                    />
                  </div>
                  {addressErrors.phoneNumber && <p className="text-[11px] text-[#9B2C2C] mt-0.5">{addressErrors.phoneNumber}</p>}
                </div>
              </div>

              {/* Pincode & City/State */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-[#111111] mb-1">
                    {language === 'hi' ? 'पिनकोड (Pincode) *' : 'Pincode *'}
                  </label>
                  <input
                    type="text"
                    maxLength={6}
                    value={address.pincode}
                    onChange={(e) => handlePincodeChange(e.target.value.replace(/\D/g, ''))}
                    placeholder="395006"
                    className="w-full px-3 py-2 text-sm bg-[#F7F5F0] border border-[#E5E0D8] rounded-xl focus:bg-white focus:outline-none focus:ring-1 focus:ring-[#111111] font-mono text-[#111111]"
                  />
                  {addressErrors.pincode && <p className="text-[11px] text-[#9B2C2C] mt-0.5">{addressErrors.pincode}</p>}
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#111111] mb-1">
                    {language === 'hi' ? 'शहर (City)' : 'City'}
                  </label>
                  <input
                    type="text"
                    value={address.city}
                    onChange={(e) => setAddress({ ...address, city: e.target.value })}
                    className="w-full px-3 py-2 text-sm bg-[#F7F5F0] border border-[#E5E0D8] rounded-xl focus:bg-white focus:outline-none focus:ring-1 focus:ring-[#111111] text-[#111111]"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#111111] mb-1">
                    {language === 'hi' ? 'राज्य (State)' : 'State'}
                  </label>
                  <input
                    type="text"
                    value={address.state}
                    onChange={(e) => setAddress({ ...address, state: e.target.value })}
                    className="w-full px-3 py-2 text-sm bg-[#F7F5F0] border border-[#E5E0D8] rounded-xl focus:bg-white focus:outline-none focus:ring-1 focus:ring-[#111111] text-[#111111]"
                  />
                </div>
              </div>

              {/* Flat / House No */}
              <div>
                <label className="block text-xs font-bold text-[#111111] mb-1">
                  {language === 'hi' ? 'मकान नंबर / फ्लैट नंबर / बिल्डिंग *' : 'House No. / Flat / Building *'}
                </label>
                <input
                  type="text"
                  value={address.houseFlat}
                  onChange={(e) => setAddress({ ...address, houseFlat: e.target.value })}
                  placeholder="e.g. B-402, Shrinath Heights"
                  className="w-full px-3 py-2 text-sm bg-[#F7F5F0] border border-[#E5E0D8] rounded-xl focus:bg-white focus:outline-none focus:ring-1 focus:ring-[#111111] text-[#111111]"
                />
                {addressErrors.houseFlat && <p className="text-[11px] text-[#9B2C2C] mt-0.5">{addressErrors.houseFlat}</p>}
              </div>

              {/* Area / Road */}
              <div>
                <label className="block text-xs font-bold text-[#111111] mb-1">
                  {language === 'hi' ? 'सड़क / इलाका / लैंडमार्क (पहचान) *' : 'Road / Area / Colony / Landmark *'}
                </label>
                <input
                  type="text"
                  value={address.roadArea}
                  onChange={(e) => setAddress({ ...address, roadArea: e.target.value })}
                  placeholder="e.g. Near Maruti Temple, Varachha Main Road"
                  className="w-full px-3 py-2 text-sm bg-[#F7F5F0] border border-[#E5E0D8] rounded-xl focus:bg-white focus:outline-none focus:ring-1 focus:ring-[#111111] text-[#111111]"
                />
                {addressErrors.roadArea && <p className="text-[11px] text-[#9B2C2C] mt-0.5">{addressErrors.roadArea}</p>}
              </div>

              <div className="pt-3">
                <button
                  type="submit"
                  className="w-full bg-[#111111] hover:bg-[#2B2B2B] text-white font-extrabold py-3.5 px-4 rounded-xl text-sm sm:text-base flex items-center justify-center gap-2 shadow-md transition cursor-pointer"
                >
                  <span>{language === 'hi' ? 'इस पते पर आगे बढ़ें' : 'Deliver to this Address'}</span>
                  <ArrowRight className="w-5 h-5 text-[#C8A96B]" />
                </button>
              </div>
            </form>
          )}

          {/* STEP 2: Delivery Speed */}
          {currentStep === 2 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm sm:text-base font-bold text-[#111111] flex items-center gap-2">
                  <Truck className="w-4 h-4 text-[#C8A96B]" />
                  <span>{language === 'hi' ? 'डिलीवरी का प्रकार चुनें' : 'Choose Delivery Speed'}</span>
                </h3>
                <span className="text-xs text-[#777777] font-medium">Step 2 of 4</span>
              </div>

              <div className="space-y-3">
                {/* Standard Free Delivery */}
                <div
                  onClick={() => setDeliveryType('standard')}
                  className={`p-4 rounded-xl border-2 cursor-pointer transition flex items-center justify-between ${
                    deliveryType === 'standard'
                      ? 'border-[#111111] bg-[#F7F5F0] shadow-xs'
                      : 'border-[#E5E0D8] hover:bg-[#F7F5F0]'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-white border border-[#E5E0D8] flex items-center justify-center text-[#111111] shrink-0 mt-0.5">
                      <Truck className="w-4 h-4 text-[#C8A96B]" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-[#111111]">
                        {language === 'hi' ? 'साधारण डिलीवरी (3-4 दिन) — बिल्कुल मुफ्त' : 'Standard Delivery (3-4 Days) — FREE'}
                      </h4>
                      <p className="text-xs text-[#4A4A4A] mt-0.5">
                        {language === 'hi' ? 'विश्वसनीय कूरियर द्वारा सुरक्षित पैकेजिंग के साथ।' : 'Safe courier shipping with quality fabric check.'}
                      </p>
                    </div>
                  </div>
                  <span className="text-sm font-black text-[#111111] uppercase">
                    {language === 'hi' ? 'मुफ्त' : 'FREE'}
                  </span>
                </div>

                {/* Express Delivery */}
                <div
                  onClick={() => setDeliveryType('express')}
                  className={`p-4 rounded-xl border-2 cursor-pointer transition flex items-center justify-between ${
                    deliveryType === 'express'
                      ? 'border-[#111111] bg-[#F7F5F0] shadow-xs'
                      : 'border-[#E5E0D8] hover:bg-[#F7F5F0]'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-white border border-[#E5E0D8] flex items-center justify-center text-[#111111] shrink-0 mt-0.5">
                      <Truck className="w-4 h-4 text-[#C8A96B]" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-[#111111]">
                        {language === 'hi' ? 'फास्ट एक्सप्रेस डिलीवरी (1-2 दिन)' : 'Express Priority Delivery (1-2 Days)'}
                      </h4>
                      <p className="text-xs text-[#4A4A4A] mt-0.5">
                        {language === 'hi' ? 'अर्जेंट सिलाई या गिफ्ट के लिए सुपरफास्ट डिलीवरी।' : 'Priority express shipping for urgent tailor stitching.'}
                      </p>
                    </div>
                  </div>
                  <span className="text-sm font-black text-[#111111]">
                    +₹49
                  </span>
                </div>
              </div>

              <div className="pt-3 flex gap-2">
                <button
                  type="button"
                  onClick={() => setCurrentStep(1)}
                  className="py-3 px-4 rounded-xl border border-[#E5E0D8] text-[#111111] font-bold text-sm cursor-pointer hover:bg-[#F7F5F0]"
                >
                  <ArrowLeft className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => setCurrentStep(3)}
                  className="flex-1 bg-[#111111] hover:bg-[#2B2B2B] text-white font-extrabold py-3.5 px-4 rounded-xl text-sm sm:text-base flex items-center justify-center gap-2 shadow-md transition cursor-pointer"
                >
                  <span>{language === 'hi' ? 'भुगतान के तरीके पर जाएं' : 'Continue to Payment'}</span>
                  <ArrowRight className="w-5 h-5 text-[#C8A96B]" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: Payment Method */}
          {currentStep === 3 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm sm:text-base font-bold text-[#111111] flex items-center gap-2">
                  <Banknote className="w-4 h-4 text-[#C8A96B]" />
                  <span>{language === 'hi' ? 'भुगतान का तरीका चुनें' : 'Choose Payment Method'}</span>
                </h3>
                <span className="text-xs text-[#777777] font-medium">Step 3 of 4</span>
              </div>

              <div className="space-y-3">
                {/* 1. PhonePe Payment Gateway (Official & Direct) */}
                <div
                  onClick={() => handleSelectPaymentMethod('phonepe')}
                  className={`p-4 rounded-xl border-2 transition flex flex-col gap-3 ${
                    paymentMethod === 'phonepe'
                      ? 'border-[#5f259f] bg-purple-50/40 shadow-sm ring-1 ring-[#5f259f]'
                      : 'border-[#E5E0D8] hover:bg-[#F7F5F0] cursor-pointer'
                  }`}
                >
                  <div className="flex items-start gap-3 w-full">
                    <div className="w-10 h-10 rounded-full bg-[#5f259f] flex items-center justify-center text-white shrink-0 mt-0.5 shadow-sm font-black text-sm">
                      पे
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <h4 className="text-sm font-extrabold text-[#111111]">
                          PhonePe Payment Gateway
                        </h4>
                        <span className="bg-[#5f259f] text-white text-[10px] font-extrabold px-2 py-0.5 rounded shadow-xs">
                          {language === 'hi' ? 'फोनपे गेटवे' : 'Official PG'}
                        </span>
                      </div>
                      <p className="text-xs text-[#4A4A4A] mt-1">
                        {language === 'hi'
                          ? 'PhonePe ऐप, UPI, कार्ड या नेटबैंकिंग द्वारा तुरंत सुरक्षित भुगतान'
                          : 'Instant secure checkout via PhonePe App, UPI, Debit/Credit Card or NetBanking'}
                      </p>
                    </div>
                    {paymentMethod === 'phonepe' && <Check className="w-5 h-5 text-[#5f259f] shrink-0" />}
                  </div>

                  {/* Expanded PhonePe Live Payment Panel when PhonePe is selected */}
                  {paymentMethod === 'phonepe' && (
                    <div className="mt-2 pt-3 border-t border-purple-200 space-y-3 bg-white p-3.5 rounded-xl border border-purple-100 shadow-xs">
                      {isLoadingPayment ? (
                        <div className="py-6 flex flex-col items-center justify-center gap-2 text-stone-500">
                          <Loader2 className="w-6 h-6 animate-spin text-[#5f259f]" />
                          <span className="text-xs font-semibold">{language === 'hi' ? 'फोनपे पेमेंट गेटवे लोड हो रहा है...' : 'Connecting to PhonePe Payment Gateway...'}</span>
                        </div>
                      ) : paymentSession ? (
                        <>
                          {/* Live Dynamic PhonePe QR Code */}
                          <div className="text-center space-y-2">
                            <div className="inline-block p-2 bg-white rounded-xl shadow-xs border-2 border-[#5f259f]/30">
                              <img 
                                src={paymentSession.upiQrCode} 
                                alt="PhonePe QR Code" 
                                className="w-44 h-44 sm:w-48 sm:h-48 mx-auto rounded-lg object-contain"
                              />
                            </div>
                            <div className="text-center">
                              <span className="text-xs font-extrabold text-[#5f259f] block">
                                {language === 'hi' ? `PhonePe से स्कैन करें — ₹${finalPayable}` : `Scan with PhonePe — ₹${finalPayable}`}
                              </span>
                              <span className="text-[11px] text-stone-500">
                                {language === 'hi' ? 'PhonePe या किसी भी UPI ऐप से भुगतान स्वीकार्य' : 'Accepted on PhonePe, GPay, Paytm, BHIM'}
                              </span>
                            </div>
                          </div>

                          {/* Direct PhonePe App Trigger for Mobile */}
                          <div className="space-y-1.5 pt-1">
                            <a
                              href={paymentSession.phonepeIntentUrl || paymentSession.upiIntentUrl}
                              className="w-full bg-[#5f259f] hover:bg-[#4a1c7d] text-white py-2.5 px-3 rounded-lg text-xs font-black flex items-center justify-center gap-2 shadow-sm transition active:scale-95"
                            >
                              <Smartphone className="w-4 h-4" />
                              <span>{language === 'hi' ? 'PhonePe ऐप में सीधे खोलें (Pay via PhonePe)' : 'Open Directly in PhonePe App'}</span>
                            </a>
                            {paymentSession.phonepeRedirectUrl && (
                              <a
                                href={paymentSession.phonepeRedirectUrl}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="w-full bg-white border border-[#5f259f] text-[#5f259f] hover:bg-purple-50 py-2 px-3 rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 transition"
                              >
                                <ExternalLink className="w-3.5 h-3.5" />
                                <span>{language === 'hi' ? 'PhonePe PG वेब पेज पर जाएं' : 'Open PhonePe Web Checkout'}</span>
                              </a>
                            )}
                          </div>

                          {/* Copy PhonePe UPI ID */}
                          <div className="flex items-center justify-between bg-purple-50/50 p-2.5 rounded-lg border border-purple-200 text-xs">
                            <div className="truncate mr-2">
                              <span className="text-[10px] text-purple-700 block uppercase font-bold">PhonePe Merchant VPA:</span>
                              <span className="font-mono font-bold text-stone-900 select-all">{paymentSession.merchantUpi}</span>
                            </div>
                            <button
                              type="button"
                              onClick={(e) => { e.stopPropagation(); handleCopyUpi(); }}
                              className="px-2.5 py-1.5 bg-white border border-purple-300 hover:bg-purple-50 rounded text-xs font-bold text-[#5f259f] flex items-center gap-1 shrink-0 cursor-pointer"
                            >
                              {copiedUpi ? (
                                <>
                                  <CheckCheck className="w-3.5 h-3.5 text-emerald-600" />
                                  <span className="text-emerald-700">Copied!</span>
                                </>
                              ) : (
                                <>
                                  <Copy className="w-3.5 h-3.5" />
                                  <span>Copy</span>
                                </>
                              )}
                            </button>
                          </div>

                          {/* UTR / Transaction ID */}
                          <div className="space-y-1">
                            <label className="text-[11px] font-bold text-[#111111] flex items-center justify-between">
                              <span>{language === 'hi' ? 'PhonePe UTR / Transaction ID (भुगतान के बाद):' : 'PhonePe UTR / Txn Ref Number:'}</span>
                              <span className="text-[10px] text-emerald-700 font-semibold bg-emerald-100 px-1.5 py-0.2 rounded">Auto Verified</span>
                            </label>
                            <input
                              type="text"
                              maxLength={16}
                              value={utrNumber}
                              onChange={(e) => { setUtrNumber(e.target.value); setUtrError(''); }}
                              onClick={(e) => e.stopPropagation()}
                              placeholder="e.g. T260930123456 or 12-digit UTR"
                              className="w-full px-3 py-2 text-xs border border-purple-200 rounded-lg focus:outline-none focus:ring-1 focus:ring-[#5f259f] font-mono bg-stone-50/50"
                            />
                            {utrError && <p className="text-[11px] text-red-600 font-medium">{utrError}</p>}
                          </div>
                        </>
                      ) : null}
                    </div>
                  )}
                </div>

                {/* 2. Cash on Delivery (Featured & Recommended) */}
                <div
                  onClick={() => handleSelectPaymentMethod('cod')}
                  className={`p-4 rounded-xl border-2 cursor-pointer transition flex items-start gap-3 ${
                    paymentMethod === 'cod'
                      ? 'border-[#111111] bg-[#F7F5F0] shadow-xs ring-1 ring-[#111111]'
                      : 'border-[#E5E0D8] hover:bg-[#F7F5F0]'
                  }`}
                >
                  <div className="w-9 h-9 rounded-full bg-white border border-[#E5E0D8] flex items-center justify-center text-[#111111] shrink-0 mt-0.5">
                    <Banknote className="w-5 h-5 text-[#C8A96B]" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h4 className="text-sm font-extrabold text-[#111111]">
                        {language === 'hi' ? 'कैश ऑन डिलीवरी (घर पर पैसे दें)' : 'Cash on Delivery (COD)'}
                      </h4>
                      <span className="bg-[#111111] text-white text-[10px] font-bold px-2 py-0.5 rounded border border-[#C8A96B]/40">
                        {language === 'hi' ? 'सबसे पसंदीदा' : 'Recommended'}
                      </span>
                    </div>
                    <p className="text-xs text-[#4A4A4A] mt-1">
                      {language === 'hi' 
                        ? 'कपड़ा जब आपके घर पहुंचे, तभी नकद पैसे दें। कोई अग्रिम पैसा नहीं।' 
                        : 'Pay cash when fabric is delivered at your doorstep. Zero advance payment.'}
                    </p>
                  </div>
                  {paymentMethod === 'cod' && <Check className="w-5 h-5 text-[#C8A96B] shrink-0" />}
                </div>

                {/* 2. UPI */}
                <div
                  onClick={() => handleSelectPaymentMethod('upi')}
                  className={`p-4 rounded-xl border-2 transition flex flex-col gap-3 ${
                    paymentMethod === 'upi'
                      ? 'border-[#111111] bg-[#F7F5F0] shadow-xs ring-1 ring-[#111111]'
                      : 'border-[#E5E0D8] hover:bg-[#F7F5F0] cursor-pointer'
                  }`}
                >
                  <div className="flex items-start gap-3 w-full">
                    <div className="w-9 h-9 rounded-full bg-white border border-[#E5E0D8] flex items-center justify-center text-[#111111] shrink-0 mt-0.5">
                      <QrCode className="w-5 h-5 text-[#C8A96B]" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <h4 className="text-sm font-bold text-[#111111]">
                          UPI (Google Pay, PhonePe, Paytm, BHIM)
                        </h4>
                        <span className="bg-[#EBF7EE] text-[#1B7938] text-[10px] font-bold px-2 py-0.5 rounded border border-[#1B7938]/30">
                          {language === 'hi' ? 'तुरंत' : 'Instant 0% Fee'}
                        </span>
                      </div>
                      <p className="text-xs text-[#4A4A4A] mt-1">
                        {language === 'hi' ? 'QR कोड स्कैन करें या सीधे UPI ऐप से भुगतान करें' : 'Scan dynamic QR or pay directly via any UPI app'}
                      </p>
                    </div>
                    {paymentMethod === 'upi' && <Check className="w-5 h-5 text-[#C8A96B] shrink-0" />}
                  </div>

                  {/* Expanded UPI Live Payment Panel when UPI is selected */}
                  {paymentMethod === 'upi' && (
                    <div className="mt-2 pt-3 border-t border-[#E5E0D8] space-y-3 bg-white p-3.5 rounded-xl border">
                      {isLoadingPayment ? (
                        <div className="py-6 flex flex-col items-center justify-center gap-2 text-stone-500">
                          <Loader2 className="w-6 h-6 animate-spin text-[#C8A96B]" />
                          <span className="text-xs font-semibold">{language === 'hi' ? 'डायनामिक QR कोड बन रहा है...' : 'Generating dynamic UPI QR code...'}</span>
                        </div>
                      ) : paymentSession ? (
                        <>
                          {/* Live Dynamic QR Code from Backend */}
                          <div className="text-center space-y-2">
                            <div className="inline-block p-2 bg-white rounded-xl shadow-xs border border-stone-200">
                              <img 
                                src={paymentSession.upiQrCode} 
                                alt="UPI Payment QR Code" 
                                className="w-44 h-44 sm:w-48 sm:h-48 mx-auto rounded-lg object-contain"
                              />
                            </div>
                            <div className="text-center">
                              <span className="text-xs font-bold text-[#111111] block">
                                {language === 'hi' ? `स्कैन करें और ₹${finalPayable} भुगतान करें` : `Scan & Pay ₹${finalPayable}`}
                              </span>
                              <span className="text-[11px] text-stone-500">
                                {language === 'hi' ? 'Google Pay, PhonePe, Paytm, BHIM किसी भी ऐप से' : 'Works with any UPI app on phone'}
                              </span>
                            </div>
                          </div>

                          {/* Quick UPI App Deep Links for Mobile Users */}
                          <div className="pt-1">
                            <span className="text-[11px] font-bold text-[#4A4A4A] uppercase tracking-wide block mb-1.5 text-center">
                              {language === 'hi' ? 'सीधे ऐप से भुगतान करें:' : 'Pay directly via App on this device:'}
                            </span>
                            <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                              <a
                                href={paymentSession.upiIntentUrl}
                                className="flex items-center justify-center gap-1.5 py-2 px-2 rounded-lg bg-stone-100 hover:bg-stone-200 text-xs font-bold text-stone-800 transition"
                              >
                                <span className="w-2 h-2 rounded-full bg-blue-500"></span>
                                <span>GPay</span>
                              </a>
                              <a
                                href={paymentSession.upiIntentUrl}
                                className="flex items-center justify-center gap-1.5 py-2 px-2 rounded-lg bg-stone-100 hover:bg-stone-200 text-xs font-bold text-stone-800 transition"
                              >
                                <span className="w-2 h-2 rounded-full bg-purple-600"></span>
                                <span>PhonePe</span>
                              </a>
                              <a
                                href={paymentSession.upiIntentUrl}
                                className="flex items-center justify-center gap-1.5 py-2 px-2 rounded-lg bg-stone-100 hover:bg-stone-200 text-xs font-bold text-stone-800 transition"
                              >
                                <span className="w-2 h-2 rounded-full bg-sky-500"></span>
                                <span>Paytm</span>
                              </a>
                              <a
                                href={paymentSession.upiIntentUrl}
                                className="flex items-center justify-center gap-1.5 py-2 px-2 rounded-lg bg-stone-100 hover:bg-stone-200 text-xs font-bold text-stone-800 transition"
                              >
                                <span className="w-2 h-2 rounded-full bg-emerald-600"></span>
                                <span>BHIM</span>
                              </a>
                            </div>
                          </div>

                          {/* Copy UPI ID */}
                          <div className="flex items-center justify-between bg-stone-50 p-2.5 rounded-lg border border-stone-200 text-xs">
                            <div className="truncate mr-2">
                              <span className="text-[10px] text-stone-500 block uppercase font-semibold">UPI ID:</span>
                              <span className="font-mono font-bold text-stone-800 select-all">{paymentSession.merchantUpi}</span>
                            </div>
                            <button
                              type="button"
                              onClick={(e) => { e.stopPropagation(); handleCopyUpi(); }}
                              className="px-2.5 py-1.5 bg-white border border-stone-300 hover:bg-stone-100 rounded text-xs font-bold text-stone-800 flex items-center gap-1 shrink-0 cursor-pointer"
                            >
                              {copiedUpi ? (
                                <>
                                  <CheckCheck className="w-3.5 h-3.5 text-emerald-600" />
                                  <span className="text-emerald-700">Copied!</span>
                                </>
                              ) : (
                                <>
                                  <Copy className="w-3.5 h-3.5" />
                                  <span>Copy</span>
                                </>
                              )}
                            </button>
                          </div>

                          {/* UTR Input */}
                          <div className="space-y-1">
                            <label className="text-[11px] font-bold text-[#111111] flex items-center justify-between">
                              <span>{language === 'hi' ? '12-अंकों का UTR / Transaction ID (भुगतान के बाद):' : '12-Digit UTR / Ref Number (After Payment):'}</span>
                              <span className="text-[10px] text-stone-400 font-normal">Optional / Auto</span>
                            </label>
                            <input
                              type="text"
                              maxLength={16}
                              value={utrNumber}
                              onChange={(e) => { setUtrNumber(e.target.value); setUtrError(''); }}
                              onClick={(e) => e.stopPropagation()}
                              placeholder="e.g. 429182910284"
                              className="w-full px-3 py-2 text-xs border border-stone-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-[#111111] font-mono"
                            />
                            {utrError && <p className="text-[11px] text-red-600 font-medium">{utrError}</p>}
                          </div>
                        </>
                      ) : (
                        <button
                          type="button"
                          onClick={(e) => { e.stopPropagation(); fetchPaymentSession('upi'); }}
                          className="w-full py-2 px-3 bg-stone-900 text-white rounded-lg text-xs font-bold"
                        >
                          {language === 'hi' ? 'QR कोड लोड करें' : 'Load QR Code'}
                        </button>
                      )}
                    </div>
                  )}
                </div>

                {/* 3. Card */}
                <div
                  onClick={() => handleSelectPaymentMethod('card')}
                  className={`p-4 rounded-xl border-2 cursor-pointer transition flex items-start gap-3 ${
                    paymentMethod === 'card'
                      ? 'border-[#111111] bg-[#F7F5F0] shadow-xs ring-1 ring-[#111111]'
                      : 'border-[#E5E0D8] hover:bg-[#F7F5F0]'
                  }`}
                >
                  <div className="w-9 h-9 rounded-full bg-white border border-[#E5E0D8] flex items-center justify-center text-[#111111] shrink-0 mt-0.5">
                    <CreditCard className="w-5 h-5 text-[#C8A96B]" />
                  </div>
                  <div className="flex-1">
                    <h4 className="text-sm font-bold text-[#111111]">
                      {language === 'hi' ? 'डेबिट / क्रेडिट कार्ड / एटीएम' : 'Debit / Credit Card (All Banks)'}
                    </h4>
                    <p className="text-xs text-[#4A4A4A] mt-1">
                      Visa, MasterCard, RuPay, Maestro accepted.
                    </p>
                  </div>
                  {paymentMethod === 'card' && <Check className="w-5 h-5 text-[#C8A96B] shrink-0" />}
                </div>
              </div>

              <div className="pt-3 flex gap-2">
                <button
                  type="button"
                  onClick={() => setCurrentStep(2)}
                  className="py-3 px-4 rounded-xl border border-[#E5E0D8] text-[#111111] font-bold text-sm cursor-pointer hover:bg-[#F7F5F0]"
                >
                  <ArrowLeft className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => setCurrentStep(4)}
                  className="flex-1 bg-[#111111] hover:bg-[#2B2B2B] text-white font-extrabold py-3.5 px-4 rounded-xl text-sm sm:text-base flex items-center justify-center gap-2 shadow-md transition cursor-pointer"
                >
                  <span>{language === 'hi' ? 'ऑर्डर की समीक्षा करें' : 'Review & Place Order'}</span>
                  <ArrowRight className="w-5 h-5 text-[#C8A96B]" />
                </button>
              </div>
            </div>
          )}

          {/* STEP 4: Review and Place Order */}
          {currentStep === 4 && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm sm:text-base font-bold text-[#111111]">
                  {language === 'hi' ? '4. ऑर्डर की समीक्षा करें और पुष्टि करें' : '4. Final Review & Place Order'}
                </h3>
                <span className="text-xs text-[#777777] font-medium">Final Step</span>
              </div>

              {/* Delivery Address Review */}
              <div className="bg-[#F7F5F0] p-3.5 rounded-xl border border-[#E5E0D8] text-xs space-y-1">
                <div className="flex justify-between items-center mb-1">
                  <span className="font-bold text-[#111111] uppercase tracking-wide">
                    {language === 'hi' ? 'डिलीवरी का पता:' : 'Delivery Address:'}
                  </span>
                  <button
                    onClick={() => setCurrentStep(1)}
                    className="text-[#111111] font-bold hover:text-[#C8A96B] hover:underline cursor-pointer"
                  >
                    {language === 'hi' ? 'बदलें' : 'Change'}
                  </button>
                </div>
                <p className="font-semibold text-[#111111]">{address.fullName} • {address.phoneNumber}</p>
                <p className="text-[#4A4A4A]">{address.houseFlat}, {address.roadArea}, {address.city}, {address.state} - {address.pincode}</p>
              </div>

              {/* Payment Method Review */}
              <div className="bg-[#F7F5F0] p-3.5 rounded-xl border border-[#E5E0D8] text-xs flex justify-between items-center">
                <div>
                  <span className="font-bold text-[#111111] block mb-0.5">
                    {language === 'hi' ? 'भुगतान का तरीका:' : 'Payment Mode:'}
                  </span>
                  <span className="text-[#4A4A4A] font-medium">
                    {paymentMethod === 'phonepe' 
                      ? 'PhonePe Payment Gateway (पेफोन ऑनलाइन)' 
                      : paymentMethod === 'cod' 
                      ? 'Cash on Delivery (घर पर नकद भुगतान)' 
                      : paymentMethod.toUpperCase()}
                  </span>
                </div>
                <button
                  onClick={() => setCurrentStep(3)}
                  className="text-[#111111] font-bold hover:text-[#C8A96B] hover:underline cursor-pointer"
                >
                  {language === 'hi' ? 'बदलें' : 'Change'}
                </button>
              </div>

              {/* Item Summaries */}
              <div className="space-y-2">
                <span className="text-xs font-bold text-[#111111] uppercase tracking-wide block">
                  {language === 'hi' ? 'ऑर्डर किए गए कपड़े:' : 'Fabrics in this Order:'}
                </span>
                {cart.map(item => (
                  <div key={item.cartItemId} className="flex items-center justify-between text-xs py-1 border-b border-[#E5E0D8]">
                    <span className="text-[#4A4A4A] font-medium truncate max-w-[260px]">
                      {item.quantity}x {item.product.name} (Size: {item.selectedLength.label.split('-')[0].trim()})
                    </span>
                    <span className="font-bold text-[#111111]">
                      ₹{Math.round(item.product.discountPrice * item.selectedLength.priceMultiplier) * item.quantity}
                    </span>
                  </div>
                ))}
              </div>

              {/* Final Price Card */}
              <div className="bg-[#F7F5F0] p-4 rounded-xl border border-[#E5E0D8] space-y-1.5 text-xs">
                <div className="flex justify-between text-[#4A4A4A]">
                  <span>{language === 'hi' ? 'कुल MRP:' : 'Total MRP:'}</span>
                  <span>₹{cartMRP}</span>
                </div>
                <div className="flex justify-between text-[#9B2C2C] font-semibold">
                  <span>{language === 'hi' ? 'कुल छूट (Discount):' : 'Discount:'}</span>
                  <span>- ₹{cartDiscount}</span>
                </div>
                <div className="flex justify-between text-[#4A4A4A]">
                  <span>{language === 'hi' ? 'डिलीवरी शुल्क:' : 'Delivery Fee:'}</span>
                  <span className={deliveryFee === 0 ? 'text-[#111111] font-bold' : ''}>
                    {deliveryFee === 0 ? (language === 'hi' ? 'मुफ्त (FREE)' : 'FREE') : `₹${deliveryFee}`}
                  </span>
                </div>
                <div className="border-t border-[#E5E0D8] pt-2 flex justify-between text-[#111111] font-black text-base">
                  <span>{language === 'hi' ? 'अंतिम देय राशि:' : 'Final Payable:'}</span>
                  <span className="text-lg">₹{finalPayable}</span>
                </div>
              </div>

              {/* Huge Action Button - Place Order */}
              <div className="pt-2">
                <button
                  type="button"
                  disabled={isVerifying}
                  onClick={handleConfirmOrder}
                  className="w-full bg-[#111111] hover:bg-[#2B2B2B] text-white font-black py-4 px-4 rounded-xl text-base sm:text-lg flex items-center justify-center gap-2 shadow-xl transition active:scale-95 cursor-pointer disabled:opacity-75 disabled:cursor-not-allowed"
                >
                  {isVerifying ? (
                    <>
                      <Loader2 className="w-6 h-6 animate-spin text-[#C8A96B]" />
                      <span>{language === 'hi' ? 'पेमेंट सत्यापित हो रहा है...' : 'Verifying with Payment Backend...'}</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-6 h-6 text-[#C8A96B]" />
                      <span>{language === 'hi' ? `ऑर्डर बुक करें — ₹${finalPayable}` : `Place Order Now — ₹${finalPayable}`}</span>
                    </>
                  )}
                </button>
              </div>

              <div className="flex items-center justify-center gap-2 text-[11px] text-[#777777] font-medium text-center">
                <ShieldCheck className="w-4 h-4 text-[#C8A96B] shrink-0" />
                <span>
                  {language === 'hi' 
                    ? '100% सुरक्षित • कपड़ा पसंद न आने पर 7 दिन में वापसी' 
                    : '100% Safe • 7 Days Easy Doorstep Return'}
                </span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
