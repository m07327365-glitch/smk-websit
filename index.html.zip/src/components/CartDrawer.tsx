import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import { 
  X, 
  Trash2, 
  ShoppingBag, 
  ArrowRight, 
  ShieldCheck, 
  Truck, 
  Tag, 
  Check,
  ChevronRight
} from 'lucide-react';

export const CartDrawer: React.FC = () => {
  const { 
    cart, 
    cartCount, 
    cartTotal, 
    cartMRP, 
    cartDiscount, 
    updateCartQuantity, 
    removeFromCart, 
    closeModal, 
    openModal, 
    language,
    t 
  } = useShop();

  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<string | null>(null);
  const [couponError, setCouponError] = useState('');

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (couponCode.trim().toUpperCase() === 'WELCOME100' || couponCode.trim().toUpperCase() === 'FESTIVE50') {
      setAppliedCoupon(couponCode.trim().toUpperCase());
      setCouponError('');
    } else {
      setCouponError(language === 'hi' ? 'अमान्य कूपन। WELCOME100 का उपयोग करें।' : 'Invalid code. Try WELCOME100');
    }
  };

  const couponDiscount = appliedCoupon === 'WELCOME100' ? 100 : (appliedCoupon === 'FESTIVE50' ? 50 : 0);
  const finalPayable = Math.max(0, cartTotal - couponDiscount);
  const totalSavings = cartDiscount + couponDiscount;

  const handleProceedToCheckout = () => {
    closeModal();
    openModal('checkout');
  };

  return (
    <div className="fixed inset-0 z-50 bg-stone-950/60 backdrop-blur-xs flex justify-end">
      <div className="bg-white w-full max-w-md h-full flex flex-col shadow-2xl animate-in slide-in-from-right duration-200">
        {/* Drawer Header */}
        <div className="p-4 sm:p-5 border-b border-[#E5E0D8] flex items-center justify-between bg-[#F7F5F0]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#111111] flex items-center justify-center text-[#C8A96B] shadow-2xs">
              <ShoppingBag className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-[#111111]">
                {language === 'hi' ? 'आपकी खरीदारी (Cart)' : 'My Shopping Bag'}
              </h2>
              <p className="text-xs text-[#777777]">
                {cartCount} {language === 'hi' ? 'कपड़े चुने गए हैं' : 'fabrics selected'}
              </p>
            </div>
          </div>
          <button
            onClick={closeModal}
            className="w-8 h-8 rounded-lg bg-white hover:bg-[#E5E0D8] text-[#111111] border border-[#E5E0D8] flex items-center justify-center transition cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Free Delivery Bar */}
        <div className="bg-[#F7F5F0] px-4 py-2 border-b border-[#E5E0D8] flex items-center gap-2 text-xs text-[#111111] font-semibold">
          <Truck className="w-4 h-4 text-[#C8A96B] shrink-0" />
          <span>
            {cartTotal >= 499 
              ? (language === 'hi' ? 'बधाई! इस ऑर्डर पर मुफ्त डिलीवरी लागू है।' : 'Congratulations! Free Delivery applies on this order.')
              : (language === 'hi' ? `मुफ्त डिलीवरी के लिए ₹${499 - cartTotal} का और कपड़ा जोड़ें` : `Add ₹${499 - cartTotal} more for FREE delivery`)}
          </span>
        </div>

        {/* Cart Item List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3.5 bg-white">
          {cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-4">
              <div className="w-16 h-16 rounded-full bg-[#F7F5F0] flex items-center justify-center text-[#777777] border border-[#E5E0D8]">
                <ShoppingBag className="w-8 h-8 text-[#C8A96B]" />
              </div>
              <div>
                <h3 className="text-base font-bold text-[#111111]">
                  {language === 'hi' ? 'आपकी कार्ट अभी खाली है' : 'Your Shopping Bag is Empty'}
                </h3>
                <p className="text-xs text-[#4A4A4A] mt-1 max-w-xs">
                  {language === 'hi' 
                    ? 'अपनी पसंद का शर्ट या पैंट का कपड़ा अभी कार्ट में जोड़ें।' 
                    : 'Explore pure cotton, linen and festive combo fabrics.'}
                </p>
              </div>
              <button
                onClick={closeModal}
                className="bg-[#111111] hover:bg-[#2B2B2B] text-white font-bold py-2.5 px-6 rounded-xl text-sm transition cursor-pointer shadow-sm"
              >
                {language === 'hi' ? 'कपड़े देखना शुरू करें' : 'Start Shopping'}
              </button>
            </div>
          ) : (
            cart.map((item) => {
              const itemPrice = Math.round(item.product.discountPrice * item.selectedLength.priceMultiplier);
              const itemMRP = Math.round(item.product.originalPrice * item.selectedLength.priceMultiplier);

              return (
                <div 
                  key={item.cartItemId}
                  className="flex gap-3 bg-[#F7F5F0]/60 p-3 rounded-xl border border-[#E5E0D8] relative"
                >
                  <img
                    src={item.selectedVariant?.image || item.product.image}
                    alt={item.product.name}
                    className="w-20 h-20 rounded-lg object-cover border border-[#E5E0D8] shrink-0 bg-white"
                  />

                  <div className="flex-1 min-w-0 flex flex-col justify-between">
                    <div>
                      <div className="flex items-start justify-between gap-1">
                        <h4 className="text-xs sm:text-sm font-bold text-[#111111] line-clamp-1">
                          {language === 'hi' ? item.product.nameHi : item.product.name}
                        </h4>
                        <button
                          onClick={() => removeFromCart(item.cartItemId)}
                          className="text-[#777777] hover:text-[#9B2C2C] transition p-0.5 cursor-pointer"
                          title="Remove item"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      <div className="flex items-center gap-2 text-xs text-[#4A4A4A] mt-1">
                        <span className="font-bold text-[#111111] bg-white border border-[#E5E0D8] px-2 py-0.5 rounded text-[11px]">
                          Size: {item.selectedLength.label.split('-')[0].trim()}
                        </span>
                        <span className="text-[11px] text-[#777777] truncate">
                          ({item.selectedLength.suitableFor})
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between mt-2">
                      <div className="flex items-baseline gap-1.5">
                        <span className="text-sm font-black text-[#111111]">
                          ₹{itemPrice * item.quantity}
                        </span>
                        <span className="text-[11px] text-[#777777] line-through">
                          ₹{itemMRP * item.quantity}
                        </span>
                      </div>

                      {/* Quantity Controls */}
                      <div className="flex items-center border border-[#E5E0D8] rounded-lg bg-white overflow-hidden">
                        <button
                          onClick={() => updateCartQuantity(item.cartItemId, -1)}
                          className="px-2.5 py-1 text-[#4A4A4A] hover:bg-[#F7F5F0] font-bold text-xs cursor-pointer"
                        >
                          -
                        </button>
                        <span className="px-2.5 py-1 text-xs font-bold text-[#111111] min-w-6 text-center">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => updateCartQuantity(item.cartItemId, 1)}
                          className="px-2.5 py-1 text-[#4A4A4A] hover:bg-[#F7F5F0] font-bold text-xs cursor-pointer"
                        >
                          +
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer Price Breakup & Checkout Button */}
        {cart.length > 0 && (
          <div className="p-4 sm:p-5 border-t border-[#E5E0D8] bg-[#F7F5F0] space-y-3.5">
            {/* Coupon Code Input */}
            <form onSubmit={handleApplyCoupon} className="space-y-1">
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Tag className="w-4 h-4 text-[#777777] absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={couponCode}
                    onChange={(e) => setCouponCode(e.target.value)}
                    placeholder={language === 'hi' ? 'कूपन कोड डालें (उदा. WELCOME100)' : 'Apply Coupon (e.g. WELCOME100)'}
                    className="w-full pl-9 pr-3 py-2 text-xs uppercase font-semibold bg-white border border-[#E5E0D8] rounded-xl focus:outline-none focus:ring-1 focus:ring-[#111111] text-[#111111]"
                  />
                </div>
                <button
                  type="submit"
                  className="bg-[#111111] hover:bg-[#2B2B2B] text-white text-xs font-bold px-4 py-2 rounded-xl transition cursor-pointer"
                >
                  {language === 'hi' ? 'लागू करें' : 'Apply'}
                </button>
              </div>
              {appliedCoupon && (
                <p className="text-xs text-[#111111] font-bold flex items-center gap-1">
                  <Check className="w-3.5 h-3.5 text-[#C8A96B]" />
                  {language === 'hi' ? `कूपन '${appliedCoupon}' लागू! ₹${couponDiscount} की अतिरिक्त छूट मिली।` : `Coupon '${appliedCoupon}' applied! Extra ₹${couponDiscount} saved.`}
                </p>
              )}
              {couponError && <p className="text-xs text-[#9B2C2C]">{couponError}</p>}
            </form>

            {/* Price Details */}
            <div className="bg-white p-3 rounded-xl border border-[#E5E0D8] space-y-1.5 text-xs">
              <div className="flex justify-between text-[#4A4A4A]">
                <span>{language === 'hi' ? 'कुल कपड़े की MRP:' : 'Total Fabric MRP:'}</span>
                <span>₹{cartMRP}</span>
              </div>
              <div className="flex justify-between text-[#9B2C2C] font-medium">
                <span>{language === 'hi' ? 'फैब्रिक छूट (Discount):' : 'Fabric Discount:'}</span>
                <span>- ₹{cartDiscount}</span>
              </div>
              {appliedCoupon && (
                <div className="flex justify-between text-[#9B2C2C] font-medium">
                  <span>{language === 'hi' ? 'कूपन छूट:' : 'Coupon Discount:'}</span>
                  <span>- ₹{couponDiscount}</span>
                </div>
              )}
              <div className="flex justify-between text-[#4A4A4A]">
                <span>{language === 'hi' ? 'डिलीवरी शुल्क:' : 'Delivery Charges:'}</span>
                <span className="text-[#111111] font-bold">{language === 'hi' ? 'मुफ्त (FREE)' : 'FREE'}</span>
              </div>
              <div className="border-t border-[#E5E0D8] pt-2 flex justify-between text-[#111111] font-black text-sm">
                <span>{language === 'hi' ? 'कुल देय राशि:' : 'Total Payable Amount:'}</span>
                <span className="text-base text-[#111111]">₹{finalPayable}</span>
              </div>
            </div>

            {/* Big Action Button */}
            <button
              onClick={handleProceedToCheckout}
              className="w-full bg-[#111111] hover:bg-[#2B2B2B] text-white font-extrabold py-3.5 px-4 rounded-xl text-sm sm:text-base flex items-center justify-center gap-2 shadow-lg transition active:scale-95 cursor-pointer"
            >
              <span>{language === 'hi' ? `ऑर्डर करने आगे बढ़ें (₹${finalPayable})` : `Proceed to Checkout (₹${finalPayable})`}</span>
              <ArrowRight className="w-5 h-5 text-[#C8A96B]" />
            </button>

            <div className="flex items-center justify-center gap-1.5 text-[11px] text-[#777777] font-medium">
              <ShieldCheck className="w-3.5 h-3.5 text-[#C8A96B]" />
              <span>{language === 'hi' ? 'सुरक्षित चेकआउट • घर पर नकद भुगतान उपलब्ध' : 'Safe Checkout • Cash on Delivery Available'}</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
