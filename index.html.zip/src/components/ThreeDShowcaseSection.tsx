import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import { ThreeDVideoPlayer } from './ThreeDVideoPlayer';
import { 
  Sparkles, 
  Tv, 
  RotateCw, 
  ShieldCheck, 
  CheckCircle2, 
  ArrowRight, 
  Eye, 
  Scissors, 
  Play
} from 'lucide-react';

export const ThreeDShowcaseSection: React.FC = () => {
  const { language, setSelectedCategory, openModal, products } = useShop();

  const handleShopCombos = () => {
    setSelectedCategory('combo');
  };

  const handleFeaturedProduct = () => {
    const featured = products.find(p => p.id === 'smk-01') || products[0];
    if (featured) {
      openModal('product', featured);
    }
  };

  return (
    <section className="max-w-7xl mx-auto px-4 py-2">
      <div className="bg-white rounded-2xl border border-[#E5E0D8] p-5 sm:p-8 shadow-xs overflow-hidden">
        {/* Header Label */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-6">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#111111] text-[#C8A96B] text-xs font-bold uppercase tracking-wider mb-2">
              <span className="w-2 h-2 rounded-full bg-[#C8A96B] animate-ping" />
              <Tv className="w-3.5 h-3.5 text-[#C8A96B]" />
              <span>{language === 'hi' ? '3D लाइव फैब्रिक वीडियो' : '3D Live Fabric Experience'}</span>
            </div>
            <h2 className="text-xl sm:text-3xl font-black text-[#111111] font-serif tracking-tight">
              {language === 'hi' 
                ? 'कपड़ा खरीदने से पहले 3D वीडियो में देखें असली फॉल और चमक' 
                : 'Experience Real Fabric Drape & Shine in 3D Motion'}
            </h2>
            <p className="text-xs sm:text-sm text-[#4A4A4A] mt-1 max-w-2xl">
              {language === 'hi' 
                ? 'रेमंड और सियाराम के असली कपड़े की 360° फिनिश, धागे की बुनाई और शानदार फॉल को लाइव 3D वीडियो व 3D स्टूडियो में चलाकर परखें।'
                : 'Inspect genuine Raymond & Siyaram fabrics with live 3D drape video, 360° interactive cloth simulation, and microscopic weave inspection.'}
            </p>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto">
            <button
              onClick={handleShopCombos}
              className="bg-[#111111] hover:bg-[#2B2B2B] text-white text-xs sm:text-sm font-bold px-4 py-2.5 rounded-xl transition flex items-center gap-1.5 cursor-pointer shadow active:scale-95"
            >
              <span>{language === 'hi' ? 'सभी 3D कॉम्बो देखें' : 'Explore All Combos'}</span>
              <ArrowRight className="w-4 h-4 text-[#C8A96B]" />
            </button>
          </div>
        </div>

        {/* Grid layout with 3D Video Player on Left/Center and Feature Points on Right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          {/* Main 3D Video & WebGL Canvas Player */}
          <div className="lg:col-span-8">
            <ThreeDVideoPlayer />
          </div>

          {/* Side Feature Highlights */}
          <div className="lg:col-span-4 space-y-4">
            <div className="bg-[#F7F5F0] rounded-xl p-4 border border-[#E5E0D8]">
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-lg bg-[#111111] text-[#C8A96B] flex items-center justify-center shrink-0 mt-0.5">
                  <Play className="w-4 h-4 fill-current" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-[#111111]">
                    {language === 'hi' ? 'लाइव 3D वीडियो प्लेबैक' : 'Live 3D Drape Video'}
                  </h4>
                  <p className="text-xs text-[#777777] mt-0.5">
                    {language === 'hi' 
                      ? 'असली कपड़े की चमक, खिंचाव और रिंकल-फ्री व्यवहार को मोशन वीडियो में देखें।' 
                      : 'High-definition 3D video showing natural cloth fall, crease-resistance and sheen.'}
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-[#F7F5F0] rounded-xl p-4 border border-[#E5E0D8]">
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-lg bg-[#111111] text-[#C8A96B] flex items-center justify-center shrink-0 mt-0.5">
                  <RotateCw className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-[#111111]">
                    {language === 'hi' ? '3D मॉडल पर सूट पहनकर देखें' : '3D Model Wearing Suit'}
                  </h4>
                  <p className="text-xs text-[#777777] mt-0.5">
                    {language === 'hi' 
                      ? '3D मॉडल को 360° घुमाकर देखें, रेमंड व सियाराम के कपड़े पहनाएं और असली फिटिंग जांचें।' 
                      : 'Rotate 3D model 360° to inspect bespoke lapel, chest drape, creased trousers & fit.'}
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-[#F7F5F0] rounded-xl p-4 border border-[#E5E0D8]">
              <div className="flex items-start gap-3">
                <div className="w-9 h-9 rounded-lg bg-[#111111] text-[#C8A96B] flex items-center justify-center shrink-0 mt-0.5">
                  <Scissors className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-sm font-bold text-[#111111]">
                    {language === 'hi' ? 'टेलर कटिंग गारंटी' : 'Tailor Ready Guarantee'}
                  </h4>
                  <p className="text-xs text-[#777777] mt-0.5">
                    {language === 'hi' 
                      ? 'पूरी नाप (2.25m x 1.20m, 2.25m, 1.20m)। कपड़े में कोई जोड़ या कट नहीं।' 
                      : 'Full measured cuts with zero joint cuts. Perfect for bespoke custom tailoring.'}
                  </p>
                </div>
              </div>
            </div>

            {/* Quick CTA Card */}
            <div className="bg-gradient-to-r from-[#111111] to-[#1E1E1E] rounded-xl p-4 text-white border border-[#2B2B2B]">
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-bold text-[#C8A96B] uppercase tracking-wider">
                  {language === 'hi' ? 'आज का सबसे लोकप्रिय 3D सेट' : 'Trending #1 Combo'}
                </span>
                <span className="bg-[#9B2C2C] text-white text-[10px] font-black px-2 py-0.5 rounded">
                  45% OFF
                </span>
              </div>
              <h5 className="font-bold text-sm text-white">
                {language === 'hi' ? 'रॉयल ब्लैक सफारी + कॉटन शर्ट कॉम्बो' : 'Royal Black Raymond Combo Cut'}
              </h5>
              <div className="flex items-center justify-between mt-3 pt-2 border-t border-[#2B2B2B]">
                <div>
                  <span className="text-lg font-black text-white">₹1,199</span>
                  <span className="text-xs line-through text-[#777777] ml-2">₹2,199</span>
                </div>
                <button
                  onClick={handleFeaturedProduct}
                  className="bg-[#C8A96B] hover:bg-[#b8985a] text-[#111111] font-bold px-3 py-1.5 rounded-lg text-xs transition cursor-pointer flex items-center gap-1 active:scale-95"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>{language === 'hi' ? 'अभी खरीदें' : 'Buy Now'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
