import React from 'react';
import { useShop } from '../context/ShopContext';
import { SearchBar } from './SearchBar';
import { 
  ShoppingBag, 
  User, 
  Package, 
  HelpCircle, 
  Languages, 
  PhoneCall, 
  Truck, 
  ShieldCheck,
  Scissors
} from 'lucide-react';

export const Header: React.FC = () => {
  const { 
    language, 
    setLanguage, 
    cartCount, 
    cartTotal,
    orders, 
    openModal, 
    setActiveTab, 
    user,
    setSelectedCategory,
    setSearchQuery,
    navigate
  } = useShop();

  const toggleLanguage = () => {
    setLanguage(language === 'en' ? 'hi' : 'en');
  };

  const handleHomeClick = () => {
    setActiveTab('home');
    setSelectedCategory('all');
    setSearchQuery('');
  };

  return (
    <header className="sticky top-0 z-40 bg-[#111111] border-b border-[#2B2B2B] shadow-md">
      {/* Top Announcement Bar */}
      <div className="bg-[#151515] text-[#D9D4CA] text-xs py-1.5 px-4 font-medium border-b border-[#222222]">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-4 text-[13px]">
            <span className="flex items-center gap-1.5">
              <Truck className="w-3.5 h-3.5 text-[#C8A96B]" />
              <span>{language === 'hi' ? 'घर पर पैसे दें (Cash on Delivery) उपलब्ध' : 'Cash on Delivery Available Across India'}</span>
            </span>
            <span className="hidden md:inline text-[#4A4A4A]">|</span>
            <span className="hidden md:flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-[#C8A96B]" />
              <span>{language === 'hi' ? '7 दिनों में आसान वापसी (Easy Returns)' : '7-Day Easy Returns & Exchange'}</span>
            </span>
          </div>

          <div className="flex items-center gap-4 ml-auto text-[13px]">
            <button 
              onClick={() => openModal('support')}
              className="flex items-center gap-1 text-[#D9D4CA] hover:text-white transition cursor-pointer"
            >
              <PhoneCall className="w-3 h-3 text-[#C8A96B]" />
              <span className="font-semibold">{language === 'hi' ? 'सहायता: 1800-200-5588' : 'Helpline: 1800-200-5588'}</span>
            </button>
            <span className="text-[#4A4A4A]">|</span>
            {/* Language Switcher */}
            <button
              onClick={toggleLanguage}
              className="flex items-center gap-1 bg-[#2B2B2B] hover:bg-[#383838] text-white px-2 py-0.5 rounded text-xs font-bold transition border border-[#444444] cursor-pointer"
              title="Change Language"
            >
              <Languages className="w-3 h-3 text-[#C8A96B]" />
              <span>{language === 'en' ? 'हिंदी में बदलें' : 'Switch to English'}</span>
            </button>
            <span className="text-[#4A4A4A]">|</span>
            {/* Direct Admin Portal Link */}
            <button
              onClick={() => navigate('/admin')}
              className="flex items-center gap-1 bg-[#2B2B2B] hover:bg-[#383838] text-[#C8A96B] hover:text-white px-2 py-0.5 rounded text-xs font-bold transition border border-[#C8A96B]/50 cursor-pointer"
              title="Open Store Owner Admin Panel"
            >
              <span>👑 {language === 'hi' ? 'दुकानदार एडमिन' : 'Admin Panel'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 py-3 sm:py-3.5">
        <div className="flex items-center justify-between gap-3 md:gap-6">
          {/* Logo & Store Name */}
          <button 
            onClick={handleHomeClick}
            className="flex items-center gap-2.5 text-left shrink-0 focus:outline-none group cursor-pointer"
          >
            <div className="w-10 h-10 sm:w-11 sm:h-11 rounded-xl bg-gradient-to-br from-[#2B2B2B] to-[#111111] flex items-center justify-center text-[#C8A96B] shadow-md border border-[#C8A96B]/40 group-hover:border-[#C8A96B] transition">
              <Scissors className="w-6 h-6 text-[#C8A96B] -rotate-45" />
            </div>
            <div>
              <div className="text-lg sm:text-xl md:text-2xl font-black tracking-tight text-white font-serif leading-none flex items-center gap-1.5">
                SHREE MARUTI KRUPA
              </div>
              <p className="text-[11px] sm:text-xs text-[#D9D4CA] font-semibold tracking-wider uppercase mt-0.5">
                {language === 'hi' ? 'सूटिंग व शर्टिंग फैब्रिक स्टोर' : 'Premium Suiting & Shirting'}
              </p>
            </div>
          </button>

          {/* Large Search Bar - Central Desktop */}
          <div className="hidden sm:flex flex-1 justify-center max-w-xl mx-2">
            <SearchBar />
          </div>

          {/* Desktop & Tablet Action Icons */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            {/* Track / My Orders */}
            <button
              onClick={() => setActiveTab('orders')}
              className="hidden lg:flex items-center gap-1.5 px-3 py-2 text-[#D9D4CA] hover:text-white hover:bg-[#2B2B2B] rounded-xl transition font-medium text-sm cursor-pointer"
            >
              <Package className="w-5 h-5 text-[#C8A96B]" />
              <div className="text-left leading-tight">
                <span className="block text-[11px] text-[#777777]">{language === 'hi' ? 'ऑर्डर ट्रैक करें' : 'Track'}</span>
                <span className="font-semibold text-xs text-white">{language === 'hi' ? 'मेरे ऑर्डर' : 'My Orders'}</span>
              </div>
              {orders.length > 0 && (
                <span className="w-2 h-2 rounded-full bg-[#C8A96B] animate-pulse ml-0.5"></span>
              )}
            </button>

            {/* Help / Support */}
            <button
              onClick={() => openModal('support')}
              className="hidden md:flex items-center gap-1.5 px-3 py-2 text-[#D9D4CA] hover:text-white hover:bg-[#2B2B2B] rounded-xl transition font-medium text-sm cursor-pointer"
            >
              <HelpCircle className="w-5 h-5 text-[#C8A96B]" />
              <div className="text-left leading-tight">
                <span className="block text-[11px] text-[#777777]">{language === 'hi' ? 'मदद' : 'Need Help?'}</span>
                <span className="font-semibold text-xs text-white">{language === 'hi' ? 'सहायता' : 'Support'}</span>
              </div>
            </button>

            {/* User Account */}
            <button
              onClick={() => setActiveTab('account')}
              className="hidden sm:flex items-center gap-1.5 px-3 py-2 text-[#D9D4CA] hover:text-white hover:bg-[#2B2B2B] rounded-xl transition font-medium text-sm cursor-pointer"
            >
              <User className="w-5 h-5 text-[#C8A96B]" />
              <div className="text-left leading-tight">
                <span className="block text-[11px] text-[#777777]">{language === 'hi' ? 'नमस्ते' : 'Hello'}</span>
                <span className="font-semibold text-xs text-white truncate max-w-[80px]">
                  {user.isLoggedIn ? user.name.split(' ')[0] : (language === 'hi' ? 'खाता' : 'Account')}
                </span>
              </div>
            </button>

            {/* Cart Button */}
            <button
              onClick={() => openModal('cartDrawer')}
              className="relative flex items-center gap-2.5 bg-[#2B2B2B] hover:bg-[#383838] border border-[#C8A96B]/50 text-white px-3.5 py-2.5 rounded-xl font-bold transition shadow-sm cursor-pointer active:scale-95"
              aria-label="Shopping Cart"
            >
              <div className="relative">
                <ShoppingBag className="w-5 h-5 text-[#C8A96B]" />
                {cartCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-[#9B2C2C] text-white text-[11px] font-black w-5 h-5 rounded-full flex items-center justify-center ring-2 ring-[#111111]">
                    {cartCount}
                  </span>
                )}
              </div>
              <div className="hidden sm:block text-left leading-none">
                <span className="text-[10px] text-[#C8A96B] uppercase font-semibold block">
                  {language === 'hi' ? 'कार्ट' : 'Cart'}
                </span>
                <span className="text-xs font-bold text-white">
                  {cartCount > 0 ? `₹${cartTotal}` : (language === 'hi' ? 'खाली' : '₹0')}
                </span>
              </div>
            </button>

            {/* Admin Portal Button */}
            <button
              onClick={() => navigate('/admin')}
              className="hidden md:flex items-center gap-1.5 bg-[#2B2B2B] hover:bg-[#383838] text-[#C8A96B] hover:text-white px-3 py-2 rounded-xl text-xs font-bold border border-[#C8A96B]/50 shadow-xs cursor-pointer transition"
              title="Admin Panel"
            >
              <span>👑 {language === 'hi' ? 'एडमिन' : 'Admin'}</span>
            </button>
          </div>
        </div>

        {/* Mobile Search Bar Row */}
        <div className="mt-2.5 sm:hidden">
          <SearchBar />
        </div>
      </div>
    </header>
  );
};
