import React from 'react';
import { useShop } from '../context/ShopContext';
import { Order } from '../types';
import { 
  Package, 
  Truck, 
  RotateCcw, 
  ChevronRight, 
  MapPin, 
  Calendar, 
  CheckCircle2, 
  ShoppingBag,
  ExternalLink
} from 'lucide-react';

export const OrdersView: React.FC = () => {
  const { orders, openModal, language, setSelectedOrderForTracking, setActiveTab } = useShop();

  const handleTrack = (order: Order) => {
    setSelectedOrderForTracking(order);
    openModal('tracking', order);
  };

  const handleReturn = (order: Order) => {
    openModal('return', { order, product: order.items[0]?.product });
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 sm:py-8">
      {/* Title */}
      <div className="flex items-center justify-between mb-6 pb-3 border-b border-[#E5E0D8]">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-[#111111] font-serif">
            {language === 'hi' ? 'मेरे ऑर्डर (My Orders)' : 'My Orders & Tracking'}
          </h2>
          <p className="text-xs sm:text-sm text-[#4A4A4A] mt-0.5">
            {language === 'hi' 
              ? 'यहाँ आप अपने ऑर्डर की स्थिति देख सकते हैं या आसानी से कपड़ा वापस कर सकते हैं।' 
              : 'Track current shipments or easily initiate 7-day doorstep returns.'}
          </p>
        </div>
      </div>

      {orders.length === 0 ? (
        <div className="bg-white rounded-2xl p-8 text-center border border-[#E5E0D8] shadow-2xs space-y-4">
          <div className="w-16 h-16 rounded-full bg-[#F7F5F0] border border-[#E5E0D8] text-[#C8A96B] flex items-center justify-center mx-auto">
            <Package className="w-8 h-8" />
          </div>
          <div>
            <h3 className="text-base font-bold text-[#111111]">
              {language === 'hi' ? 'अभी तक कोई ऑर्डर नहीं है' : 'No Orders Found'}
            </h3>
            <p className="text-xs text-[#777777] mt-1">
              {language === 'hi' 
                ? 'आपने अभी तक कोई कपड़ा ऑर्डर नहीं किया है। आज ही बेहतरीन कपड़े देखें।' 
                : 'Browse our collection of pure cotton shirtings and suiting combos.'}
            </p>
          </div>
          <button
            onClick={() => setActiveTab('home')}
            className="bg-[#111111] hover:bg-[#2B2B2B] text-white font-bold py-2.5 px-6 rounded-xl text-sm transition cursor-pointer"
          >
            {language === 'hi' ? 'कपड़े देखें (Shop Now)' : 'Shop Now'}
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {orders.map((order) => {
            return (
              <div 
                key={order.id}
                className="bg-white rounded-2xl border border-[#E5E0D8] shadow-2xs overflow-hidden transition hover:shadow-md"
              >
                {/* Order Top Bar */}
                <div className="bg-[#F7F5F0] p-4 border-b border-[#E5E0D8] flex flex-wrap items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-3">
                    <span className="font-bold text-[#111111] font-mono text-sm">
                      #{order.orderNumber}
                    </span>
                    <span className="text-[#E5E0D8]">|</span>
                    <span className="text-[#4A4A4A] flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-[#C8A96B]" />
                      {order.date}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="bg-white text-[#111111] border border-[#E5E0D8] font-bold px-2.5 py-1 rounded-md text-[11px] uppercase tracking-wide">
                      {order.status === 'out_for_delivery' 
                        ? (language === 'hi' ? 'डिलीवरी के लिए निकला है' : 'Out for Delivery')
                        : order.status === 'delivered' 
                        ? (language === 'hi' ? 'डिलीवर हुआ' : 'Delivered')
                        : (language === 'hi' ? 'ऑर्डर प्रोसेस में है' : 'In Progress')}
                    </span>
                    <span className="font-bold text-[#111111] text-sm">
                      ₹{order.totalPayable}
                    </span>
                  </div>
                </div>

                {/* Items in this order */}
                <div className="p-4 divide-y divide-[#E5E0D8] space-y-3">
                  {order.items.map((item) => (
                    <div key={item.cartItemId} className="flex items-center gap-3 pt-2 first:pt-0">
                      <img
                        src={item.product.image}
                        alt={item.product.name}
                        className="w-16 h-16 rounded-xl object-cover border border-[#E5E0D8] shrink-0"
                      />
                      <div className="flex-1 min-w-0">
                        <h4 className="text-sm font-bold text-[#111111] truncate">
                          {language === 'hi' ? item.product.nameHi : item.product.name}
                        </h4>
                        <div className="flex items-center gap-2 text-xs text-[#4A4A4A] mt-1">
                          <span className="font-bold text-[#111111] bg-[#F7F5F0] border border-[#E5E0D8] px-2 py-0.5 rounded text-[11px]">
                            Size: {item.selectedLength.label.split('-')[0].trim()}
                          </span>
                          <span>•</span>
                          <span>{language === 'hi' ? 'मात्रा:' : 'Qty:'} {item.quantity}</span>
                        </div>
                        <p className="text-xs text-[#777777] mt-1">
                          {language === 'hi' ? 'अनुमानित डिलीवरी:' : 'Expected Delivery:'}{' '}
                          <span className="font-semibold text-[#111111]">{order.expectedDelivery}</span>
                        </p>
                      </div>
                    </div>
                  ))}
                </div>

                {/* Return Banner if return requested */}
                {order.returnRequested && (
                  <div className="bg-[#F7F5F0] px-4 py-2.5 border-t border-[#E5E0D8] text-xs text-[#9B2C2C] flex items-center gap-2">
                    <RotateCcw className="w-4 h-4 text-[#9B2C2C] shrink-0" />
                    <span>
                      {language === 'hi'
                        ? `रिटर्न अनुरोध प्राप्त: कारण: "${order.returnReason}" • पिकअप कल होगा`
                        : `Return Initiated: "${order.returnReason}" • Doorstep Pickup Tomorrow`}
                    </span>
                  </div>
                )}

                {/* Primary Action Buttons */}
                <div className="bg-[#F7F5F0] p-3.5 border-t border-[#E5E0D8] flex flex-wrap items-center justify-between gap-2.5">
                  <div className="text-xs text-[#4A4A4A] flex items-center gap-1.5">
                    <Truck className="w-4 h-4 text-[#C8A96B]" />
                    <span>
                      {order.courierName} ({order.trackingNumber})
                    </span>
                  </div>

                  <div className="flex items-center gap-2 ml-auto">
                    {/* Track Order - Primary prominent button */}
                    <button
                      onClick={() => handleTrack(order)}
                      className="bg-[#111111] hover:bg-[#2B2B2B] text-white font-bold py-2 px-4 rounded-xl text-xs sm:text-sm flex items-center gap-1.5 shadow-xs transition cursor-pointer"
                    >
                      <Package className="w-4 h-4 text-[#C8A96B]" />
                      <span>{language === 'hi' ? 'ऑर्डर ट्रैक करें' : 'Track Order'}</span>
                    </button>

                    {/* Return Button */}
                    {!order.returnRequested && (
                      <button
                        onClick={() => handleReturn(order)}
                        className="bg-white hover:bg-[#F7F5F0] text-[#111111] border border-[#E5E0D8] font-bold py-2 px-3.5 rounded-xl text-xs sm:text-sm flex items-center gap-1.5 transition cursor-pointer"
                      >
                        <RotateCcw className="w-3.5 h-3.5 text-[#777777]" />
                        <span>{language === 'hi' ? 'वापसी (Return)' : 'Return'}</span>
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
