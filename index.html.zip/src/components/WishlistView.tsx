import React from 'react';
import { useShop } from '../context/ShopContext';
import { ProductCard } from './ProductCard';
import { Heart, ShoppingBag } from 'lucide-react';

export const WishlistView: React.FC = () => {
  const { wishlist, products, language, setActiveTab } = useShop();

  const savedProducts = products.filter(p => wishlist.includes(p.id));

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 sm:py-8">
      <div className="flex items-center justify-between mb-6 pb-3 border-b border-[#E5E0D8]">
        <div>
          <h2 className="text-xl sm:text-2xl font-black text-[#111111] font-serif flex items-center gap-2">
            <Heart className="w-6 h-6 text-[#9B2C2C] fill-[#9B2C2C]" />
            <span>{language === 'hi' ? 'मेरी पसंद के कपड़े (Wishlist)' : 'My Saved Fabrics (Wishlist)'}</span>
          </h2>
          <p className="text-xs sm:text-sm text-[#4A4A4A] mt-0.5">
            {language === 'hi' ? `${savedProducts.length} कपड़े पसंद किए गए हैं` : `${savedProducts.length} fabrics saved for later`}
          </p>
        </div>
      </div>

      {savedProducts.length === 0 ? (
        <div className="bg-white rounded-2xl p-10 text-center border border-[#E5E0D8] max-w-md mx-auto space-y-4 shadow-2xs">
          <div className="w-16 h-16 rounded-full bg-[#F7F5F0] border border-[#E5E0D8] text-[#9B2C2C] flex items-center justify-center mx-auto">
            <Heart className="w-8 h-8" />
          </div>
          <div>
            <h3 className="text-base font-bold text-[#111111]">
              {language === 'hi' ? 'विशलिस्ट में कोई कपड़ा नहीं है' : 'Your Wishlist is Empty'}
            </h3>
            <p className="text-xs text-[#777777] mt-1">
              {language === 'hi' 
                ? 'कपड़ा देखते समय दिल आइकन दबाकर पसंदीदा कपड़े यहाँ सहेजें।' 
                : 'Click the heart icon on any fabric card to save it here for later.'}
            </p>
          </div>
          <button
            onClick={() => setActiveTab('home')}
            className="bg-[#111111] hover:bg-[#2B2B2B] text-white font-bold py-2.5 px-6 rounded-xl text-sm transition cursor-pointer"
          >
            {language === 'hi' ? 'कपड़े देखना शुरू करें' : 'Browse Fabrics'}
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3.5 sm:gap-6">
          {savedProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}
    </div>
  );
};
