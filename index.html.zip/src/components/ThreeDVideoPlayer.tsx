import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  RotateCw, 
  Sparkles, 
  Layers, 
  Eye, 
  Tv, 
  Sliders,
  User,
  Camera,
  Check
} from 'lucide-react';
import { useShop } from '../context/ShopContext';

export interface VideoPresetItem {
  id: string;
  title: string;
  titleHi: string;
  desc: string;
  videoUrl: string;
  posterUrl: string;
  colorHex: string;
  tag: string;
}

interface ThreeDVideoPlayerProps {
  compact?: boolean;
  className?: string;
  onExploreProduct?: () => void;
}

export const DEFAULT_VIDEO_PRESETS: VideoPresetItem[] = [
  {
    id: 'drape-gold',
    title: '3D Luxury Fabric Flow & Drape',
    titleHi: '3D रॉयल फैब्रिक ड्रेप व फ्लो',
    desc: 'Pure Giza cotton & gold thread sheen in motion',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
    posterUrl: 'https://images.unsplash.com/photo-1617137984095-74e4e5e3613f?auto=format&fit=crop&w=1200&q=80',
    colorHex: '#C8A96B',
    tag: 'RAYMOND SPECIAL',
  },
  {
    id: 'suit-spin',
    title: '3D Tailored Suit 360° Showcase',
    titleHi: '3D स्यूटिंग व पैंट 360° फिनिश',
    desc: 'Handcrafted wrinkle-free Italian twill construction',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyBlazes.mp4',
    posterUrl: 'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?auto=format&fit=crop&w=1200&q=80',
    colorHex: '#111111',
    tag: 'SIYARAM TWILL',
  },
  {
    id: 'cotton-weave',
    title: '3D Microscopic Thread Weave',
    titleHi: '3D सूक्ष्म धागा बुनाई क्वालिटी',
    desc: 'High-density 120s double-twist breathable yarns',
    videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4',
    posterUrl: 'https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?auto=format&fit=crop&w=1200&q=80',
    colorHex: '#E5E0D8',
    tag: 'ARVIND PURE COTTON',
  }
];

export const loadVideoPresets = (): VideoPresetItem[] => {
  try {
    const saved = localStorage.getItem('smk_3d_video_config');
    if (saved) {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed) && parsed.length > 0) {
        return parsed;
      }
    }
  } catch (e) {
    console.error('Failed to load custom 3d video presets', e);
  }
  return DEFAULT_VIDEO_PRESETS;
};

// Fabric options for the 3D model wearing the cloth
const FABRICS_3D = [
  { id: 'offwhite-linen', name: 'Signature Off-White Linen', color: 0xECE7DE, roughness: 0.55, metalness: 0.05, sheen: '#ECE7DE', badge: 'Signature' },
  { id: 'black-raymond', name: 'Raymond Jet Black', color: 0x111111, roughness: 0.42, metalness: 0.15, sheen: '#111111', badge: 'Raymond' },
  { id: 'royal-gold', name: 'Imperial Gold Beige', color: 0xC8A96B, roughness: 0.32, metalness: 0.35, sheen: '#C8A96B', badge: 'Wedding' },
  { id: 'navy-siyaram', name: 'Siyaram Deep Navy', color: 0x16213e, roughness: 0.45, metalness: 0.15, sheen: '#16213e', badge: 'Siyaram' },
  { id: 'maroon-silk', name: 'Royal Wine Maroon', color: 0x5a1827, roughness: 0.38, metalness: 0.22, sheen: '#5a1827', badge: 'Festive' },
];

export const EXACT_HERO_MODEL_IMG = '/src/assets/images/hero_model_portrait_1790689718903.jpg';

export const ThreeDVideoPlayer: React.FC<ThreeDVideoPlayerProps> = ({ 
  compact = false, 
  className = '',
  onExploreProduct 
}) => {
  const { language, openModal, products } = useShop();

  const [videoList, setVideoList] = useState<VideoPresetItem[]>(loadVideoPresets);
  const [activeMode, setActiveMode] = useState<'signature_model' | 'interactive3d' | 'video'>('signature_model');
  const [modelType, setModelType] = useState<'mannequin' | 'cloth_wave'>('mannequin');
  const [selectedVideo, setSelectedVideo] = useState<VideoPresetItem>(() => videoList[0] || DEFAULT_VIDEO_PRESETS[0]);
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(true);
  const [autoRotate, setAutoRotate] = useState(true);
  const [cameraView, setCameraView] = useState<'full' | 'face' | 'chest' | 'trousers'>('full');
  const [videoError, setVideoError] = useState(false);
  
  // Listen for live updates from Admin Settings
  useEffect(() => {
    const handleUpdate = () => {
      const updated = loadVideoPresets();
      setVideoList(updated);
      setSelectedVideo(updated[0] || DEFAULT_VIDEO_PRESETS[0]);
      setVideoError(false);
    };
    window.addEventListener('smk_3d_video_updated', handleUpdate);
    return () => window.removeEventListener('smk_3d_video_updated', handleUpdate);
  }, []);

  // 3D Card mouse tilt effect for video mode
  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  const containerRef = useRef<HTMLDivElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // 3D WebGL Cloth state
  const [selectedFabric, setSelectedFabric] = useState(FABRICS_3D[0]);
  const [wireframe, setWireframe] = useState(false);

  // Ref tracking 3D Three.js scene instances
  const threeStateRef = useRef<{
    renderer?: THREE.WebGLRenderer;
    scene?: THREE.Scene;
    camera?: THREE.PerspectiveCamera;
    suitMaterials: THREE.MeshStandardMaterial[];
    waveMesh?: THREE.Mesh<THREE.PlaneGeometry, THREE.MeshStandardMaterial>;
    mannequinGroup?: THREE.Group;
    isDragging: boolean;
    prevMouseX: number;
    prevMouseY: number;
    rotX: number;
    rotY: number;
    reqId?: number;
  }>({
    suitMaterials: [],
    isDragging: false,
    prevMouseX: 0,
    prevMouseY: 0,
    rotX: 0.05,
    rotY: 0.1,
  });

  // Handle 3D Tilt on mouse move
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!containerRef.current || activeMode === 'interactive3d') return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width - 0.5) * 14;
    const y = -((e.clientY - rect.top) / rect.height - 0.5) * 14;
    setTilt({ x: y, y: x });
  };

  const handleMouseLeave = () => {
    setTilt({ x: 0, y: 0 });
  };

  // Toggle Video Play/Pause
  const togglePlay = () => {
    if (!videoRef.current) return;
    if (videoRef.current.paused) {
      videoRef.current.play().then(() => setIsPlaying(true)).catch(() => {});
    } else {
      videoRef.current.pause();
      setIsPlaying(false);
    }
  };

  // Toggle Mute
  const toggleMute = () => {
    if (!videoRef.current) return;
    videoRef.current.muted = !videoRef.current.muted;
    setIsMuted(videoRef.current.muted);
  };

  // Smooth camera view transitions
  useEffect(() => {
    if (!threeStateRef.current.camera) return;
    const cam = threeStateRef.current.camera;
    if (cameraView === 'full') {
      cam.position.set(0, -0.1, 4.3);
      cam.lookAt(0, -0.15, 0);
    } else if (cameraView === 'face') {
      cam.position.set(0, 1.48, 1.7);
      cam.lookAt(0, 1.48, 0);
    } else if (cameraView === 'chest') {
      cam.position.set(0, 0.75, 2.7);
      cam.lookAt(0, 0.75, 0);
    } else if (cameraView === 'trousers') {
      cam.position.set(0, -1.05, 2.9);
      cam.lookAt(0, -1.05, 0);
    }
  }, [cameraView]);

  // Initialize WebGL 3D Model Scene
  useEffect(() => {
    if (activeMode !== 'interactive3d' || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const width = canvas.clientWidth || 400;
    const height = canvas.clientHeight || 300;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x111111);

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(0, -0.1, 4.3);
    camera.lookAt(0, -0.15, 0);

    const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.35;
    renderer.shadowMap.enabled = true;

    // --- LIGHTING SETUP (LUXURY ATELIER LIGHTING) ---
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    scene.add(ambientLight);

    // Warm golden key light (#C8A96B)
    const goldKeyLight = new THREE.DirectionalLight(0xC8A96B, 2.4);
    goldKeyLight.position.set(3, 4, 3.5);
    scene.add(goldKeyLight);

    // Soft cool fill light
    const fillLight = new THREE.DirectionalLight(0xd4e2f5, 1.2);
    fillLight.position.set(-3.5, 1, 2);
    scene.add(fillLight);

    // Rim back light for masculine suit silhouette
    const rimLight = new THREE.PointLight(0xffffff, 2.2, 10);
    rimLight.position.set(0, 2.5, -2.5);
    scene.add(rimLight);

    // Bottom soft uplight for shoes & trousers
    const bottomLight = new THREE.PointLight(0xC8A96B, 0.8, 6);
    bottomLight.position.set(0, -2, 2);
    scene.add(bottomLight);

    // Materials array to update when fabric changes
    const suitMaterials: THREE.MeshStandardMaterial[] = [];

    // Master Suit Fabric Material (Applied to jacket, lapels, sleeves, pants)
    const suitMat = new THREE.MeshStandardMaterial({
      color: selectedFabric.color,
      roughness: selectedFabric.roughness,
      metalness: selectedFabric.metalness,
      wireframe: wireframe,
      side: THREE.DoubleSide,
    });
    suitMaterials.push(suitMat);

    // Gold brass accents (#C8A96B)
    const goldMat = new THREE.MeshStandardMaterial({
      color: 0xC8A96B,
      metalness: 0.9,
      roughness: 0.22,
    });

    // Pure white crisp formal shirting
    const shirtMat = new THREE.MeshStandardMaterial({
      color: 0xF7F5F0,
      roughness: 0.55,
      metalness: 0.05,
      wireframe: wireframe,
    });

    // Silk tie material
    const tieMat = new THREE.MeshStandardMaterial({
      color: 0x151515,
      roughness: 0.35,
      metalness: 0.25,
    });

    // Mannequin Head & Wood/Dark Chrome Body
    const skinMat = new THREE.MeshStandardMaterial({
      color: 0xdca882,
      roughness: 0.65,
      metalness: 0.04,
    });

    const hairMat = new THREE.MeshStandardMaterial({
      color: 0x1e1511,
      roughness: 0.52,
      metalness: 0.08,
    });

    const eyeWhiteMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.2 });
    const irisMat = new THREE.MeshStandardMaterial({ color: 0x3d2011, roughness: 0.3 });
    const pupilMat = new THREE.MeshBasicMaterial({ color: 0x000000 });
    const browMat = new THREE.MeshStandardMaterial({ color: 0x1c120e, roughness: 0.7 });
    const lipsMat = new THREE.MeshStandardMaterial({ color: 0xb77065, roughness: 0.55 });

    // Polished Oxford shoes
    const shoeMat = new THREE.MeshStandardMaterial({
      color: 0x090909,
      roughness: 0.2,
      metalness: 0.4,
    });

    // --- 1. BUILD THE 3D HUMAN GENTLEMAN MODEL WEARING SUIT ---
    const humanGroup = new THREE.Group();

    // Studio Luxury Floor Disc (Gentleman stands on this platform)
    const studioFloorMesh = new THREE.Mesh(
      new THREE.CylinderGeometry(1.2, 1.25, 0.06, 36),
      new THREE.MeshStandardMaterial({ color: 0x161616, roughness: 0.3, metalness: 0.2 })
    );
    studioFloorMesh.position.y = -1.82;
    humanGroup.add(studioFloorMesh);

    // Gold rim around studio platform
    const goldRimMesh = new THREE.Mesh(
      new THREE.TorusGeometry(1.22, 0.02, 16, 48),
      goldMat
    );
    goldRimMesh.rotation.x = Math.PI / 2;
    goldRimMesh.position.y = -1.79;
    humanGroup.add(goldRimMesh);

    // --- HUMAN HEAD, FACE & HAIR ---
    const headGroup = new THREE.Group();
    headGroup.position.set(0, 1.48, 0);

    // Human Neck
    const neckMesh = new THREE.Mesh(
      new THREE.CylinderGeometry(0.14, 0.17, 0.32, 20),
      skinMat
    );
    neckMesh.position.y = -0.16;
    headGroup.add(neckMesh);

    // Cranium / Head oval
    const craniumGeom = new THREE.SphereGeometry(0.24, 28, 24);
    craniumGeom.scale(0.9, 1.15, 0.95);
    const craniumMesh = new THREE.Mesh(craniumGeom, skinMat);
    headGroup.add(craniumMesh);

    // Masculine Jaw & Chin
    const jawGeom = new THREE.CylinderGeometry(0.18, 0.12, 0.2, 16);
    jawGeom.scale(0.88, 1, 1.1);
    const jawMesh = new THREE.Mesh(jawGeom, skinMat);
    jawMesh.position.set(0, -0.12, 0.06);
    headGroup.add(jawMesh);

    const chinMesh = new THREE.Mesh(new THREE.SphereGeometry(0.06, 16, 16), skinMat);
    chinMesh.position.set(0, -0.22, 0.16);
    headGroup.add(chinMesh);

    // Styled Gentleman Pompadour Haircut
    const hairTopGeom = new THREE.SphereGeometry(0.255, 24, 20);
    hairTopGeom.scale(0.94, 1.05, 1.05);
    const hairTop = new THREE.Mesh(hairTopGeom, hairMat);
    hairTop.position.set(0, 0.08, -0.02);
    headGroup.add(hairTop);

    // Hair Quiff / Crest
    const hairQuiffGeom = new THREE.BoxGeometry(0.32, 0.14, 0.22);
    const hairQuiff = new THREE.Mesh(hairQuiffGeom, hairMat);
    hairQuiff.position.set(0.02, 0.22, 0.08);
    hairQuiff.rotation.set(0.25, 0.1, -0.05);
    headGroup.add(hairQuiff);

    // Sideburns
    const sideburnL = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.14, 0.06), hairMat);
    sideburnL.position.set(-0.21, -0.04, 0.04);
    headGroup.add(sideburnL);

    const sideburnR = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.14, 0.06), hairMat);
    sideburnR.position.set(0.21, -0.04, 0.04);
    headGroup.add(sideburnR);

    // Human Eyes (Left & Right)
    const createEye = (x: number) => {
      const eyeGroup = new THREE.Group();
      eyeGroup.position.set(x, 0.03, 0.2);

      const sclera = new THREE.Mesh(new THREE.SphereGeometry(0.032, 16, 16), eyeWhiteMat);
      sclera.scale.set(1.2, 0.8, 0.8);
      eyeGroup.add(sclera);

      const iris = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.01, 16), irisMat);
      iris.rotation.x = Math.PI / 2;
      iris.position.z = 0.026;
      eyeGroup.add(iris);

      const pupil = new THREE.Mesh(new THREE.CylinderGeometry(0.009, 0.009, 0.012, 16), pupilMat);
      pupil.rotation.x = Math.PI / 2;
      pupil.position.z = 0.028;
      eyeGroup.add(pupil);

      const glint = new THREE.Mesh(new THREE.SphereGeometry(0.004, 8, 8), eyeWhiteMat);
      glint.position.set(0.006, 0.006, 0.032);
      eyeGroup.add(glint);

      const eyelid = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.012, 0.02), skinMat);
      eyelid.position.set(0, 0.03, 0.02);
      eyeGroup.add(eyelid);

      return eyeGroup;
    };

    headGroup.add(createEye(-0.085));
    headGroup.add(createEye(0.085));

    // Groomed Dark Eyebrows
    const browGeom = new THREE.BoxGeometry(0.085, 0.018, 0.02);
    
    const browL = new THREE.Mesh(browGeom, browMat);
    browL.position.set(-0.085, 0.09, 0.22);
    browL.rotation.z = -0.1;
    headGroup.add(browL);

    const browR = new THREE.Mesh(browGeom, browMat);
    browR.position.set(0.085, 0.09, 0.22);
    browR.rotation.z = 0.1;
    headGroup.add(browR);

    // Sculpted Nose
    const noseBridge = new THREE.Mesh(new THREE.BoxGeometry(0.032, 0.1, 0.045), skinMat);
    noseBridge.position.set(0, -0.02, 0.24);
    noseBridge.rotation.x = -0.18;
    headGroup.add(noseBridge);

    const noseTip = new THREE.Mesh(new THREE.SphereGeometry(0.025, 14, 14), skinMat);
    noseTip.position.set(0, -0.065, 0.26);
    headGroup.add(noseTip);

    // Lips with confident gentle smile
    const lipUpper = new THREE.Mesh(new THREE.BoxGeometry(0.075, 0.014, 0.02), lipsMat);
    lipUpper.position.set(0, -0.13, 0.22);
    headGroup.add(lipUpper);

    const lipLower = new THREE.Mesh(new THREE.BoxGeometry(0.065, 0.016, 0.02), lipsMat);
    lipLower.position.set(0, -0.155, 0.215);
    headGroup.add(lipLower);

    // Human Ears
    const earGeom = new THREE.BoxGeometry(0.035, 0.12, 0.06);
    
    const earL = new THREE.Mesh(earGeom, skinMat);
    earL.position.set(-0.22, 0, 0);
    earL.rotation.y = -0.2;
    headGroup.add(earL);

    const earR = new THREE.Mesh(earGeom, skinMat);
    earR.position.set(0.22, 0, 0);
    earR.rotation.y = 0.2;
    headGroup.add(earR);

    humanGroup.add(headGroup);

    // --- 1. TEXTURED LINEN SHIRT (WEARING SELECTED FABRIC) ---
    // Shirt Torso / Body
    const shirtTorsoGeom = new THREE.CylinderGeometry(0.48, 0.44, 1.32, 24);
    shirtTorsoGeom.scale(1.10, 1, 0.80);
    const shirtTorsoMesh = new THREE.Mesh(shirtTorsoGeom, suitMat);
    shirtTorsoMesh.position.set(0, 0.55, 0);
    humanGroup.add(shirtTorsoMesh);

    // Natural Shoulders
    const shoulderMesh = new THREE.Mesh(new THREE.BoxGeometry(1.36, 0.16, 0.46), suitMat);
    shoulderMesh.position.set(0, 1.15, 0);
    humanGroup.add(shoulderMesh);

    // Open Casual Shirt Collar (Unbuttoned casual V-neck as in photo)
    const collarLeft = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.12, 0.04), suitMat);
    collarLeft.position.set(-0.11, 1.22, 0.19);
    collarLeft.rotation.set(0.18, 0.35, -0.32);
    humanGroup.add(collarLeft);

    const collarRight = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.12, 0.04), suitMat);
    collarRight.position.set(0.11, 1.22, 0.19);
    collarRight.rotation.set(0.18, -0.35, 0.32);
    humanGroup.add(collarRight);

    // Open V-Neck skin peeking under collar
    const neckSkinMesh = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.16, 4), skinMat);
    neckSkinMesh.rotation.z = Math.PI;
    neckSkinMesh.position.set(0, 1.16, 0.20);
    humanGroup.add(neckSkinMesh);

    // Vertical Button Placket down the front
    const placketMesh = new THREE.Mesh(new THREE.BoxGeometry(0.055, 1.24, 0.02), suitMat);
    placketMesh.position.set(0, 0.55, 0.21);
    humanGroup.add(placketMesh);

    // Shirt Pearl Buttons
    const shirtButtonMat = new THREE.MeshStandardMaterial({ color: 0xE8DFD5, roughness: 0.3 });
    const buttonGeom = new THREE.CylinderGeometry(0.018, 0.018, 0.015, 16);
    buttonGeom.rotateX(Math.PI / 2);
    for (let b = 0; b < 5; b++) {
      const btn = new THREE.Mesh(buttonGeom, shirtButtonMat);
      btn.position.set(0, 0.98 - b * 0.22, 0.22);
      humanGroup.add(btn);
    }

    // Left Chest Pocket
    const pocketMesh = new THREE.Mesh(new THREE.BoxGeometry(0.14, 0.15, 0.02), suitMat);
    pocketMesh.position.set(-0.24, 0.82, 0.21);
    humanGroup.add(pocketMesh);

    // Untucked Curved Hem curving naturally over trousers
    const hemGeom = new THREE.CylinderGeometry(0.44, 0.47, 0.22, 24);
    hemGeom.scale(1.08, 1, 0.82);
    const hemMesh = new THREE.Mesh(hemGeom, suitMat);
    hemMesh.position.set(0, -0.16, 0);
    humanGroup.add(hemMesh);

    // --- 2. ROLLED-UP SLEEVES, BARE FOREARMS, WATCH & HAND-IN-POCKET POSE ---
    // A. LEFT ARM (Folded Sleeve, Wristwatch, Hand Tucked in Pocket)
    const upperSleeveL = new THREE.Mesh(
      new THREE.CylinderGeometry(0.14, 0.125, 0.65, 16),
      suitMat
    );
    upperSleeveL.position.set(-0.64, 0.84, 0.02);
    upperSleeveL.rotation.z = 0.20;
    humanGroup.add(upperSleeveL);

    // Rolled Cuff on Left Elbow
    const cuffRollL = new THREE.Mesh(
      new THREE.CylinderGeometry(0.145, 0.135, 0.11, 16),
      suitMat
    );
    cuffRollL.position.set(-0.70, 0.50, 0.03);
    cuffRollL.rotation.z = 0.20;
    humanGroup.add(cuffRollL);

    // Bare Forearm (Skin tone)
    const forearmL = new THREE.Mesh(
      new THREE.CylinderGeometry(0.10, 0.08, 0.70, 16),
      skinMat
    );
    forearmL.position.set(-0.59, 0.18, 0.08);
    forearmL.rotation.set(-0.16, 0, -0.28);
    humanGroup.add(forearmL);

    // Classic Wristwatch on Left Wrist (Black Strap & Gold Dial)
    const watchStrap = new THREE.Mesh(
      new THREE.CylinderGeometry(0.085, 0.085, 0.04, 16),
      new THREE.MeshStandardMaterial({ color: 0x161616, roughness: 0.4 })
    );
    watchStrap.position.set(-0.50, -0.06, 0.11);
    watchStrap.rotation.z = -0.28;
    humanGroup.add(watchStrap);

    const watchDial = new THREE.Mesh(
      new THREE.CylinderGeometry(0.038, 0.038, 0.018, 16),
      goldMat
    );
    watchDial.rotation.x = Math.PI / 2;
    watchDial.position.set(-0.52, -0.06, 0.15);
    humanGroup.add(watchDial);

    // Left Hand tucked inside trouser pocket!
    const handLeftPocket = new THREE.Mesh(
      new THREE.BoxGeometry(0.075, 0.11, 0.045),
      skinMat
    );
    handLeftPocket.position.set(-0.42, -0.20, 0.13);
    handLeftPocket.rotation.set(-0.1, 0.2, -0.32);
    humanGroup.add(handLeftPocket);

    // B. RIGHT ARM (Folded Sleeve, Bare Forearm, Relaxed Hand at Side)
    const upperSleeveR = new THREE.Mesh(
      new THREE.CylinderGeometry(0.14, 0.125, 0.65, 16),
      suitMat
    );
    upperSleeveR.position.set(0.64, 0.84, 0.02);
    upperSleeveR.rotation.z = -0.16;
    humanGroup.add(upperSleeveR);

    // Rolled Cuff on Right Elbow
    const cuffRollR = new THREE.Mesh(
      new THREE.CylinderGeometry(0.145, 0.135, 0.11, 16),
      suitMat
    );
    cuffRollR.position.set(0.70, 0.50, 0.02);
    cuffRollR.rotation.z = -0.16;
    humanGroup.add(cuffRollR);

    // Bare Right Forearm (Skin tone)
    const forearmR = new THREE.Mesh(
      new THREE.CylinderGeometry(0.10, 0.08, 0.70, 16),
      skinMat
    );
    forearmR.position.set(0.75, 0.15, 0.02);
    forearmR.rotation.z = -0.12;
    humanGroup.add(forearmR);

    // Relaxed Right Human Hand
    const handRightGroup = new THREE.Group();
    handRightGroup.position.set(0.80, -0.24, 0.02);
    
    const palmR = new THREE.Mesh(new THREE.BoxGeometry(0.07, 0.12, 0.035), skinMat);
    handRightGroup.add(palmR);

    const thumbR = new THREE.Mesh(new THREE.BoxGeometry(0.022, 0.06, 0.022), skinMat);
    thumbR.position.set(-0.035, 0.02, 0.02);
    thumbR.rotation.z = 0.35;
    handRightGroup.add(thumbR);

    const fingersR = new THREE.Mesh(new THREE.BoxGeometry(0.06, 0.08, 0.028), skinMat);
    fingersR.position.set(0.005, -0.075, 0.005);
    handRightGroup.add(fingersR);

    humanGroup.add(handRightGroup);

    // --- 3. CHARCOAL SLATE GREY TAILORED TROUSERS ---
    const trouserMat = new THREE.MeshStandardMaterial({
      color: 0x343940, // Signature Charcoal Slate Grey from photo!
      roughness: 0.52,
      metalness: 0.10,
    });

    // Trouser Waist & Hips
    const waistGeom = new THREE.CylinderGeometry(0.44, 0.42, 0.22, 24);
    waistGeom.scale(1.05, 1, 0.85);
    const waistMesh = new THREE.Mesh(waistGeom, trouserMat);
    waistMesh.position.set(0, -0.28, 0);
    humanGroup.add(waistMesh);

    // Left Pocket Opening Slit (where left hand rests)
    const pocketOpeningL = new THREE.Mesh(
      new THREE.BoxGeometry(0.02, 0.16, 0.07),
      new THREE.MeshStandardMaterial({ color: 0x24282f, roughness: 0.6 })
    );
    pocketOpeningL.position.set(-0.41, -0.20, 0.12);
    pocketOpeningL.rotation.y = 0.25;
    humanGroup.add(pocketOpeningL);

    // Left & Right Tailored Trouser Legs
    const legGeom = new THREE.CylinderGeometry(0.185, 0.145, 1.40, 16);
    
    const leftLeg = new THREE.Mesh(legGeom, trouserMat);
    leftLeg.position.set(-0.21, -0.98, 0);
    humanGroup.add(leftLeg);

    const rightLeg = new THREE.Mesh(legGeom, trouserMat);
    rightLeg.position.set(0.21, -0.98, 0);
    humanGroup.add(rightLeg);

    // Front Crease Lines
    const creaseGeom = new THREE.BoxGeometry(0.012, 1.34, 0.025);
    const creaseLeft = new THREE.Mesh(creaseGeom, trouserMat);
    creaseLeft.position.set(-0.21, -0.98, 0.165);
    humanGroup.add(creaseLeft);

    const creaseRight = new THREE.Mesh(creaseGeom, trouserMat);
    creaseRight.position.set(0.21, -0.98, 0.165);
    humanGroup.add(creaseRight);

    // --- 4. CLEAN MINIMALIST WHITE SNEAKERS (AS IN PHOTO) ---
    const sneakerMat = new THREE.MeshStandardMaterial({
      color: 0xF8F8F8,
      roughness: 0.28,
      metalness: 0.04,
    });
    const soleMat = new THREE.MeshStandardMaterial({
      color: 0xEAEAEA,
      roughness: 0.65,
    });

    const createSneaker = (x: number) => {
      const shoeGroup = new THREE.Group();
      shoeGroup.position.set(x, -1.72, 0.08);

      // Sneaker Upper
      const upper = new THREE.Mesh(new THREE.BoxGeometry(0.165, 0.105, 0.38), sneakerMat);
      shoeGroup.add(upper);

      // White Rubber Sole
      const sole = new THREE.Mesh(new THREE.BoxGeometry(0.175, 0.032, 0.40), soleMat);
      sole.position.y = -0.055;
      shoeGroup.add(sole);

      // Rounded Toe Cap
      const toe = new THREE.Mesh(new THREE.SphereGeometry(0.082, 16, 12), sneakerMat);
      toe.scale.set(1, 0.65, 1.1);
      toe.position.set(0, -0.01, 0.14);
      shoeGroup.add(toe);

      // Laces
      const laces = new THREE.Mesh(
        new THREE.BoxGeometry(0.075, 0.015, 0.13),
        new THREE.MeshStandardMaterial({ color: 0xFFFFFF })
      );
      laces.position.set(0, 0.054, 0.02);
      shoeGroup.add(laces);

      return shoeGroup;
    };

    humanGroup.add(createSneaker(-0.21));
    humanGroup.add(createSneaker(0.21));

    // --- 5. BOUTIQUE SHOWROOM MIRROR IN 3D SCENE BACKGROUND ---
    const mirrorFrame = new THREE.Mesh(
      new THREE.BoxGeometry(2.4, 4.2, 0.08),
      new THREE.MeshStandardMaterial({ color: 0x221B16, roughness: 0.4 })
    );
    mirrorFrame.position.set(0.65, 0.3, -1.6);
    scene.add(mirrorFrame);

    const mirrorGlass = new THREE.Mesh(
      new THREE.PlaneGeometry(2.2, 4.0),
      new THREE.MeshStandardMaterial({
        color: 0x1E2228,
        roughness: 0.15,
        metalness: 0.85,
      })
    );
    mirrorGlass.position.set(0.65, 0.3, -1.55);
    scene.add(mirrorGlass);

    // Warm Boutique Gold Light Column
    const mirrorLight = new THREE.Mesh(
      new THREE.BoxGeometry(0.04, 4.0, 0.02),
      new THREE.MeshStandardMaterial({ color: 0xC8A96B, emissive: 0xC8A96B, emissiveIntensity: 0.65 })
    );
    mirrorLight.position.set(1.75, 0.3, -1.53);
    scene.add(mirrorLight);

    scene.add(humanGroup);

    // --- 2. OPTIONAL PURE CLOTH DRAPE MESH (FOR CLOTH WAVE MODE) ---
    const clothGeom = new THREE.PlaneGeometry(2.8, 2.2, 32, 32);
    const waveMesh = new THREE.Mesh(clothGeom, suitMat);
    waveMesh.visible = (modelType === 'cloth_wave');
    scene.add(waveMesh);

    humanGroup.visible = (modelType === 'mannequin');

    threeStateRef.current.renderer = renderer;
    threeStateRef.current.scene = scene;
    threeStateRef.current.camera = camera;
    threeStateRef.current.suitMaterials = suitMaterials;
    threeStateRef.current.waveMesh = waveMesh;
    threeStateRef.current.mannequinGroup = humanGroup;

    // --- ANIMATION LOOP WITH SUBTLE HUMAN BREATHING MOTION ---
    let clock = new THREE.Clock();
    const animate = () => {
      const time = clock.getElapsedTime();

      // Auto rotation when enabled & not actively dragged
      if (autoRotate && !threeStateRef.current.isDragging) {
        threeStateRef.current.rotY += 0.007;
      }

      if (humanGroup.visible) {
        humanGroup.rotation.y = threeStateRef.current.rotY;
        humanGroup.rotation.x = threeStateRef.current.rotX * 0.4;

        // Subtle realistic human breathing motion on chest and shoulders
        const breath = Math.sin(time * 1.8) * 0.006;
        shoulderMesh.scale.set(1 + breath, 1 + breath * 0.5, 1 + breath);
        shirtTorsoMesh.scale.set(1.10 + breath * 0.8, 1, 0.80 + breath * 0.6);
      }

      if (waveMesh.visible) {
        // Realtime cloth ripples
        const pos = clothGeom.attributes.position;
        for (let i = 0; i < pos.count; i++) {
          const u = pos.getX(i);
          const v = pos.getY(i);
          const z =
            Math.sin(u * 2.2 + time * 2.5) * 0.18 +
            Math.cos(v * 1.8 + time * 2.0) * 0.12 +
            Math.sin((u + v) * 3.0 + time * 3.2) * 0.06;
          pos.setZ(i, z);
        }
        pos.needsUpdate = true;
        clothGeom.computeVertexNormals();

        waveMesh.rotation.x = threeStateRef.current.rotX;
        waveMesh.rotation.y = threeStateRef.current.rotY + Math.sin(time * 0.5) * 0.05;
      }

      renderer.render(scene, camera);
      threeStateRef.current.reqId = requestAnimationFrame(animate);
    };

    animate();

    const handleResize = () => {
      if (!canvasRef.current) return;
      const w = canvasRef.current.clientWidth;
      const h = canvasRef.current.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (threeStateRef.current.reqId) {
        cancelAnimationFrame(threeStateRef.current.reqId);
      }
      clothGeom.dispose();
      suitMat.dispose();
      trouserMat.dispose();
      sneakerMat.dispose();
      soleMat.dispose();
      goldMat.dispose();
      shirtButtonMat.dispose();
      skinMat.dispose();
      hairMat.dispose();
      eyeWhiteMat.dispose();
      irisMat.dispose();
      pupilMat.dispose();
      browMat.dispose();
      lipsMat.dispose();
      renderer.dispose();
    };
  }, [activeMode, modelType, wireframe]);

  // Update fabric color on 3D suit materials without recreating scene
  useEffect(() => {
    threeStateRef.current.suitMaterials.forEach((mat) => {
      mat.color.setHex(selectedFabric.color);
      mat.roughness = selectedFabric.roughness;
      mat.metalness = selectedFabric.metalness;
      mat.wireframe = wireframe;
      mat.needsUpdate = true;
    });
  }, [selectedFabric, wireframe]);

  // Mouse & Touch Dragging for 3D Model
  const handleCanvasMouseDown = (e: React.MouseEvent) => {
    threeStateRef.current.isDragging = true;
    threeStateRef.current.prevMouseX = e.clientX;
    threeStateRef.current.prevMouseY = e.clientY;
  };

  const handleCanvasMouseMove = (e: React.MouseEvent) => {
    if (!threeStateRef.current.isDragging) return;
    const deltaX = e.clientX - threeStateRef.current.prevMouseX;
    const deltaY = e.clientY - threeStateRef.current.prevMouseY;
    threeStateRef.current.rotY += deltaX * 0.012;
    threeStateRef.current.rotX += deltaY * 0.008;
    // Bound X tilt so model doesn't flip upside down
    threeStateRef.current.rotX = Math.max(-0.4, Math.min(0.4, threeStateRef.current.rotX));
    threeStateRef.current.prevMouseX = e.clientX;
    threeStateRef.current.prevMouseY = e.clientY;
  };

  const handleCanvasMouseUp = () => {
    threeStateRef.current.isDragging = false;
  };

  // Touch controls
  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      threeStateRef.current.isDragging = true;
      threeStateRef.current.prevMouseX = e.touches[0].clientX;
      threeStateRef.current.prevMouseY = e.touches[0].clientY;
    }
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!threeStateRef.current.isDragging || e.touches.length !== 1) return;
    const deltaX = e.touches[0].clientX - threeStateRef.current.prevMouseX;
    const deltaY = e.touches[0].clientY - threeStateRef.current.prevMouseY;
    threeStateRef.current.rotY += deltaX * 0.012;
    threeStateRef.current.rotX += deltaY * 0.008;
    threeStateRef.current.rotX = Math.max(-0.4, Math.min(0.4, threeStateRef.current.rotX));
    threeStateRef.current.prevMouseX = e.touches[0].clientX;
    threeStateRef.current.prevMouseY = e.touches[0].clientY;
  };

  const handleTouchEnd = () => {
    threeStateRef.current.isDragging = false;
  };

  return (
    <div className={`relative ${className}`}>
      {/* 3D Container with Perspective Tilt */}
      <div
        ref={containerRef}
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
        className="relative mx-auto rounded-2xl overflow-hidden shadow-2xl border-2 border-[#C8A96B]/40 group bg-[#111111] transition-transform duration-200 ease-out"
        style={{
          perspective: 1200,
          transform: activeMode === 'video' ? `rotateX(${tilt.x}deg) rotateY(${tilt.y}deg)` : undefined,
          transformStyle: 'preserve-3d',
        }}
      >
        {/* Top Floating Glass Badge Bar */}
        <div className="absolute top-3 left-3 right-3 z-30 flex items-center justify-between pointer-events-none">
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#111111]/90 backdrop-blur-md border border-[#C8A96B]/50 text-[#C8A96B] text-[11px] font-black tracking-wider uppercase shadow-md pointer-events-auto">
              <span className="w-2 h-2 rounded-full bg-[#C8A96B] animate-ping inline-block" />
              {activeMode === 'signature_model' 
                ? '⭐ SMK SIGNATURE MODEL' 
                : activeMode === 'video' 
                ? '3D VIDEO LIVE' 
                : '3D HUMAN MODEL'}
            </span>

            {activeMode === 'signature_model' && (
              <span className="hidden sm:inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md bg-black/75 text-[#D9D4CA] text-[10px] font-bold border border-[#C8A96B]/30 backdrop-blur-sm pointer-events-auto">
                <Sparkles className="w-3 h-3 text-[#C8A96B]" />
                {language === 'hi' ? 'शर्ट + पैंट कॉम्बो' : 'Linen Shirt + Trouser'}
              </span>
            )}

            {activeMode === 'interactive3d' && (
              <span className="hidden sm:inline-flex items-center gap-1 px-2.5 py-0.5 rounded-md bg-black/75 text-[#D9D4CA] text-[10px] font-bold border border-[#C8A96B]/30 backdrop-blur-sm pointer-events-auto">
                <User className="w-3 h-3 text-[#C8A96B]" />
                {selectedFabric.name}
              </span>
            )}
          </div>

          {/* Mode Switcher Buttons */}
          <div className="flex items-center gap-1 bg-black/85 backdrop-blur-md p-1 rounded-xl border border-[#2B2B2B] pointer-events-auto">
            <button
              onClick={() => setActiveMode('signature_model')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                activeMode === 'signature_model'
                  ? 'bg-[#C8A96B] text-[#111111] shadow'
                  : 'text-[#D9D4CA] hover:text-white'
              }`}
              title="Shree Maruti Krupa Signature Model"
            >
              <User className="w-3.5 h-3.5" />
              <span className="text-[11px]">{language === 'hi' ? 'SMK मॉडल' : 'SMK Model'}</span>
            </button>

            <button
              onClick={() => setActiveMode('interactive3d')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                activeMode === 'interactive3d'
                  ? 'bg-[#C8A96B] text-[#111111] shadow'
                  : 'text-[#D9D4CA] hover:text-white'
              }`}
              title="3D WebGL 360° Studio"
            >
              <RotateCw className="w-3.5 h-3.5" />
              <span className="text-[11px]">{language === 'hi' ? '3D स्पिन' : '3D Spin'}</span>
            </button>

            <button
              onClick={() => setActiveMode('video')}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer ${
                activeMode === 'video'
                  ? 'bg-[#C8A96B] text-[#111111] shadow'
                  : 'text-[#D9D4CA] hover:text-white'
              }`}
              title="3D Live Video Stream"
            >
              <Tv className="w-3.5 h-3.5" />
              <span className="text-[11px]">Video</span>
            </button>
          </div>
        </div>

        {/* Content Area: Video or 3D WebGL Canvas */}
        <div className={`relative ${compact ? 'h-72 sm:h-80 md:h-[380px]' : 'h-80 sm:h-96 md:h-[440px]'} w-full overflow-hidden`}>
          {activeMode === 'signature_model' ? (
            /* Signature Model Mode featuring exact user-requested model */
            <div 
              className="relative w-full h-full overflow-hidden select-none group/model cursor-pointer"
              onClick={() => {
                const feat = products.find(p => p.id === 'smk-03') || products[0];
                openModal('product', feat);
              }}
            >
              <img
                src={EXACT_HERO_MODEL_IMG}
                alt="Shree Maruti Krupa Signature Model wearing Linen Shirt and Trouser"
                className="w-full h-full object-cover object-top filter brightness-100 contrast-105 transition-transform duration-700 group-hover/model:scale-105"
                referrerPolicy="no-referrer"
              />

              {/* 3D Glass Gloss Reflection responding to mouse tilt */}
              <div 
                className="absolute inset-0 pointer-events-none opacity-20 bg-gradient-to-tr from-transparent via-white/10 to-[#C8A96B]/25"
                style={{
                  transform: `translate(${tilt.y * 3}px, ${-tilt.x * 3}px)`,
                }}
              />

              {/* Interactive Fabric Hotspots on the Model */}
              {/* Hotspot 1: Linen Shirt on Chest */}
              <div className="absolute top-[28%] left-[44%] -translate-x-1/2 -translate-y-1/2 z-20 pointer-events-none">
                <div className="relative">
                  <div className="w-6 h-6 rounded-full bg-[#C8A96B] flex items-center justify-center text-[#111111] shadow-lg animate-bounce">
                    <Sparkles className="w-3.5 h-3.5 fill-current" />
                  </div>
                  <div className="absolute left-7 top-1/2 -translate-y-1/2 bg-[#111111]/90 text-white text-[11px] font-semibold px-2.5 py-1.5 rounded-lg border border-[#C8A96B]/40 shadow-xl whitespace-nowrap backdrop-blur-md">
                    <div className="font-bold text-[#C8A96B]">{language === 'hi' ? 'टेक्सचर्ड लिनन शर्ट' : '100% Textured Linen Shirt'}</div>
                    <div className="text-[10px] text-[#D9D4CA]">{language === 'hi' ? '2.25m शर्ट कट • प्रीमियम फॉल' : '2.25m Cut • Unstitched'}</div>
                  </div>
                </div>
              </div>

              {/* Hotspot 2: Trouser on Thigh */}
              <div className="absolute top-[68%] left-[46%] -translate-x-1/2 -translate-y-1/2 z-20 pointer-events-none">
                <div className="relative">
                  <div className="w-6 h-6 rounded-full bg-[#C8A96B] flex items-center justify-center text-[#111111] shadow-lg animate-bounce delay-300">
                    <Sparkles className="w-3.5 h-3.5 fill-current" />
                  </div>
                  <div className="absolute left-7 top-1/2 -translate-y-1/2 bg-[#111111]/90 text-white text-[11px] font-semibold px-2.5 py-1.5 rounded-lg border border-[#C8A96B]/40 shadow-xl whitespace-nowrap backdrop-blur-md">
                    <div className="font-bold text-[#C8A96B]">{language === 'hi' ? 'चारकोल स्लिम फॉर्मल पैंट' : 'Charcoal Slim Trouser'}</div>
                    <div className="text-[10px] text-[#D9D4CA]">{language === 'hi' ? '1.20m पैंट कट • रिंकल-फ्री' : '1.20m Cut • Wrinkle-Free'}</div>
                  </div>
                </div>
              </div>

              {/* Top-Right Badge: Mirror Reflection View */}
              <div className="absolute top-14 right-3 z-20 bg-black/80 px-2.5 py-1 rounded-md text-[10px] font-bold text-[#C8A96B] border border-[#C8A96B]/30 backdrop-blur-sm shadow flex items-center gap-1 pointer-events-none">
                <User className="w-3 h-3" />
                <span>{language === 'hi' ? '360° मिरर रिफ्लेक्शन' : '360° Mirror View'}</span>
              </div>
            </div>
          ) : activeMode === 'video' ? (
            <>
              {/* HTML5 Video Element */}
              <video
                ref={videoRef}
                key={selectedVideo.id}
                src={selectedVideo.videoUrl}
                poster={selectedVideo.posterUrl}
                autoPlay
                loop
                muted={isMuted}
                playsInline
                onError={() => setVideoError(true)}
                className="w-full h-full object-cover object-center filter brightness-95 contrast-105"
              />

              {/* In case of offline video fallback or poster */}
              {videoError && (
                <div 
                  className="absolute inset-0 bg-cover bg-center"
                  style={{ backgroundImage: `url(${selectedVideo.posterUrl})` }}
                />
              )}

              {/* Subtle 3D Glass Light Sheen Effect */}
              <div 
                className="absolute inset-0 pointer-events-none opacity-30 bg-gradient-to-tr from-transparent via-white/10 to-[#C8A96B]/20"
                style={{
                  transform: `translate(${tilt.y * 3}px, ${-tilt.x * 3}px)`,
                }}
              />

              {/* Center Play Overlay when paused */}
              {!isPlaying && (
                <div 
                  onClick={togglePlay}
                  className="absolute inset-0 flex items-center justify-center bg-black/40 cursor-pointer backdrop-blur-[2px] transition"
                >
                  <div className="w-16 h-16 rounded-full bg-[#C8A96B] text-[#111111] flex items-center justify-center shadow-xl hover:scale-110 transition active:scale-95">
                    <Play className="w-8 h-8 fill-current ml-1" />
                  </div>
                </div>
              )}
            </>
          ) : (
            /* Interactive 3D WebGL Canvas with Model wearing clothes */
            <div 
              className="relative w-full h-full cursor-grab active:cursor-grabbing select-none"
              onMouseDown={handleCanvasMouseDown}
              onMouseMove={handleCanvasMouseMove}
              onMouseUp={handleCanvasMouseUp}
              onTouchStart={handleTouchStart}
              onTouchMove={handleTouchMove}
              onTouchEnd={handleTouchEnd}
            >
              <canvas ref={canvasRef} className="w-full h-full block" />
              
              {/* Top Instruction Badge */}
              <div className="absolute top-14 left-3 px-2.5 py-1 rounded-md bg-black/80 text-[#C8A96B] text-[10px] font-bold border border-[#C8A96B]/30 backdrop-blur-sm pointer-events-none flex items-center gap-1.5 shadow-md">
                <RotateCw className="w-3 h-3 animate-spin" />
                <span>
                  {language === 'hi' 
                    ? '3D ह्यूमन मॉडल को 360° घुमाकर सूट व फिटिंग देखें' 
                    : 'Drag 360° to inspect 3D Human Model & Fit'}
                </span>
              </div>

              {/* Quick Camera Angle View Switcher (Top Right) */}
              <div className="absolute top-14 right-3 flex flex-col gap-1.5 z-20">
                <button
                  onClick={() => setAutoRotate(!autoRotate)}
                  className={`px-2.5 py-1 rounded-md text-[10px] font-bold border transition cursor-pointer backdrop-blur-md flex items-center gap-1 ${
                    autoRotate 
                      ? 'bg-[#C8A96B] text-[#111111] border-[#C8A96B]' 
                      : 'bg-black/75 text-[#D9D4CA] border-white/20'
                  }`}
                  title="360° Auto spin"
                >
                  <RotateCw className="w-3 h-3" />
                  <span>{autoRotate ? 'Spin ON' : 'Spin OFF'}</span>
                </button>

                <div className="bg-black/80 rounded-md border border-white/20 p-0.5 flex flex-col gap-0.5 backdrop-blur-md">
                  <button
                    onClick={() => setCameraView('face')}
                    className={`px-2 py-0.5 rounded text-[10px] font-bold transition text-left cursor-pointer ${
                      cameraView === 'face' ? 'bg-[#C8A96B] text-[#111111]' : 'text-[#D9D4CA] hover:text-white'
                    }`}
                  >
                    👤 {language === 'hi' ? 'चेहरा/लुक' : 'Face View'}
                  </button>
                  <button
                    onClick={() => setCameraView('full')}
                    className={`px-2 py-0.5 rounded text-[10px] font-bold transition text-left cursor-pointer ${
                      cameraView === 'full' ? 'bg-[#C8A96B] text-[#111111]' : 'text-[#D9D4CA] hover:text-white'
                    }`}
                  >
                    👔 {language === 'hi' ? 'पूरा सूट' : 'Full Look'}
                  </button>
                  <button
                    onClick={() => setCameraView('chest')}
                    className={`px-2 py-0.5 rounded text-[10px] font-bold transition text-left cursor-pointer ${
                      cameraView === 'chest' ? 'bg-[#C8A96B] text-[#111111]' : 'text-[#D9D4CA] hover:text-white'
                    }`}
                  >
                    🔍 {language === 'hi' ? 'कॉलर/टाई' : 'Chest View'}
                  </button>
                  <button
                    onClick={() => setCameraView('trousers')}
                    className={`px-2 py-0.5 rounded text-[10px] font-bold transition text-left cursor-pointer ${
                      cameraView === 'trousers' ? 'bg-[#C8A96B] text-[#111111]' : 'text-[#D9D4CA] hover:text-white'
                    }`}
                  >
                    👖 {language === 'hi' ? 'पैंट फिट' : 'Trouser'}
                  </button>
                </div>
              </div>

              {/* Fabric Color Swatches - Model wears selected fabric */}
              <div className="absolute bottom-14 left-3 right-3 z-20">
                <div className="text-[10px] font-bold text-[#C8A96B] uppercase tracking-wider mb-1 flex items-center gap-1 drop-shadow">
                  <Sparkles className="w-3 h-3" />
                  <span>{language === 'hi' ? 'मॉडल को दूसरा कपड़ा पहनाएं:' : 'Change Fabric on Model:'}</span>
                </div>
                <div className="flex flex-wrap gap-1.5 overflow-x-auto no-scrollbar pb-1">
                  {FABRICS_3D.map((fab) => (
                    <button
                      key={fab.id}
                      onClick={() => setSelectedFabric(fab)}
                      className={`px-2.5 py-1 rounded-lg text-[10px] font-bold transition flex items-center gap-1.5 border cursor-pointer backdrop-blur-md active:scale-95 ${
                        selectedFabric.id === fab.id
                          ? 'bg-[#C8A96B] text-[#111111] border-[#C8A96B] shadow-md'
                          : 'bg-black/80 text-white border-white/20 hover:border-[#C8A96B]'
                      }`}
                    >
                      <span 
                        className="w-2.5 h-2.5 rounded-full border border-white/40 shrink-0" 
                        style={{ backgroundColor: fab.sheen }}
                      />
                      <span className="whitespace-nowrap">{fab.name}</span>
                      {selectedFabric.id === fab.id && <Check className="w-2.5 h-2.5 text-[#111111]" />}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Bottom Dark Gradient Info & Video Controls */}
          <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-[#111111] via-[#111111]/85 to-transparent pt-10 pb-3 px-3 sm:px-4 z-20 flex flex-col justify-end">
            <div className="flex items-end justify-between gap-2">
              <div>
                <span className="text-[#C8A96B] font-bold text-[11px] uppercase tracking-wider flex items-center gap-1">
                  <Sparkles className="w-3 h-3" />
                  {activeMode === 'signature_model'
                    ? (language === 'hi' ? 'SMK सिग्नेचर लिनन + चारकोल कॉम्बो' : 'SMK Signature Linen & Trouser Look')
                    : activeMode === 'interactive3d' 
                    ? (language === 'hi' ? `3D सूट मॉडल • ${selectedFabric.name}` : `3D Tailored Model • ${selectedFabric.name}`)
                    : (language === 'hi' ? selectedVideo.titleHi : selectedVideo.title)}
                </span>
                <p className="text-white font-bold text-xs sm:text-sm leading-snug line-clamp-1">
                  {activeMode === 'signature_model'
                    ? (language === 'hi' ? '2.25m टेक्सचर्ड लिनन शर्ट + 1.20m रिंकल-फ्री पैंट • ₹1,199 (45% छूट)' : '2.25m Textured Linen + 1.20m Wrinkle-Free Trouser Cut • ₹1,199')
                    : activeMode === 'interactive3d'
                    ? (language === 'hi' ? 'रेमंड, सियाराम व अरविंद का 100% असली स्यूटिंग व शर्टिंग कपड़ा' : 'Bespoke tailoring fit with sharp crease, peak lapel & genuine fall')
                    : selectedVideo.desc}
                </p>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-1.5 shrink-0">
                {activeMode === 'video' && (
                  <>
                    <button
                      onClick={togglePlay}
                      aria-label={isPlaying ? 'Pause 3D Video' : 'Play 3D Video'}
                      className="w-8 h-8 rounded-lg bg-black/70 hover:bg-[#2B2B2B] text-white border border-[#2B2B2B] flex items-center justify-center cursor-pointer transition active:scale-95"
                    >
                      {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4 fill-current ml-0.5" />}
                    </button>

                    <button
                      onClick={toggleMute}
                      aria-label={isMuted ? 'Unmute' : 'Mute'}
                      className="w-8 h-8 rounded-lg bg-black/70 hover:bg-[#2B2B2B] text-[#C8A96B] border border-[#2B2B2B] flex items-center justify-center cursor-pointer transition active:scale-95"
                    >
                      {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                    </button>
                  </>
                )}

                <button
                  onClick={() => {
                    const feat = (activeMode === 'signature_model') 
                      ? (products.find(p => p.id === 'smk-03') || products[0])
                      : (products.find(p => p.id === 'smk-01') || products[0]);
                    if (onExploreProduct && activeMode !== 'signature_model') {
                      onExploreProduct();
                    } else if (feat) {
                      openModal('product', feat);
                    }
                  }}
                  className="bg-[#C8A96B] hover:bg-[#b8985a] text-[#111111] font-black px-3 py-1.5 rounded-lg text-xs transition cursor-pointer flex items-center gap-1 shadow active:scale-95"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>
                    {activeMode === 'signature_model'
                      ? (language === 'hi' ? 'यह कॉम्बो खरीदें' : 'Buy This Look')
                      : (language === 'hi' ? 'यह कपड़ा खरीदें' : 'Buy This Fabric')}
                  </span>
                </button>
              </div>
            </div>

            {/* Video Preset Switcher Pills (when in video mode) */}
            {activeMode === 'video' && (
              <div className="flex items-center gap-1.5 mt-2.5 pt-2 border-t border-[#2B2B2B]/60 overflow-x-auto no-scrollbar">
                {videoList.map((vid) => (
                  <button
                    key={vid.id}
                    onClick={() => {
                      setSelectedVideo(vid);
                      setVideoError(false);
                      setIsPlaying(true);
                    }}
                    className={`px-2 py-0.5 rounded-md text-[10px] font-bold whitespace-nowrap transition cursor-pointer border ${
                      selectedVideo.id === vid.id
                        ? 'bg-[#C8A96B] text-[#111111] border-[#C8A96B]'
                        : 'bg-black/60 text-[#D9D4CA] border-white/10 hover:border-white/30'
                    }`}
                  >
                    {language === 'hi' ? vid.titleHi.split(' ')[0] + ' ' + vid.titleHi.split(' ')[1] : vid.tag}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
