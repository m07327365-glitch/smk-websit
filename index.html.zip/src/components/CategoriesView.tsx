import React from 'react';
import { useShop } from '../context/ShopContext';
import { CategoryType } from '../types';
import { 
  Shirt, 
  Briefcase, 
  Layers, 
  Crown, 
  Flame, 
  Sparkles, 
  Tag, 
  Grid,
  ChevronRight 
} from 'lucide-react';

export const CategoriesView: React.FC = () => {
  const { setSelectedCategory, setActiveTab, setSearchQuery, language } = useShop();

  const categoryList: { key: CategoryType; titleEn: string; titleHi: string; descEn: string; descHi: string; img: string; icon: React.ReactNode }[] = [
    {
      key: 'shirt',
      titleEn: 'Shirt Fabric',
      titleHi: 'शर्ट का कपड़ा',
      descEn: '100% Giza Cotton, Pure Linen & Micro-Checks for tailored shirts',
      descHi: '100% गीज़ा कॉटन, लक्जरी लिनेन और कॉरपोरेट चेक शर्टिंग',
      img: 'https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?auto=format&fit=crop&w=800&q=80',
      icon: <Shirt className="w-5 h-5 text-[#C8A96B]" />
    },
    {
      key: 'pant',
      titleEn: 'Pant & Trouser Fabric',
      titleHi: 'पैंट व ट्राउजर कपड़ा',
      descEn: 'Wrinkle-free Poly-Viscose, Chino Stretch & Formal suiting',
      descHi: 'रिंकल-फ्री पॉली-विस्कोस, चीनो कॉटन और फॉर्मल पैंट',
      img: 'https://images.unsplash.com/photo-1594938298603-c8148c4dae35?auto=format&fit=crop&w=800&q=80',
      icon: <Briefcase className="w-5 h-5 text-[#C8A96B]" />
    },
    {
      key: 'combo',
      titleEn: 'Shirt + Pant Combo Sets',
      titleHi: 'शर्ट + पैंट जोड़ी कॉम्बो',
      descEn: 'Matching shirt piece (2.25m) + pant piece (1.20m) gift sets',
      descHi: 'परफेक्ट मैचिंग शर्ट और पैंट जोड़ी - गिफ्ट और खुद के लिए',
      img: 'https://images.unsplash.com/photo-1617137984095-74e4e5e3613f?auto=format&fit=crop&w=800&q=80',
      icon: <Layers className="w-5 h-5 text-[#C8A96B]" />
    },
    {
      key: 'premium',
      titleEn: 'Premium Suiting & Linen',
      titleHi: 'प्रीमियम सूटिंग व लिनेन',
      descEn: 'Super 120s wool-touch fabrics, 60 Lea pure linen & blazer cloth',
      descHi: 'सुपर 120s वूल टच ब्लेजर फैब्रिक, इटैलियन 60 ली लिनेन',
      img: 'https://images.unsplash.com/photo-1507679799987-c73779587ccf?auto=format&fit=crop&w=800&q=80',
      icon: <Crown className="w-5 h-5 text-[#C8A96B]" />
    },
    {
      key: 'best_sellers',
      titleEn: 'Best Sellers',
      titleHi: 'सबसे ज्यादा बिकने वाले',
      descEn: 'Fabrics loved and repeatedly ordered by thousands of customers',
      descHi: 'ग्राहकों द्वारा सबसे ज्यादा खरीदे और सराहे गए कपड़े',
      img: 'https://images.unsplash.com/photo-1593030761757-71fae45fa0e7?auto=format&fit=crop&w=800&q=80',
      icon: <Flame className="w-5 h-5 text-[#9B2C2C]" />
    },
    {
      key: 'new_arrivals',
      titleEn: 'New Arrivals',
      titleHi: 'नए डिजाइन (New Arrivals)',
      descEn: 'Latest seasonal colors and fresh festival weaving',
      descHi: 'शादी और त्योहार के लिए बिल्कुल ताजा डिजाइन व कलर',
      img: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&w=800&q=80',
      icon: <Sparkles className="w-5 h-5 text-[#C8A96B]" />
    },
    {
      key: 'offers',
      titleEn: 'Special Offers (Up to 50% OFF)',
      titleHi: 'खास छूट (50% तक की छूट)',
      descEn: 'Discounted promotional fabric cuts with high savings',
      descHi: 'बंपर छूट वाले चुनिंदा कपड़े और कॉम्बो पैक',
      img: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=800&q=80',
      icon: <Tag className="w-5 h-5 text-[#9B2C2C]" />
    }
  ];

  const handleSelect = (key: CategoryType) => {
    setSelectedCategory(key);
    setSearchQuery('');
    setActiveTab('home');
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-6 sm:py-8">
      <div className="mb-6 pb-3 border-b border-[#E5E0D8]">
        <h2 className="text-xl sm:text-2xl font-black text-[#111111] font-serif">
          {language === 'hi' ? 'कपड़े की सभी श्रेणियां (Categories)' : 'All Fabric Categories'}
        </h2>
        <p className="text-xs sm:text-sm text-[#4A4A4A] mt-0.5">
          {language === 'hi' ? 'अपनी जरूरत के अनुसार सही फैब्रिक चुनें' : 'Choose exactly what you want to stitch'}
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {categoryList.map((cat) => (
          <div
            key={cat.key}
            onClick={() => handleSelect(cat.key)}
            className="group bg-white rounded-2xl border border-[#E5E0D8] overflow-hidden shadow-2xs hover:shadow-md transition cursor-pointer flex flex-col justify-between"
          >
            <div className="h-40 overflow-hidden relative bg-[#F7F5F0]">
              <img
                src={cat.img}
                alt={cat.titleEn}
                className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#111111]/80 via-transparent to-transparent flex items-end p-3">
                <span className="text-white text-xs font-bold flex items-center gap-1.5">
                  <span className="p-1 rounded bg-[#111111]/60 backdrop-blur-xs">
                    {cat.icon}
                  </span>
                  <span>{language === 'hi' ? cat.titleHi : cat.titleEn}</span>
                </span>
              </div>
            </div>

            <div className="p-4 flex-1 flex flex-col justify-between">
              <p className="text-xs text-[#4A4A4A] leading-relaxed mb-3">
                {language === 'hi' ? cat.descHi : cat.descEn}
              </p>

              <div className="flex items-center justify-between text-xs font-bold text-[#111111] group-hover:text-[#C8A96B] pt-2 border-t border-[#E5E0D8]">
                <span>{language === 'hi' ? 'कपड़े देखें' : 'Browse Collection'}</span>
                <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition text-[#C8A96B]" />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
