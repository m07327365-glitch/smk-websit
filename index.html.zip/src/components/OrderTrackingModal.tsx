import React from 'react';
import { Order } from '../types';
import { useShop } from '../context/ShopContext';
import { 
  X, 
  CheckCircle2, 
  Clock, 
  Truck, 
  MapPin, 
  Package, 
  Phone, 
  ShieldCheck, 
  RotateCcw,
  HelpCircle,
  Copy
} from 'lucide-react';

interface OrderTrackingModalProps {
  order: Order;
  onClose: () => void;
}

export const OrderTrackingModal: React.FC<OrderTrackingModalProps> = ({ order, onClose }) => {
  const { language, openModal } = useShop();

  const handleReturnClick = () => {
    onClose();
    openModal('return', { order, product: order.items[0]?.product });
  };

  const handleSupportClick = () => {
    onClose();
    openModal('support');
  };

  const copyTracking = () => {
    navigator.clipboard?.writeText(order.trackingNumber);
    alert(language === 'hi' ? 'ट्रैकिंग नंबर कॉपी हो गया!' : 'Tracking number copied!');
  };

  return (
    <div className="fixed inset-0 z-50 bg-stone-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-xl w-full my-auto overflow-hidden shadow-2xl border border-[#E5E0D8] animate-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[#E5E0D8] bg-[#F7F5F0] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#111111] flex items-center justify-center text-[#C8A96B]">
              <Package className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-[#111111]">
                {language === 'hi' ? 'ऑर्डर ट्रैकिंग' : 'Track Order'}
              </h2>
              <p className="text-xs text-[#777777] font-mono">
                Order #{order.orderNumber}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-white hover:bg-[#E5E0D8] text-[#111111] border border-[#E5E0D8] flex items-center justify-center transition cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Expected Delivery Banner */}
        <div className="bg-[#111111] text-white p-4 flex items-center justify-between border-b border-[#2B2B2B]">
          <div>
            <span className="text-[#C8A96B] text-xs font-semibold uppercase tracking-wider block">
              {language === 'hi' ? 'अनुमानित डिलीवरी:' : 'Expected Delivery:'}
            </span>
            <span className="text-base sm:text-lg font-bold">
              {order.expectedDelivery}
            </span>
          </div>

          <div className="text-right">
            <span className="text-[#D9D4CA] text-[11px] block">
              {language === 'hi' ? 'कूरियर पार्टनर:' : 'Courier Partner:'}
            </span>
            <button
              onClick={copyTracking}
              className="text-xs text-[#C8A96B] hover:text-white font-mono flex items-center gap-1 mt-0.5"
              title="Click to copy tracking number"
            >
              <span>{order.trackingNumber}</span>
              <Copy className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* Visual Timeline Section */}
        <div className="p-4 sm:p-6 max-h-[60vh] overflow-y-auto space-y-6">
          <div className="relative pl-6 space-y-6 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-[#E5E0D8]">
            {order.trackingSteps.map((step, idx) => {
              const isPast = idx < order.currentStepIndex;
              const isCurrent = idx === order.currentStepIndex;

              return (
                <div key={idx} className="relative group">
                  {/* Status Indicator Icon */}
                  <div
                    className={`absolute -left-6 top-0.5 w-5 h-5 rounded-full flex items-center justify-center ring-4 ring-white ${
                      isPast
                        ? 'bg-[#111111] text-[#C8A96B]'
                        : isCurrent
                        ? 'bg-[#111111] text-white ring-[#C8A96B]/40 animate-pulse'
                        : 'bg-[#E5E0D8] text-[#777777]'
                    }`}
                  >
                    {isPast ? (
                      <CheckCircle2 className="w-3.5 h-3.5" />
                    ) : isCurrent ? (
                      <div className="w-2 h-2 rounded-full bg-[#C8A96B]" />
                    ) : (
                      <div className="w-1.5 h-1.5 rounded-full bg-[#777777]" />
                    )}
                  </div>

                  {/* Step Details */}
                  <div className="flex flex-col sm:flex-row sm:items-baseline sm:justify-between gap-0.5">
                    <div>
                      <h4
                        className={`text-sm font-bold ${
                          isCurrent
                            ? 'text-[#111111] font-extrabold text-base'
                            : isPast
                            ? 'text-[#111111]'
                            : 'text-[#777777]'
                        }`}
                      >
                        {language === 'hi' ? step.labelHi : step.label}
                      </h4>
                      {step.note && (
                        <p className="text-xs text-[#4A4A4A] mt-0.5 bg-[#F7F5F0] p-2 rounded-lg border border-[#E5E0D8] inline-block">
                          {step.note}
                        </p>
                      )}
                    </div>

                    <div className="text-xs text-[#777777] font-medium">
                      <span>{step.date}</span>
                      {step.time && <span className="ml-1 text-[#777777]">({step.time})</span>}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Delivery Address Card */}
          <div className="bg-[#F7F5F0] p-3.5 rounded-xl border border-[#E5E0D8] text-xs">
            <span className="font-bold text-[#111111] flex items-center gap-1.5 mb-1">
              <MapPin className="w-3.5 h-3.5 text-[#C8A96B]" />
              {language === 'hi' ? 'डिलीवरी का पता' : 'Delivery Address'}
            </span>
            <p className="font-medium text-[#111111]">
              {order.shippingAddress.fullName} • +91 {order.shippingAddress.phoneNumber}
            </p>
            <p className="text-[#4A4A4A]">
              {order.shippingAddress.houseFlat}, {order.shippingAddress.roadArea}, {order.shippingAddress.city}, {order.shippingAddress.state} - {order.shippingAddress.pincode}
            </p>
          </div>

          {/* Return Info if already requested */}
          {order.returnRequested && (
            <div className="bg-[#F7F5F0] border border-[#E5E0D8] p-3 rounded-xl text-xs text-[#9B2C2C]">
              <span className="font-bold flex items-center gap-1 mb-0.5">
                <RotateCcw className="w-3.5 h-3.5 text-[#9B2C2C]" />
                {language === 'hi' ? 'रिटर्न पिकअप शेड्यूल है' : 'Return Pickup Scheduled'}
              </span>
              <p>
                {language === 'hi' 
                  ? `कारण: ${order.returnReason}। कूरियर पार्टनर 24 घंटे में कपड़ा पिकअप करेगा।` 
                  : `Reason: ${order.returnReason}. Courier will pick up from your address within 24 hours.`}
              </p>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-[#E5E0D8] bg-[#F7F5F0] flex flex-wrap gap-2 justify-between">
          <button
            onClick={handleSupportClick}
            className="flex-1 py-2.5 px-3 rounded-xl border border-[#E5E0D8] bg-white text-[#111111] font-bold text-xs hover:bg-[#F7F5F0] flex items-center justify-center gap-1.5 transition cursor-pointer"
          >
            <HelpCircle className="w-4 h-4 text-[#C8A96B]" />
            <span>{language === 'hi' ? 'ऑर्डर में मदद चाहिए?' : 'Need Help?'}</span>
          </button>

          {!order.returnRequested && (
            <button
              onClick={handleReturnClick}
              className="flex-1 py-2.5 px-3 rounded-xl bg-[#111111] hover:bg-[#2B2B2B] text-white font-bold text-xs flex items-center justify-center gap-1.5 transition cursor-pointer"
            >
              <RotateCcw className="w-4 h-4 text-[#C8A96B]" />
              <span>{language === 'hi' ? 'कपड़ा वापस करें (Return)' : 'Return / Exchange'}</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
