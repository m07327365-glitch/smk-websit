import React, { useState, useRef, ChangeEvent } from 'react';
import { 
  Upload, 
  X, 
  Trash2, 
  CheckCircle2, 
  AlertTriangle, 
  Eye, 
  RefreshCw, 
  Star, 
  Loader2, 
  Image as ImageIcon,
  Plus
} from 'lucide-react';
import { 
  validateImageFile, 
  uploadImageFile 
} from '../../utils/imageStorageService';

interface ProductImageUploaderProps {
  primaryImage: string;
  additionalImages?: string[];
  onChange: (primary: string, additionals: string[]) => void;
  label?: string;
}

interface UploadStatusState {
  status: 'idle' | 'uploading' | 'success' | 'error';
  message: string;
  progress: number;
}

export const ProductImageUploader: React.FC<ProductImageUploaderProps> = ({
  primaryImage,
  additionalImages = [],
  onChange,
  label = 'Product Images (Main & Gallery)'
}) => {
  const [uploadStatus, setUploadStatus] = useState<UploadStatusState>({
    status: 'idle',
    message: '',
    progress: 0
  });

  // Preview modal state
  const [previewModalUrl, setPreviewModalUrl] = useState<string | null>(null);

  // Direct URL input toggle
  const [showUrlInput, setShowUrlInput] = useState(false);
  const [manualUrl, setManualUrl] = useState('');

  // Index of image being replaced (-1 if adding new)
  const [replacingIndex, setReplacingIndex] = useState<number | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const replaceInputRef = useRef<HTMLInputElement>(null);

  // Combine primary and additional images into a unified array
  const allImages = [
    ...(primaryImage ? [primaryImage] : []),
    ...additionalImages.filter(img => img && img !== primaryImage)
  ];

  const handleTriggerFileInput = () => {
    setReplacingIndex(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
      fileInputRef.current.click();
    }
  };

  const handleTriggerReplaceInput = (index: number) => {
    setReplacingIndex(index);
    if (replaceInputRef.current) {
      replaceInputRef.current.value = '';
      replaceInputRef.current.click();
    }
  };

  const handleFileChange = async (e: ChangeEvent<HTMLInputElement>, isReplacing = false) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate
    const validation = validateImageFile(file);
    if (!validation.valid) {
      setUploadStatus({
        status: 'error',
        message: validation.error || 'Upload failed — please try again',
        progress: 0
      });
      return;
    }

    try {
      setUploadStatus({
        status: 'uploading',
        message: 'Uploading...',
        progress: 10
      });

      const result = await uploadImageFile(file, (progress) => {
        setUploadStatus(prev => ({ ...prev, progress }));
      });

      if (isReplacing && replacingIndex !== null) {
        // Replace existing image at replacingIndex
        const newImages = [...allImages];
        newImages[replacingIndex] = result.url;
        const newPrimary = newImages[0];
        const newAdditionals = newImages.slice(1);
        onChange(newPrimary, newAdditionals);
        setReplacingIndex(null);
      } else {
        // Add new image
        if (!primaryImage) {
          onChange(result.url, additionalImages);
        } else {
          onChange(primaryImage, [...additionalImages, result.url]);
        }
      }

      setUploadStatus({
        status: 'success',
        message: 'Upload successful',
        progress: 100
      });

      // Clear success message after 3 seconds
      setTimeout(() => {
        setUploadStatus(prev => prev.status === 'success' ? { status: 'idle', message: '', progress: 0 } : prev);
      }, 3000);
    } catch (err: any) {
      setUploadStatus({
        status: 'error',
        message: err?.message || 'Upload failed — please try again',
        progress: 0
      });
    }
  };

  const handleSetPrimary = (index: number) => {
    if (index === 0) return; // already primary
    const targetImage = allImages[index];
    const remaining = allImages.filter((_, idx) => idx !== index);
    onChange(targetImage, remaining);
  };

  const handleRemoveImage = (index: number) => {
    const updated = allImages.filter((_, idx) => idx !== index);
    if (updated.length === 0) {
      onChange('', []);
    } else {
      onChange(updated[0], updated.slice(1));
    }
  };

  const handleAddManualUrl = () => {
    const trimmed = manualUrl.trim();
    if (!trimmed) return;
    if (!primaryImage) {
      onChange(trimmed, additionalImages);
    } else {
      onChange(primaryImage, [...additionalImages, trimmed]);
    }
    setManualUrl('');
    setShowUrlInput(false);
  };

  return (
    <div className="space-y-3 bg-stone-950 p-3.5 rounded-xl border border-stone-800">
      <div className="flex items-center justify-between">
        <div>
          <label className="block font-bold text-stone-200 text-xs flex items-center gap-1.5">
            <ImageIcon className="w-3.5 h-3.5 text-amber-400" />
            <span>{label}</span>
          </label>
          <span className="text-[11px] text-stone-400">
            JPG, JPEG, PNG, WEBP (Max 10MB) • Multiple images supported
          </span>
        </div>

        <button
          type="button"
          onClick={() => setShowUrlInput(!showUrlInput)}
          className="text-[11px] text-stone-400 hover:text-amber-300 transition underline cursor-pointer"
        >
          {showUrlInput ? 'Hide URL input' : 'Paste web URL'}
        </button>
      </div>

      {/* Hidden File Inputs */}
      <input
        ref={fileInputRef}
        type="file"
        accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"
        onChange={(e) => handleFileChange(e, false)}
        className="hidden"
      />
      <input
        ref={replaceInputRef}
        type="file"
        accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"
        onChange={(e) => handleFileChange(e, true)}
        className="hidden"
      />

      {/* Manual URL input fallback if needed */}
      {showUrlInput && (
        <div className="flex gap-2 p-2 bg-stone-900 rounded-lg border border-stone-700">
          <input
            type="url"
            value={manualUrl}
            onChange={(e) => setManualUrl(e.target.value)}
            placeholder="https://example.com/image.jpg"
            className="flex-1 px-2.5 py-1.5 bg-stone-950 border border-stone-700 rounded-lg text-white text-xs font-mono"
          />
          <button
            type="button"
            onClick={handleAddManualUrl}
            className="bg-amber-800 hover:bg-amber-700 text-white font-bold px-3 py-1.5 rounded-lg text-xs cursor-pointer"
          >
            Add URL
          </button>
        </div>
      )}

      {/* Upload Status Banner */}
      {uploadStatus.status !== 'idle' && (
        <div
          className={`p-2.5 rounded-xl border text-xs flex items-center justify-between transition-all ${
            uploadStatus.status === 'uploading'
              ? 'bg-blue-950/80 border-blue-700 text-blue-200'
              : uploadStatus.status === 'success'
              ? 'bg-emerald-950/80 border-emerald-700 text-emerald-200'
              : 'bg-red-950/80 border-red-700 text-red-200'
          }`}
        >
          <div className="flex items-center gap-2">
            {uploadStatus.status === 'uploading' && (
              <Loader2 className="w-4 h-4 text-blue-300 animate-spin" />
            )}
            {uploadStatus.status === 'success' && (
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            )}
            {uploadStatus.status === 'error' && (
              <AlertTriangle className="w-4 h-4 text-red-400" />
            )}
            <span className="font-bold">{uploadStatus.message}</span>
          </div>

          {uploadStatus.status === 'uploading' && (
            <span className="font-mono text-[11px] text-blue-300">
              {uploadStatus.progress}%
            </span>
          )}

          {uploadStatus.status === 'error' && (
            <button
              type="button"
              onClick={handleTriggerFileInput}
              className="text-[11px] font-bold text-red-300 underline cursor-pointer"
            >
              Try Again
            </button>
          )}
        </div>
      )}

      {/* Images Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {allImages.map((imgUrl, idx) => {
          const isPrimary = idx === 0;
          return (
            <div
              key={idx}
              className={`group relative aspect-square rounded-xl overflow-hidden bg-stone-900 border-2 transition-all shadow-sm ${
                isPrimary ? 'border-amber-500 ring-2 ring-amber-500/20' : 'border-stone-700 hover:border-stone-500'
              }`}
            >
              <img
                src={imgUrl}
                alt={`Product image ${idx + 1}`}
                className="w-full h-full object-cover object-center"
              />

              {/* Primary Badge */}
              {isPrimary ? (
                <div className="absolute top-1.5 left-1.5 bg-amber-500 text-stone-950 text-[10px] font-black uppercase px-2 py-0.5 rounded shadow-sm flex items-center gap-1 z-10">
                  <Star className="w-3 h-3 fill-stone-950" />
                  <span>Main Image</span>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => handleSetPrimary(idx)}
                  className="absolute top-1.5 left-1.5 opacity-90 sm:opacity-0 group-hover:opacity-100 bg-stone-900/90 hover:bg-amber-600 text-stone-200 hover:text-white text-[10px] font-bold px-2 py-0.5 rounded transition cursor-pointer z-10"
                  title="Make this the primary storefront image"
                >
                  Set as Main
                </button>
              )}

              {/* Action Toolbar on Hover */}
              <div className="absolute inset-0 bg-stone-950/70 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-1.5 p-2">
                {/* Preview Button */}
                <button
                  type="button"
                  onClick={() => setPreviewModalUrl(imgUrl)}
                  className="w-8 h-8 rounded-lg bg-stone-800 hover:bg-stone-700 text-white flex items-center justify-center transition cursor-pointer"
                  title="Preview Full Image"
                >
                  <Eye className="w-3.5 h-3.5" />
                </button>

                {/* Replace Button */}
                <button
                  type="button"
                  onClick={() => handleTriggerReplaceInput(idx)}
                  className="w-8 h-8 rounded-lg bg-stone-800 hover:bg-blue-700 text-white flex items-center justify-center transition cursor-pointer"
                  title="Replace with new image from device"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                </button>

                {/* Remove Button */}
                <button
                  type="button"
                  onClick={() => handleRemoveImage(idx)}
                  className="w-8 h-8 rounded-lg bg-stone-800 hover:bg-red-700 text-white flex items-center justify-center transition cursor-pointer"
                  title="Remove image"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}

        {/* Add Image Button / Drop Box */}
        <button
          type="button"
          onClick={handleTriggerFileInput}
          disabled={uploadStatus.status === 'uploading'}
          className="aspect-square rounded-xl border-2 border-dashed border-stone-700 hover:border-amber-500 bg-stone-900/60 hover:bg-stone-900 text-stone-400 hover:text-amber-300 flex flex-col items-center justify-center gap-2 p-3 transition cursor-pointer group disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <div className="w-10 h-10 rounded-full bg-stone-800 group-hover:bg-amber-900/50 flex items-center justify-center text-stone-300 group-hover:text-amber-200 transition">
            {uploadStatus.status === 'uploading' ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <Upload className="w-5 h-5" />
            )}
          </div>
          <div className="text-center">
            <span className="block text-xs font-bold text-stone-200 group-hover:text-amber-200">
              {allImages.length === 0 ? 'Upload Image' : '+ Add Image'}
            </span>
            <span className="text-[10px] text-stone-500 block mt-0.5">
              Select from device
            </span>
          </div>
        </button>
      </div>

      {allImages.length === 0 && (
        <p className="text-[11px] text-amber-400/90 flex items-center gap-1.5 pt-1">
          <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
          <span>At least one product image is required for the storefront catalog.</span>
        </p>
      )}

      {/* Full-screen / High-Res Image Preview Modal */}
      {previewModalUrl && (
        <div 
          className="fixed inset-0 z-50 bg-stone-950/85 backdrop-blur-xs flex items-center justify-center p-4 cursor-pointer"
          onClick={() => setPreviewModalUrl(null)}
        >
          <div 
            className="relative max-w-2xl max-h-[85vh] bg-stone-900 rounded-2xl overflow-hidden border border-stone-700 shadow-2xl p-2 flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-2 px-2 border-b border-stone-800">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <Eye className="w-3.5 h-3.5 text-amber-400" />
                <span>Full Image Preview</span>
              </span>
              <button
                type="button"
                onClick={() => setPreviewModalUrl(null)}
                className="w-7 h-7 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="p-2 flex-1 flex items-center justify-center overflow-hidden">
              <img
                src={previewModalUrl}
                alt="Product preview"
                className="max-h-[70vh] w-auto max-w-full object-contain rounded-lg"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
