import React from 'react';
import { useShop } from '../../context/ShopContext';
import { AdminTab } from './AdminSidebar';
import { 
  Package, 
  Truck, 
  CheckCircle2, 
  XCircle, 
  RotateCcw, 
  Users, 
  Shirt, 
  AlertTriangle, 
  IndianRupee, 
  PlusCircle, 
  ArrowRight, 
  Clock, 
  Calendar,
  ExternalLink
} from 'lucide-react';

interface AdminDashboardViewProps {
  onSelectTab: (tab: AdminTab) => void;
  onOpenAddProductModal: () => void;
  onViewOrderDetails: (orderId: string) => void;
}

export const AdminDashboardView: React.FC<AdminDashboardViewProps> = ({
  onSelectTab,
  onOpenAddProductModal,
  onViewOrderDetails
}) => {
  const { adminStats, orders, lowStockProducts, updateProductStock } = useShop();

  const recentOrders = orders.slice(0, 5);

  return (
    <div className="space-y-6 sm:space-y-8">
      {/* Page Title & Quick Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-stone-800">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-white font-serif">
            Store Performance & Live Analytics
          </h1>
          <p className="text-xs text-stone-400 mt-0.5">
            Surat Central Textile Hub • Real-time order tracking and fabric stock monitor
          </p>
        </div>

        {/* Quick Action Buttons */}
        {/* Quick Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={onOpenAddProductModal}
            className="bg-[#1E1E1E] hover:bg-[#2B2B2B] text-white border border-[#C8A96B]/50 font-bold px-3.5 py-2 rounded-xl text-xs flex items-center gap-1.5 transition shadow-sm cursor-pointer"
          >
            <PlusCircle className="w-4 h-4 text-[#C8A96B]" />
            <span>+ Add New Product</span>
          </button>

          <button
            onClick={() => onSelectTab('orders')}
            className="bg-[#1E1E1E] hover:bg-[#2B2B2B] border border-[#2B2B2B] text-[#D9D4CA] font-bold px-3.5 py-2 rounded-xl text-xs flex items-center gap-1.5 transition cursor-pointer"
          >
            <Package className="w-4 h-4 text-[#777777]" />
            <span>View Orders</span>
          </button>

          <button
            onClick={() => onSelectTab('products')}
            className="bg-[#1E1E1E] hover:bg-[#2B2B2B] border border-[#2B2B2B] text-[#D9D4CA] font-bold px-3.5 py-2 rounded-xl text-xs flex items-center gap-1.5 transition cursor-pointer"
          >
            <Shirt className="w-4 h-4 text-[#777777]" />
            <span>Manage Stock</span>
          </button>

          <button
            onClick={() => onSelectTab('returns')}
            className="bg-[#1E1E1E] hover:bg-[#2B2B2B] border border-[#2B2B2B] text-[#D9D4CA] font-bold px-3.5 py-2 rounded-xl text-xs flex items-center gap-1.5 transition cursor-pointer"
          >
            <RotateCcw className="w-4 h-4 text-[#777777]" />
            <span>Returns & Refunds</span>
          </button>
        </div>
      </div>

      {/* Top 2 Sales Banner Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {/* Today's Sales */}
        <div className="bg-[#111111] border border-[#2B2B2B] rounded-2xl p-5 shadow-sm">
          <div className="flex justify-between items-start">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-[#C8A96B]">
                Today's Sales
              </span>
              <div className="text-2xl sm:text-3xl font-black text-white mt-1">
                ₹{adminStats.todaySales.toLocaleString('en-IN')}
              </div>
              <p className="text-[11px] text-[#D9D4CA] mt-1">
                From {adminStats.todayOrders} new orders received today
              </p>
            </div>
            <div className="w-10 h-10 rounded-xl bg-[#1E1E1E] border border-[#2B2B2B] text-[#C8A96B] flex items-center justify-center">
              <IndianRupee className="w-5 h-5" />
            </div>
          </div>
        </div>

        {/* Total Sales */}
        <div className="bg-[#111111] border border-[#2B2B2B] rounded-2xl p-5 shadow-sm">
          <div className="flex justify-between items-start">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-[#C8A96B]">
                Total Lifetime Revenue
              </span>
              <div className="text-2xl sm:text-3xl font-black text-white mt-1">
                ₹{adminStats.totalSales.toLocaleString('en-IN')}
              </div>
              <p className="text-[11px] text-[#D9D4CA] mt-1">
                Across {adminStats.totalOrders} total store orders
              </p>
            </div>
            <div className="w-10 h-10 rounded-xl bg-[#1E1E1E] border border-[#2B2B2B] text-[#C8A96B] flex items-center justify-center">
              <IndianRupee className="w-5 h-5" />
            </div>
          </div>
        </div>
      </div>

      {/* 11 Database Metric Cards Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3.5 sm:gap-4">
        {/* 1. Today's Orders */}
        <div 
          onClick={() => onSelectTab('orders')} 
          className="bg-stone-900/90 border border-stone-800 p-4 rounded-xl hover:border-amber-700/60 transition cursor-pointer"
        >
          <div className="flex items-center justify-between text-stone-400 text-xs">
            <span className="font-bold text-white">Today's Orders</span>
            <Clock className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-white mt-1">
            {adminStats.todayOrders}
          </div>
          <span className="text-[10px] text-stone-400">Placed in last 24 hrs</span>
        </div>

        {/* 2. Total Orders */}
        <div 
          onClick={() => onSelectTab('orders')} 
          className="bg-stone-900/90 border border-stone-800 p-4 rounded-xl hover:border-amber-700/60 transition cursor-pointer"
        >
          <div className="flex items-center justify-between text-stone-400 text-xs">
            <span className="font-bold text-white">Total Orders</span>
            <Package className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-white mt-1">
            {adminStats.totalOrders}
          </div>
          <span className="text-[10px] text-stone-400">All recorded orders</span>
        </div>

        {/* 3. Pending Orders */}
        <div 
          onClick={() => onSelectTab('orders')} 
          className="bg-stone-900/90 border border-stone-800 p-4 rounded-xl hover:border-amber-700/60 transition cursor-pointer"
        >
          <div className="flex items-center justify-between text-stone-400 text-xs">
            <span className="font-bold text-amber-300">Pending Orders</span>
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse"></span>
          </div>
          <div className="text-xl sm:text-2xl font-black text-amber-300 mt-1">
            {adminStats.pendingOrders}
          </div>
          <span className="text-[10px] text-stone-400">Needs Packing / Dispatch</span>
        </div>

        {/* 4. Shipped Orders */}
        <div 
          onClick={() => onSelectTab('orders')} 
          className="bg-stone-900/90 border border-stone-800 p-4 rounded-xl hover:border-amber-700/60 transition cursor-pointer"
        >
          <div className="flex items-center justify-between text-stone-400 text-xs">
            <span className="font-bold text-white">Shipped / In Transit</span>
            <Truck className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-white mt-1">
            {adminStats.shippedOrders}
          </div>
          <span className="text-[10px] text-stone-400">With courier partners</span>
        </div>

        {/* 5. Delivered Orders */}
        <div 
          onClick={() => onSelectTab('orders')} 
          className="bg-stone-900/90 border border-stone-800 p-4 rounded-xl hover:border-amber-700/60 transition cursor-pointer"
        >
          <div className="flex items-center justify-between text-stone-400 text-xs">
            <span className="font-bold text-white">Delivered</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-white mt-1">
            {adminStats.deliveredOrders}
          </div>
          <span className="text-[10px] text-stone-400">Successfully received</span>
        </div>

        {/* 6. Cancelled Orders */}
        <div 
          onClick={() => onSelectTab('orders')} 
          className="bg-stone-900/90 border border-stone-800 p-4 rounded-xl hover:border-amber-700/60 transition cursor-pointer"
        >
          <div className="flex items-center justify-between text-stone-400 text-xs">
            <span className="font-bold text-white">Cancelled</span>
            <XCircle className="w-4 h-4 text-red-400" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-stone-300 mt-1">
            {adminStats.cancelledOrders}
          </div>
          <span className="text-[10px] text-stone-400">Cancelled / Voided</span>
        </div>

        {/* 7. Return Requests */}
        <div 
          onClick={() => onSelectTab('returns')} 
          className="bg-stone-900/90 border border-stone-800 p-4 rounded-xl hover:border-amber-700/60 transition cursor-pointer"
        >
          <div className="flex items-center justify-between text-stone-400 text-xs">
            <span className="font-bold text-orange-300">Return Requests</span>
            <RotateCcw className="w-4 h-4 text-orange-400" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-orange-300 mt-1">
            {adminStats.returnRequests}
          </div>
          <span className="text-[10px] text-stone-400">Customer return inquiries</span>
        </div>

        {/* 8. Refund Requests */}
        <div 
          onClick={() => onSelectTab('returns')} 
          className="bg-stone-900/90 border border-stone-800 p-4 rounded-xl hover:border-amber-700/60 transition cursor-pointer"
        >
          <div className="flex items-center justify-between text-stone-400 text-xs">
            <span className="font-bold text-white">Refunds to Process</span>
            <IndianRupee className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-white mt-1">
            {adminStats.refundRequests}
          </div>
          <span className="text-[10px] text-stone-400">Pending customer refunds</span>
        </div>

        {/* 9. Total Customers */}
        <div 
          onClick={() => onSelectTab('customers')} 
          className="bg-stone-900/90 border border-stone-800 p-4 rounded-xl hover:border-amber-700/60 transition cursor-pointer"
        >
          <div className="flex items-center justify-between text-stone-400 text-xs">
            <span className="font-bold text-white">Total Customers</span>
            <Users className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-white mt-1">
            {adminStats.totalCustomers}
          </div>
          <span className="text-[10px] text-stone-400">Unique customer profiles</span>
        </div>

        {/* 10. Total Products */}
        <div 
          onClick={() => onSelectTab('products')} 
          className="bg-stone-900/90 border border-stone-800 p-4 rounded-xl hover:border-amber-700/60 transition cursor-pointer"
        >
          <div className="flex items-center justify-between text-stone-400 text-xs">
            <span className="font-bold text-white">Active Products</span>
            <Shirt className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-xl sm:text-2xl font-black text-white mt-1">
            {adminStats.totalProducts}
          </div>
          <span className="text-[10px] text-stone-400">Catalog fabric styles</span>
        </div>

        {/* 11. Low Stock Products */}
        <div 
          onClick={() => onSelectTab('products')} 
          className={`p-4 rounded-xl border transition cursor-pointer ${
            adminStats.lowStockCount > 0 
              ? 'bg-orange-950/40 border-orange-800 text-orange-200' 
              : 'bg-stone-900/90 border-stone-800 text-stone-400'
          }`}
        >
          <div className="flex items-center justify-between text-xs">
            <span className="font-bold text-orange-300">Low Stock Alert</span>
            <AlertTriangle className="w-4 h-4 text-orange-400" />
          </div>
          <div className="text-xl sm:text-2xl font-black mt-1">
            {adminStats.lowStockCount}
          </div>
          <span className="text-[10px] text-stone-400">Stock ≤ 20 meters remaining</span>
        </div>
      </div>

      {/* Two Column Layout: Recent Orders & Low Stock Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Orders Section */}
        <div className="bg-stone-900 border border-stone-800 rounded-2xl p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-stone-800">
            <div>
              <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Package className="w-4 h-4 text-amber-400" />
                Recent Orders
              </h3>
              <p className="text-xs text-stone-400">Latest customer bookings in real-time</p>
            </div>
            <button
              onClick={() => onSelectTab('orders')}
              className="text-xs text-amber-400 hover:text-amber-300 font-bold flex items-center gap-1 cursor-pointer"
            >
              <span>View All</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="divide-y divide-stone-800/80 space-y-2">
            {recentOrders.map((ord) => (
              <div 
                key={ord.id} 
                className="pt-2.5 first:pt-0 flex items-center justify-between gap-3 text-xs"
              >
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-white">#{ord.orderNumber}</span>
                    <span className="text-stone-400">•</span>
                    <span className="font-semibold text-stone-200 truncate">{ord.shippingAddress.fullName}</span>
                  </div>
                  <p className="text-[11px] text-stone-400 mt-0.5">
                    {ord.items.length} item(s) • ₹{ord.totalPayable} • {ord.paymentMethod.toUpperCase()}
                  </p>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                    ord.status === 'delivered' ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' :
                    ord.status === 'out_for_delivery' ? 'bg-blue-950 text-blue-300 border border-blue-800' :
                    ord.status === 'placed' ? 'bg-amber-950 text-amber-300 border border-amber-800' :
                    'bg-stone-800 text-stone-300'
                  }`}>
                    {ord.status.replace(/_/g, ' ')}
                  </span>

                  <button
                    onClick={() => onViewOrderDetails(ord.id)}
                    className="p-1.5 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 cursor-pointer"
                    title="View Order"
                  >
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Low Stock Section */}
        <div className="bg-stone-900 border border-stone-800 rounded-2xl p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-stone-800">
            <div>
              <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-orange-400" />
                Low Stock Fabrics (Alerts)
              </h3>
              <p className="text-xs text-stone-400">Inventory reaching critical stock limits</p>
            </div>
            <button
              onClick={() => onSelectTab('products')}
              className="text-xs text-amber-400 hover:text-amber-300 font-bold flex items-center gap-1 cursor-pointer"
            >
              <span>Manage Stock</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {lowStockProducts.length === 0 ? (
            <div className="py-8 text-center text-stone-400 text-xs">
              <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
              <p className="font-semibold text-stone-200">All fabric stock levels are healthy!</p>
              <p className="text-[11px] text-stone-500 mt-0.5">No products below 20 meters remaining.</p>
            </div>
          ) : (
            <div className="space-y-3 max-h-[300px] overflow-y-auto pr-1">
              {lowStockProducts.map(({ product, variant }) => (
                <div 
                  key={`${product.id}-${variant.id}`}
                  className="p-3 bg-stone-950/60 border border-stone-800 rounded-xl flex items-center justify-between gap-3 text-xs"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-10 h-10 rounded-lg object-cover border border-stone-700 shrink-0"
                    />
                    <div className="min-w-0">
                      <h4 className="font-bold text-white truncate text-xs">{product.name}</h4>
                      <p className="text-[11px] text-amber-300/90 font-mono mt-0.5">
                        Sizes: {product.lengthOptions.map(l => `${l.lengthMeters}m`).join(' • ')}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <span className="font-mono font-bold text-orange-400 bg-orange-950/80 border border-orange-800/80 px-2 py-0.5 rounded text-xs">
                      {product.totalStock ?? variant.stock}m left
                    </span>
                    <button
                      onClick={() => updateProductStock(product.id, variant.id, (product.totalStock ?? variant.stock) + 20)}
                      className="px-2.5 py-1 rounded-lg bg-amber-800 hover:bg-amber-700 text-white font-bold text-[11px] transition cursor-pointer"
                      title="Add +20 meters to inventory"
                    >
                      +20m
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
