import React, { useState } from 'react';
import { useShop } from '../../context/ShopContext';
import { Product, ProductVariant, FabricLengthOption } from '../../types';
import { ProductImageUploader } from './ProductImageUploader';
import { 
  Shirt, 
  PlusCircle, 
  Search, 
  Filter, 
  Edit3, 
  Trash2, 
  AlertTriangle, 
  Check, 
  X, 
  Layers, 
  Tag, 
  Eye,
  Plus
} from 'lucide-react';

interface AdminProductsViewProps {
  onOpenAddModal: () => void;
}

export const AdminProductsView: React.FC<AdminProductsViewProps> = ({ onOpenAddModal }) => {
  const { products, updateProduct, deleteProduct, updateProductStock } = useShop();

  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [showLowStockOnly, setShowLowStockOnly] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [deletingProductId, setDeletingProductId] = useState<string | null>(null);

  const filtered = products.filter(p => {
    if (categoryFilter !== 'all' && p.category !== categoryFilter) {
      return false;
    }
    if (showLowStockOnly) {
      const stock = p.totalStock ?? (p.variants?.[0]?.stock ?? 0);
      const hasLowStock = stock <= 20;
      if (!hasLowStock) return false;
    }
    if (search.trim()) {
      const q = search.toLowerCase().trim();
      const matchName = p.name.toLowerCase().includes(q) || p.nameHi.toLowerCase().includes(q);
      const matchBrand = p.brand.toLowerCase().includes(q);
      const matchMaterial = p.material.toLowerCase().includes(q);
      return matchName || matchBrand || matchMaterial;
    }
    return true;
  });

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingProduct) {
      if (!editingProduct.image) {
        alert('Please upload at least one product image.');
        return;
      }
      updateProduct(editingProduct);
      setEditingProduct(null);
    }
  };

  const handleConfirmDelete = () => {
    if (deletingProductId) {
      deleteProduct(deletingProductId);
      setDeletingProductId(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Title & Add Product Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-stone-800">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-white font-serif">
            Fabric Catalog & Stock Inventory
          </h1>
          <p className="text-xs text-stone-400 mt-0.5">
            Total {products.length} active fabric designs • Live stock tracking per meter
          </p>
        </div>

        <button
          onClick={onOpenAddModal}
          className="bg-amber-800 hover:bg-amber-700 text-white font-bold px-4 py-2 rounded-xl text-xs flex items-center justify-center gap-1.5 transition shadow-sm cursor-pointer self-start sm:self-auto"
        >
          <PlusCircle className="w-4 h-4 text-amber-200" />
          <span>+ Add New Fabric</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        {/* Category Filters */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {[
            { id: 'all', label: 'All Fabrics' },
            { id: 'shirt', label: 'Shirt Fabric' },
            { id: 'pant', label: 'Pant Fabric' },
            { id: 'combo', label: 'Combo Sets' },
            { id: 'premium', label: 'Premium Suiting' }
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => setCategoryFilter(cat.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer ${
                categoryFilter === cat.id
                  ? 'bg-amber-800 text-white shadow-xs'
                  : 'bg-stone-900 text-stone-400 hover:text-white border border-stone-800'
              }`}
            >
              {cat.label}
            </button>
          ))}

          {/* Low Stock Toggle button */}
          <button
            onClick={() => setShowLowStockOnly(!showLowStockOnly)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
              showLowStockOnly
                ? 'bg-orange-900 text-orange-200 border border-orange-700'
                : 'bg-stone-900 text-stone-400 hover:text-orange-400 border border-stone-800'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Low Stock (≤20m)</span>
          </button>
        </div>

        {/* Search Input */}
        <div className="relative w-full sm:w-64">
          <span className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-stone-500">
            <Search className="w-4 h-4" />
          </span>
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search fabrics by name or brand..."
            className="w-full pl-9 pr-3 py-2 bg-stone-900 border border-stone-700 rounded-xl text-stone-200 text-xs focus:outline-none focus:ring-1 focus:ring-amber-500 font-medium"
          />
        </div>
      </div>

      {/* Products Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((prod) => {
          const totalStock = prod.totalStock ?? (prod.variants?.reduce((acc, v) => acc + v.stock, 0) || 0);
          const hasLowVariant = totalStock <= 20;

          return (
            <div
              key={prod.id}
              className="bg-stone-900 border border-stone-800 rounded-2xl overflow-hidden shadow-sm flex flex-col justify-between"
            >
              {/* Image & Price Tag */}
              <div className="relative h-44 bg-stone-950 overflow-hidden">
                <img
                  src={prod.image}
                  alt={prod.name}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5">
                  <span className="bg-stone-950/80 backdrop-blur-xs text-white text-[11px] font-bold px-2.5 py-0.5 rounded-lg border border-stone-700">
                    {prod.brand}
                  </span>
                  {hasLowVariant && (
                    <span className="bg-orange-950/90 text-orange-300 text-[10px] font-bold px-2 py-0.5 rounded-lg border border-orange-800 flex items-center gap-1">
                      <AlertTriangle className="w-3 h-3" />
                      Low Stock
                    </span>
                  )}
                </div>

                <div className="absolute bottom-2.5 right-2.5 bg-amber-900 text-white font-black text-xs px-2.5 py-1 rounded-lg shadow-md">
                  ₹{prod.discountPrice}{' '}
                  <span className="line-through text-stone-300 text-[10px] font-normal">₹{prod.originalPrice}</span>
                </div>
              </div>

              {/* Body */}
              <div className="p-4 space-y-3 flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="font-bold text-white text-sm line-clamp-1">{prod.name}</h3>
                  <p className="text-[11px] text-stone-400 mt-0.5 line-clamp-1">{prod.nameHi}</p>

                  <div className="flex items-center gap-2 text-[11px] text-stone-400 mt-2">
                    <span className="capitalize">{prod.category} Fabric</span>
                    <span>•</span>
                    <span>{prod.material}</span>
                  </div>
                </div>

                {/* Sizes & Stock */}
                <div className="pt-2 border-t border-stone-800/80 space-y-2 text-xs">
                  <div className="flex items-center justify-between text-stone-400 text-[11px]">
                    <span className="font-bold uppercase tracking-wider">Cuts / Sizes:</span>
                    <span className="font-mono font-bold text-amber-400">
                      {prod.lengthOptions.map(l => `${l.lengthMeters}m`).join(' • ')}
                    </span>
                  </div>

                  <div className="bg-stone-950 p-2.5 rounded-xl border border-stone-800 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] uppercase font-bold text-stone-400 block">Total Roll Stock</span>
                      <span className={`font-mono text-xs font-bold ${totalStock <= 20 ? 'text-orange-400' : 'text-emerald-400'}`}>
                        {totalStock} Meters Available
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5">
                      <button
                        onClick={() => {
                          const primaryVarId = prod.variants?.[0]?.id || 'std';
                          updateProductStock(prod.id, primaryVarId, Math.max(0, totalStock - 10));
                        }}
                        className="px-2 py-1 rounded-lg bg-stone-800 hover:bg-stone-700 text-stone-300 font-bold text-xs cursor-pointer border border-stone-700"
                        title="Deduct 10 meters"
                      >
                        -10m
                      </button>
                      <button
                        onClick={() => {
                          const primaryVarId = prod.variants?.[0]?.id || 'std';
                          updateProductStock(prod.id, primaryVarId, totalStock + 20);
                        }}
                        className="px-2 py-1 rounded-lg bg-amber-800 hover:bg-amber-700 text-white font-bold text-xs cursor-pointer border border-amber-700"
                        title="Add 20 meters"
                      >
                        +20m
                      </button>
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="pt-3 border-t border-stone-800 flex items-center justify-between gap-2">
                  <button
                    onClick={() => setEditingProduct(prod)}
                    className="flex-1 py-1.5 px-3 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-200 text-xs font-bold flex items-center justify-center gap-1.5 transition cursor-pointer"
                  >
                    <Edit3 className="w-3.5 h-3.5 text-amber-400" />
                    <span>Edit Fabric</span>
                  </button>

                  <button
                    onClick={() => setDeletingProductId(prod.id)}
                    className="py-1.5 px-3 rounded-xl bg-stone-800 hover:bg-red-950 hover:text-red-400 text-stone-400 text-xs font-bold transition cursor-pointer flex items-center gap-1"
                    title="Delete Fabric"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Delete</span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Edit Product Modal */}
      {editingProduct && (
        <div className="fixed inset-0 z-50 bg-stone-950/80 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <form 
            onSubmit={handleSaveEdit}
            className="bg-stone-900 border border-stone-800 rounded-2xl max-w-xl w-full p-6 space-y-4 text-xs shadow-2xl my-auto text-stone-300"
          >
            <div className="flex items-center justify-between pb-3 border-b border-stone-800">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Edit3 className="w-4 h-4 text-amber-400" />
                Edit Fabric Details
              </h3>
              <button 
                type="button" 
                onClick={() => setEditingProduct(null)}
                className="text-stone-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block font-bold text-stone-400 mb-1">Fabric Title (English)</label>
                <input
                  type="text"
                  required
                  value={editingProduct.name}
                  onChange={(e) => setEditingProduct({ ...editingProduct, name: e.target.value })}
                  className="w-full px-3 py-2 bg-stone-950 border border-stone-700 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>

              <div>
                <label className="block font-bold text-stone-400 mb-1">Fabric Title (Hindi)</label>
                <input
                  type="text"
                  required
                  value={editingProduct.nameHi}
                  onChange={(e) => setEditingProduct({ ...editingProduct, nameHi: e.target.value })}
                  className="w-full px-3 py-2 bg-stone-950 border border-stone-700 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-stone-400 mb-1">Brand Name</label>
                  <input
                    type="text"
                    required
                    value={editingProduct.brand}
                    onChange={(e) => setEditingProduct({ ...editingProduct, brand: e.target.value })}
                    className="w-full px-3 py-2 bg-stone-950 border border-stone-700 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                  />
                </div>
                <div>
                  <label className="block font-bold text-stone-400 mb-1">Category</label>
                  <select
                    value={editingProduct.category}
                    onChange={(e) => setEditingProduct({ ...editingProduct, category: e.target.value as any })}
                    className="w-full px-3 py-2 bg-stone-950 border border-stone-700 rounded-xl text-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                  >
                    <option value="shirt">Shirt Fabric</option>
                    <option value="pant">Pant Fabric</option>
                    <option value="combo">Shirt + Pant Combo</option>
                    <option value="premium">Premium Suiting</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-stone-400 mb-1">Original Price (MRP)</label>
                  <input
                    type="number"
                    required
                    value={editingProduct.originalPrice}
                    onChange={(e) => setEditingProduct({ ...editingProduct, originalPrice: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-stone-950 border border-stone-700 rounded-xl text-white font-mono"
                  />
                </div>
                <div>
                  <label className="block font-bold text-stone-400 mb-1">Discount Price (Selling Price)</label>
                  <input
                    type="number"
                    required
                    value={editingProduct.discountPrice}
                    onChange={(e) => setEditingProduct({ ...editingProduct, discountPrice: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-stone-950 border border-stone-700 rounded-xl text-white font-mono"
                  />
                </div>
              </div>

              {/* Product Images (Upload & Gallery) */}
              <ProductImageUploader
                primaryImage={editingProduct.image}
                additionalImages={editingProduct.additionalImages || []}
                onChange={(primary, additionals) => {
                  setEditingProduct({
                    ...editingProduct,
                    image: primary,
                    additionalImages: additionals
                  });
                }}
              />

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-bold text-stone-400 mb-1">Material & Specs</label>
                  <input
                    type="text"
                    value={editingProduct.material}
                    onChange={(e) => setEditingProduct({ ...editingProduct, material: e.target.value })}
                    placeholder="e.g. 100% Giza Cotton"
                    className="w-full px-3 py-2 bg-stone-950 border border-stone-700 rounded-xl text-white text-xs"
                  />
                </div>
                <div>
                  <label className="block font-bold text-stone-400 mb-1">Available Stock (Meters)</label>
                  <input
                    type="number"
                    min="0"
                    value={editingProduct.totalStock ?? (editingProduct.variants?.[0]?.stock ?? 100)}
                    onChange={(e) => {
                      const val = Number(e.target.value);
                      setEditingProduct({
                        ...editingProduct,
                        totalStock: val,
                        variants: editingProduct.variants?.map(v => ({ ...v, stock: val })) || [
                          { id: 'std', colorName: 'Standard', hex: '#333333', stock: val, image: editingProduct.image }
                        ]
                      });
                    }}
                    className="w-full px-3 py-2 bg-stone-950 border border-stone-700 rounded-xl text-white font-mono"
                  />
                </div>
              </div>

              {/* Sizes overview */}
              <div className="p-2.5 rounded-xl bg-stone-950 border border-stone-800 flex items-center justify-between">
                <div>
                  <span className="font-bold text-white text-xs block">Enabled Fabric Cuts</span>
                  <span className="text-[10px] text-stone-400">1.2m (Pant/Half) & 2.25m (Kurta/Pathani)</span>
                </div>
                <span className="text-[10px] font-bold text-amber-400 bg-amber-950/60 border border-amber-800 px-2 py-0.5 rounded">Active</span>
              </div>
            </div>

            <div className="pt-3 border-t border-stone-800 flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setEditingProduct(null)}
                className="px-3 py-2 rounded-xl bg-stone-800 text-stone-300 font-bold hover:bg-stone-700 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 rounded-xl bg-amber-800 hover:bg-amber-700 text-white font-bold cursor-pointer"
              >
                Save Changes
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deletingProductId && (
        <div className="fixed inset-0 z-50 bg-stone-950/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-stone-900 border border-red-900/60 rounded-2xl max-w-md w-full p-5 space-y-4 shadow-2xl">
            <h3 className="text-sm font-bold text-white flex items-center gap-2 text-red-400">
              <Trash2 className="w-4 h-4" />
              Delete Product Confirmation
            </h3>
            <p className="text-xs text-stone-300">
              Are you sure you want to remove this fabric product from the store catalog? Customers will no longer be able to buy it.
            </p>
            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setDeletingProductId(null)}
                className="px-3 py-2 rounded-xl bg-stone-800 text-stone-300 text-xs font-bold hover:bg-stone-700 cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmDelete}
                className="px-4 py-2 rounded-xl bg-red-800 hover:bg-red-700 text-white text-xs font-bold cursor-pointer"
              >
                Confirm Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
