import React from 'react';
import { useShop } from '../context/ShopContext';
import { ArrowRight, Sparkles, CheckCircle2, ShieldCheck, Banknote, Eye, Star } from 'lucide-react';

export const Banner: React.FC = () => {
  const { setSelectedCategory, language, openModal, products } = useShop();

  const handleHeroClick = () => {
    setSelectedCategory('combo');
  };

  const handleQuickBuy = () => {
    // Open product modal for popular combo
    const featured = products.find(p => p.id === 'smk-03') || products[0];
    openModal('product', featured);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 pt-4 sm:pt-6">
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-[#111111] via-[#1E1E1E] to-[#151515] text-white shadow-xl border border-[#2B2B2B]">
        {/* Background Subtle Textile Pattern */}
        <div className="absolute inset-0 opacity-15 bg-[radial-gradient(#C8A96B_1px,transparent_1px)] [background-size:16px_16px]"></div>

        <div className="relative grid grid-cols-1 lg:grid-cols-12 gap-6 items-center p-6 sm:p-8 md:p-10">
          {/* Left Text Column */}
          <div className="lg:col-span-7 space-y-4">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-[#C8A96B]/15 text-[#C8A96B] border border-[#C8A96B]/30 rounded-lg text-xs font-bold uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5 text-[#C8A96B]" />
              <span>{language === 'hi' ? 'त्योहार व शादी स्पेशल सेल' : 'Festive & Wedding Fabric Special'}</span>
            </div>

            <h1 className="text-2xl sm:text-4xl md:text-5xl font-black font-serif tracking-tight text-white leading-tight">
              {language === 'hi' ? (
                <>प्रीमियम शर्ट व पैंट फैब्रिक पर <span className="text-[#C8A96B]">50% तक की छूट</span></>
              ) : (
                <>Pure & Tailor-Grade Fabrics <span className="text-[#C8A96B]">Up to 50% OFF</span></>
              )}
            </h1>

            <p className="text-sm sm:text-base text-[#D9D4CA] max-w-xl font-normal leading-relaxed">
              {language === 'hi' 
                ? '100% असली रेमंड, अरविंद और सियाराम ब्रांड के कपड़े। बिना किसी झंझट के घर बैठे मंगाएं और कपड़ा मिलने पर नकद पैसे दें।'
                : 'Genuine 100% Giza Cotton, Pure Linen & Wrinkle-Free Trouser lengths. Delivered to your doorstep with Cash on Delivery.'}
            </p>

            {/* Trust bullet badges */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 pt-1 text-xs text-[#D9D4CA]">
              <div className="flex items-center gap-1.5 font-medium">
                <CheckCircle2 className="w-4 h-4 text-[#C8A96B] shrink-0" />
                <span>{language === 'hi' ? '100% असली कपड़ा' : '100% Genuine Cut'}</span>
              </div>
              <div className="flex items-center gap-1.5 font-medium">
                <Banknote className="w-4 h-4 text-[#C8A96B] shrink-0" />
                <span>{language === 'hi' ? 'घर पर नकद भुगतान (COD)' : 'Cash on Delivery'}</span>
              </div>
              <div className="flex items-center gap-1.5 font-medium">
                <ShieldCheck className="w-4 h-4 text-[#C8A96B] shrink-0" />
                <span>{language === 'hi' ? '7 दिन आसान वापसी' : '7 Days Easy Return'}</span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-3">
              <button
                onClick={handleHeroClick}
                className="bg-[#C8A96B] hover:bg-[#b8985a] text-[#111111] font-bold px-6 py-3.5 rounded-xl shadow-md transition flex items-center gap-2 cursor-pointer text-sm sm:text-base active:scale-95"
              >
                <span>{language === 'hi' ? 'शर्ट + पैंट कॉम्बो देखें' : 'Shop Shirt + Pant Combos'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={handleQuickBuy}
                className="bg-white/10 hover:bg-white/20 text-white font-semibold px-5 py-3.5 rounded-xl border border-white/25 transition text-sm sm:text-base cursor-pointer"
              >
                {language === 'hi' ? 'बेस्ट सेलर कपड़ा देखें' : 'View #1 Best Seller'}
              </button>
            </div>
          </div>

          {/* Right Signature Visual Column */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto rounded-2xl overflow-hidden shadow-2xl border-2 border-[#C8A96B]/40 group bg-[#111111] max-w-md">
              <div className="relative h-80 sm:h-96 md:h-[420px] w-full overflow-hidden">
                <img
                  src="/src/assets/images/hero_model_portrait_1790689718903.jpg"
                  alt="Shree Maruti Krupa Signature Collection"
                  className="w-full h-full object-cover object-top filter brightness-100 contrast-105 transition-transform duration-700 group-hover:scale-105"
                  referrerPolicy="no-referrer"
                />

                {/* Subtle gradient vignette */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent pointer-events-none" />

                {/* Top Badges */}
                <div className="absolute top-3 left-3 z-10">
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#111111]/90 backdrop-blur-md border border-[#C8A96B]/50 text-[#C8A96B] text-xs font-black tracking-wider uppercase shadow-md">
                    <Sparkles className="w-3.5 h-3.5" />
                    {language === 'hi' ? 'सिग्नेचर कलेक्शन' : 'SIGNATURE LOOK'}
                  </span>
                </div>

                <div className="absolute top-3 right-3 z-10">
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-emerald-600 text-white text-xs font-black shadow-md">
                    45% OFF
                  </span>
                </div>

                {/* Bottom Overlay Info & Quick Action */}
                <div className="absolute inset-x-0 bottom-0 p-4 z-10 flex items-end justify-between gap-3">
                  <div>
                    <span className="text-[#C8A96B] text-[11px] font-bold uppercase tracking-wider block">
                      {language === 'hi' ? 'रॉयल लिनन शर्ट + चारकोल पैंट' : 'Pure Linen Shirt + Trouser Pair'}
                    </span>
                    <h3 className="text-white font-bold text-sm sm:text-base leading-snug">
                      {language === 'hi' ? '2.25m शर्ट + 1.20m पैंट कॉम्बो' : '2.25m Shirt + 1.20m Pant Combo'}
                    </h3>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-emerald-400 font-extrabold text-base">₹1,199</span>
                      <span className="line-through text-gray-400 text-xs">₹2,199</span>
                      <span className="flex items-center text-amber-400 text-xs font-bold gap-0.5 ml-1">
                        <Star className="w-3 h-3 fill-current" /> 4.9
                      </span>
                    </div>
                  </div>

                  <button
                    onClick={handleQuickBuy}
                    className="bg-[#C8A96B] hover:bg-[#b8985a] text-[#111111] font-black px-4 py-2.5 rounded-xl text-xs sm:text-sm shadow-lg transition active:scale-95 cursor-pointer whitespace-nowrap flex items-center gap-1.5"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>{language === 'hi' ? 'अभी खरीदें' : 'Buy Look'}</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
