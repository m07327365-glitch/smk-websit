import React from 'react';
import { Product } from '../types';
import { useShop } from '../context/ShopContext';
import { Star, ShoppingBag, Heart, Check, Zap } from 'lucide-react';

interface ProductCardProps {
  product: Product;
}

export const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { 
    language, 
    addToCart, 
    wishlist, 
    toggleWishlist, 
    openModal, 
    t 
  } = useShop();

  const isWishlisted = wishlist.includes(product.id);

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.stopPropagation();
    // Add default length with 1 tap!
    const defaultVariant = product.variants?.[0] || {
      id: 'std',
      colorName: 'Standard',
      hex: '#333333',
      image: product.image,
      stock: product.totalStock || 100
    };
    const defaultLength = product.lengthOptions[0];
    addToCart(product, defaultVariant, defaultLength, 1);
  };

  const handleCardClick = () => {
    openModal('product', product);
  };

  const handleBuyNow = (e: React.MouseEvent) => {
    e.stopPropagation();
    openModal('product', product);
  };

  return (
    <div 
      onClick={handleCardClick}
      className="group bg-white rounded-2xl border border-[#E5E0D8] shadow-2xs hover:shadow-md transition-all duration-200 overflow-hidden flex flex-col justify-between cursor-pointer relative"
    >
      {/* Top Image Container */}
      <div className="relative aspect-4/3 sm:aspect-square bg-[#F7F5F0] overflow-hidden">
        <img
          src={product.image}
          alt={product.name}
          loading="lazy"
          className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-300"
        />

        {/* Badges Overlay */}
        <div className="absolute top-2.5 left-2.5 flex flex-col gap-1 items-start">
          {product.isBestSeller && (
            <span className="bg-[#111111] text-white text-[11px] font-bold px-2 py-0.5 rounded shadow-xs uppercase tracking-wider border border-[#C8A96B]/50">
              {language === 'hi' ? 'बेस्ट सेलर' : 'Best Seller'}
            </span>
          )}
          {product.discountPercent > 0 && (
            <span className="bg-[#9B2C2C] text-white text-[11px] font-bold px-2 py-0.5 rounded shadow-xs">
              {product.discountPercent}% OFF
            </span>
          )}
        </div>

        {/* Wishlist Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            toggleWishlist(product.id);
          }}
          className={`absolute top-2.5 right-2.5 w-9 h-9 rounded-full flex items-center justify-center transition shadow-xs cursor-pointer border ${
            isWishlisted
              ? 'bg-white text-[#9B2C2C] border-[#9B2C2C]/30'
              : 'bg-white/90 text-[#777777] hover:text-[#9B2C2C] hover:bg-white border-[#E5E0D8]'
          }`}
          aria-label="Save to Wishlist"
          title={isWishlisted ? 'Remove from Wishlist' : 'Add to Wishlist'}
        >
          <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-[#9B2C2C]' : ''}`} />
        </button>

        {/* Size Cuts Badge */}
        <div className="absolute bottom-2 left-2 bg-[#111111]/90 backdrop-blur-xs text-white text-[10px] font-bold px-2 py-0.5 rounded flex items-center gap-1.5 shadow-xs border border-[#2B2B2B]">
          <span className="text-[#D9D4CA]">{language === 'hi' ? 'साइज:' : 'Size:'}</span>
          <span className="text-[#C8A96B] font-mono">
            {product.lengthOptions && product.lengthOptions.length > 0
              ? product.lengthOptions.map(o => o.label.split('-')[0].trim()).join(' | ')
              : product.defaultLength}
          </span>
        </div>
      </div>

      {/* Card Details Body */}
      <div className="p-3.5 sm:p-4 flex-1 flex flex-col justify-between">
        <div>
          {/* Brand Name & Rating */}
          <div className="flex items-center justify-between text-xs text-[#777777] mb-1">
            <span className="font-semibold text-[#777777] uppercase tracking-wider text-[11px]">
              {product.brand}
            </span>
            <div className="flex items-center gap-1 bg-[#F7F5F0] border border-[#E5E0D8] px-1.5 py-0.5 rounded text-[#111111] font-bold text-xs">
              <Star className="w-3 h-3 fill-[#C8A96B] text-[#C8A96B]" />
              <span>{product.rating}</span>
              <span className="text-[#777777] font-normal">({product.reviewCount})</span>
            </div>
          </div>

          {/* Product Name */}
          <h2 className="text-sm sm:text-base font-bold text-[#111111] line-clamp-2 leading-snug group-hover:text-[#C8A96B] transition mb-1.5">
            {language === 'hi' ? product.nameHi : product.name}
          </h2>

          {/* Fabric Type / Material Hint */}
          <p className="text-xs text-[#4A4A4A] line-clamp-1 mb-2 font-medium">
            {product.material} • {product.defaultLength}
          </p>
        </div>

        <div>
          {/* Price & Discount */}
          <div className="flex items-baseline gap-2 mb-3">
            <span className="text-lg sm:text-xl font-extrabold text-[#111111]">
              ₹{product.discountPrice}
            </span>
            <span className="text-xs sm:text-sm text-[#777777] line-clamp-1 line-through">
              MRP ₹{product.originalPrice}
            </span>
            <span className="text-xs font-bold text-[#9B2C2C]">
              ({product.discountPercent}% {language === 'hi' ? 'छूट' : 'OFF'})
            </span>
          </div>

          {/* Primary Action Buttons */}
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={handleQuickAdd}
              className="w-full bg-[#F7F5F0] hover:bg-[#E5E0D8] text-[#111111] font-bold py-2.5 px-2 rounded-xl text-xs sm:text-sm flex items-center justify-center gap-1.5 transition active:scale-95 border border-[#E5E0D8] hover:border-[#C8A96B] cursor-pointer"
            >
              <ShoppingBag className="w-4 h-4 text-[#C8A96B]" />
              <span>{language === 'hi' ? 'कार्ट में जोड़ें' : 'Add to Cart'}</span>
            </button>

            <button
              onClick={handleBuyNow}
              className="w-full bg-[#111111] hover:bg-[#2B2B2B] text-white font-bold py-2.5 px-2 rounded-xl text-xs sm:text-sm flex items-center justify-center gap-1 transition active:scale-95 cursor-pointer shadow-xs"
            >
              <Zap className="w-3.5 h-3.5 text-[#C8A96B] fill-[#C8A96B]" />
              <span>{language === 'hi' ? 'सीधे खरीदें' : 'Buy Now'}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
