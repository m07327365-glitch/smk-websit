import React, { useState } from 'react';
import { useShop } from '../context/ShopContext';
import { 
  X, 
  PhoneCall, 
  MessageCircle, 
  HelpCircle, 
  ChevronDown, 
  ChevronUp, 
  Package, 
  Truck, 
  RotateCcw, 
  CreditCard,
  CheckCircle2
} from 'lucide-react';

interface SupportModalProps {
  onClose: () => void;
}

export const SupportModal: React.FC<SupportModalProps> = ({ onClose }) => {
  const { language, t } = useShop();

  const [activeCategory, setActiveCategory] = useState<'order' | 'delivery' | 'return' | 'payment'>('order');
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);
  const [callbackNumber, setCallbackNumber] = useState('');
  const [callbackRequested, setCallbackRequested] = useState(false);

  const faqs = {
    order: [
      {
        qEn: 'How much fabric is required for a regular shirt?',
        qHi: 'सामान्य शर्ट के लिए कितना कपड़ा लेना चाहिए?',
        aEn: 'For standard full-sleeve shirts up to size 44, 1.60 meters is standard. For extra tall height or size 46+, select 1.80m or 2.00m.',
        aHi: '44 साइज तक की पूरी आस्तीन की शर्ट के लिए 1.60 मीटर कपड़ा काफी है। 46+ साइज या 6 फीट से अधिक ऊंचाई के लिए 1.80 मीटर चुनें।'
      },
      {
        qEn: 'How much fabric is needed for formal trousers / pants?',
        qHi: 'फॉर्मल पैंट के लिए कितने मीटर कपड़े की जरूरत होती है?',
        aEn: '1.20 meters is sufficient for waist size up to 38. For waist 40+ or pleated trousers, select 1.30m.',
        aHi: '38 कमर तक की पैंट के लिए 1.20 मीटर काफी है। 40+ कमर या प्लेटेड पैंट के लिए 1.30 मीटर चुनें।'
      }
    ],
    delivery: [
      {
        qEn: 'How long does delivery take?',
        qHi: 'डिलीवरी में कितना समय लगता है?',
        aEn: 'Standard delivery takes 3 to 4 working days across all pincodes in India. Express priority delivery takes 1 to 2 days.',
        aHi: 'पूरे भारत में साधारण डिलीवरी 3 से 4 दिन में पहुंचती है। फास्ट एक्सप्रेस डिलीवरी 1 से 2 दिन में पहुंचती है।'
      },
      {
        qEn: 'Are there any delivery charges?',
        qHi: 'क्या डिलीवरी का कोई अलग चार्ज है?',
        aEn: 'All orders of ₹499 and above enjoy 100% FREE delivery. Below ₹499, standard delivery is just ₹40.',
        aHi: '₹499 या उससे अधिक के सभी ऑर्डर पर डिलीवरी बिल्कुल मुफ्त है।'
      }
    ],
    return: [
      {
        qEn: 'What is the return policy if I do not like the fabric?',
        qHi: 'अगर मुझे कपड़ा पसंद न आए तो वापसी का क्या नियम है?',
        aEn: 'We offer a 7-day doorstep return policy. Open My Orders, click Return, and our courier agent will pick it up from your house for free.',
        aHi: 'हम 7 दिनों का आसान रिटर्न देते हैं। \'मेरे ऑर्डर\' में जाएं, \'वापसी\' बटन दबाएं और हमारा कूरियर आपके घर आकर कपड़ा ले जाएगा।'
      },
      {
        qEn: 'When do I get my refund back?',
        qHi: 'रिफंड के पैसे कब वापस मिलते हैं?',
        aEn: 'As soon as the courier collects the fabric, the refund is initiated to your bank account / UPI within 24 hours.',
        aHi: 'कूरियर द्वारा कपड़ा पिकअप करते ही 24 घंटे में आपके बैंक खाते या UPI में पैसे ट्रांसफर कर दिए जाते हैं।'
      }
    ],
    payment: [
      {
        qEn: 'Can I pay Cash on Delivery (COD)?',
        qHi: 'क्या मैं घर पर डिलीवरी के समय नकद भुगतान (COD) कर सकता हूँ?',
        aEn: 'Yes! Cash on Delivery is available across all Indian pincodes with zero advance payment required.',
        aHi: 'हाँ! पूरे भारत में कैश ऑन डिलीवरी (COD) उपलब्ध है। जब कपड़ा आपके हाथ में आए, तभी नकद पैसे दें।'
      },
      {
        qEn: 'Is online UPI payment safe?',
        qHi: 'क्या ऑनलाइन UPI पेमेंट सुरक्षित है?',
        aEn: '100% secure. You can pay via Google Pay, PhonePe, Paytm, BHIM, or Debit/Credit cards through encrypted gateways.',
        aHi: 'बिल्कुल 100% सुरक्षित है। आप गूगल पे, फोनपे, पेटीएम या एटीएम कार्ड से सुरक्षित भुगतान कर सकते हैं।'
      }
    ]
  };

  const handleWhatsApp = () => {
    window.open('https://wa.me/919876543210?text=Hello%20Shree%20Maruti%20Krupa%2C%20I%20need%20help%20with%20fabric%20shopping.', '_blank');
  };

  const handleCall = () => {
    window.location.href = 'tel:18002005588';
  };

  const handleCallbackSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (callbackNumber.trim().length >= 10) {
      setCallbackRequested(true);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-stone-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-xl w-full my-auto overflow-hidden shadow-2xl border border-[#E5E0D8]">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[#E5E0D8] bg-[#F7F5F0] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-[#111111] flex items-center justify-center text-[#C8A96B]">
              <HelpCircle className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-[#111111]">
                {language === 'hi' ? 'ग्राहक सहायता केंद्र' : 'Help & Customer Support'}
              </h2>
              <p className="text-xs text-[#777777]">
                {language === 'hi' ? 'हम आपकी मदद के लिए सदैव उपस्थित हैं' : 'We are always happy to assist you'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-white hover:bg-[#E5E0D8] text-[#111111] border border-[#E5E0D8] flex items-center justify-center transition cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 sm:p-6 space-y-5 max-h-[75vh] overflow-y-auto">
          {/* Quick Contact Buttons */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            <button
              onClick={handleWhatsApp}
              className="bg-[#25D366] hover:bg-[#1EBE5D] text-white font-bold p-3.5 rounded-xl flex items-center justify-center gap-2 transition shadow-xs cursor-pointer"
            >
              <MessageCircle className="w-5 h-5" />
              <span className="text-xs sm:text-sm">{language === 'hi' ? 'व्हाट्सएप पर बात करें' : 'Chat on WhatsApp'}</span>
            </button>

            <button
              onClick={handleCall}
              className="bg-[#111111] hover:bg-[#2B2B2B] text-white font-bold p-3.5 rounded-xl flex items-center justify-center gap-2 transition shadow-xs cursor-pointer"
            >
              <PhoneCall className="w-5 h-5 text-[#C8A96B]" />
              <span className="text-xs sm:text-sm">{language === 'hi' ? 'कॉल करें: 1800-200-5588' : 'Call: 1800-200-5588'}</span>
            </button>
          </div>

          <p className="text-[11px] text-center text-[#777777] font-medium">
            {language === 'hi' 
              ? 'हेल्पलाइन समय: सोमवार से रविवार • सुबह 9:00 से रात 8:00 बजे तक' 
              : 'Helpline Hours: Monday to Sunday • 9:00 AM to 8:00 PM'}
          </p>

          {/* 4 Help Topics */}
          <div>
            <h3 className="text-xs font-bold text-[#111111] uppercase tracking-wide mb-2.5">
              {language === 'hi' ? 'विषय अनुसार मदद चुनें:' : 'Select Help Topic:'}
            </h3>

            <div className="grid grid-cols-4 gap-1.5 p-1 bg-[#F7F5F0] border border-[#E5E0D8] rounded-xl mb-3">
              {[
                { key: 'order', labelEn: 'Order', labelHi: 'ऑर्डर', icon: <Package className="w-3.5 h-3.5" /> },
                { key: 'delivery', labelEn: 'Delivery', labelHi: 'डिलीवरी', icon: <Truck className="w-3.5 h-3.5" /> },
                { key: 'return', labelEn: 'Returns', labelHi: 'वापसी', icon: <RotateCcw className="w-3.5 h-3.5" /> },
                { key: 'payment', labelEn: 'Payment', labelHi: 'भुगतान', icon: <CreditCard className="w-3.5 h-3.5" /> },
              ].map((tab) => (
                <button
                  key={tab.key}
                  onClick={() => {
                    setActiveCategory(tab.key as any);
                    setOpenFaqIndex(0);
                  }}
                  className={`py-2 px-1 rounded-lg text-xs font-bold transition flex flex-col sm:flex-row items-center justify-center gap-1 cursor-pointer ${
                    activeCategory === tab.key
                      ? 'bg-[#111111] text-white shadow-xs'
                      : 'text-[#4A4A4A] hover:text-[#111111]'
                  }`}
                >
                  <span className={activeCategory === tab.key ? 'text-[#C8A96B]' : ''}>{tab.icon}</span>
                  <span>{language === 'hi' ? tab.labelHi : tab.labelEn}</span>
                </button>
              ))}
            </div>

            {/* Accordion list */}
            <div className="space-y-2">
              {faqs[activeCategory].map((faq, index) => {
                const isOpen = openFaqIndex === index;
                return (
                  <div key={index} className="border border-[#E5E0D8] rounded-xl overflow-hidden bg-white">
                    <button
                      onClick={() => setOpenFaqIndex(isOpen ? null : index)}
                      className="w-full text-left p-3.5 flex items-center justify-between text-xs sm:text-sm font-bold text-[#111111] hover:bg-[#F7F5F0] transition cursor-pointer"
                    >
                      <span>{language === 'hi' ? faq.qHi : faq.qEn}</span>
                      {isOpen ? <ChevronUp className="w-4 h-4 text-[#777777]" /> : <ChevronDown className="w-4 h-4 text-[#777777]" />}
                    </button>
                    {isOpen && (
                      <div className="p-3.5 pt-0 text-xs text-[#4A4A4A] border-t border-[#E5E0D8] bg-[#F7F5F0]/50 leading-relaxed">
                        {language === 'hi' ? faq.aHi : faq.aEn}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Callback Request */}
          <div className="bg-[#F7F5F0] p-4 rounded-xl border border-[#E5E0D8]">
            {callbackRequested ? (
              <div className="text-center py-2 space-y-1">
                <CheckCircle2 className="w-6 h-6 text-[#111111] mx-auto" />
                <p className="text-xs font-bold text-[#111111]">
                  {language === 'hi' ? 'अनुरोध प्राप्त हुआ! हमारे प्रतिनिधि 10 मिनट में कॉल करेंगे।' : 'Callback scheduled! Our executive will call in 10 minutes.'}
                </p>
              </div>
            ) : (
              <form onSubmit={handleCallbackSubmit} className="space-y-2">
                <span className="text-xs font-bold text-[#111111] block">
                  {language === 'hi' ? 'क्या आप चाहते हैं कि हम आपको कॉल करें?' : 'Want us to call you back?'}
                </span>
                <div className="flex gap-2">
                  <input
                    type="tel"
                    maxLength={10}
                    value={callbackNumber}
                    onChange={(e) => setCallbackNumber(e.target.value.replace(/\D/g, ''))}
                    placeholder="Enter 10-digit number"
                    className="flex-1 px-3 py-2 text-xs bg-white border border-[#E5E0D8] rounded-xl focus:outline-none focus:ring-1 focus:ring-[#111111] text-[#111111]"
                  />
                  <button
                    type="submit"
                    className="bg-[#111111] hover:bg-[#2B2B2B] text-white text-xs font-bold px-4 py-2 rounded-xl transition cursor-pointer shrink-0"
                  >
                    {language === 'hi' ? 'कॉल बैक मांगें' : 'Request Call'}
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
